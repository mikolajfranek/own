﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UnitTestImpromptuInterface.Support
{
#if !NETCOREAPP2_0
    public class Program
    {
        public static void Main()
        {
            
        }
    }
#endif
}
