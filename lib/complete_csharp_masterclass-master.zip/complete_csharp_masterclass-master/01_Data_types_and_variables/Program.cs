﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter_1_data_types_and_variables
{
    //class name like ClientActivity
    public class Program
    {
        //fields
        const double PI = 3.1415;
        const int weeks = 52, months = 12;


        //method name like CalulateValue
        //method arguments like firstNumber
        static void Main(string[] args)
        {
            /*
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.BackgroundColor = ConsoleColor.DarkGray;
            Console.Clear();

            Console.WriteLine("Hello World");
            Console.WriteLine("Hello Mikolaj");
            
            Console.Read();
            */


            /*
            int num1 = 13;
            int num2 = 3;
            int sum = num1 + num2;
            Console.WriteLine(num1 + "+" + num2 + "=" + sum);

            double d1 = 3.14;
            double d2 = 1.82;
            double sumD = d1 + d2;
            Console.WriteLine(d1 + "+" + d2 + "=" + sumD);

            //remember about sufix f
            float f1 = 3.15f;

            Console.Read();
            */


            /*
            string myName = "Mikolaj";
            string message = "My name is " + myName;

            string capsMessage = message.ToUpper();

            Console.WriteLine(capsMessage);
            Console.Read();
            */


            /*
            //local variables like itemCount
            //use userControl instead of usrCtr
            //don't use numbers at he start of variables name
            //_loginUser - make sens

            string myName;
            int lastNum;
            bool isSaved;

            //avoid
            //String myName;
            //Int32 lastNum;
            //Boolean isSaved;
            */


            /*
            //implicit conversion
            int num = 23321321;
            long bigNum = num;
            float myFoloat = 13.37f;
            double myNewDouble = myFoloat;

            //explicit conversion
            double myDouble = 13.37;
            int myInt;
            myInt = (int)myDouble;
            Console.WriteLine(myInt);

            //typeConversion
            string myString = myDouble.ToString(); // "13.37"
            Console.WriteLine(myString);

            bool sunIsShining = true;
            string myBoolString = sunIsShining.ToString();
            Console.WriteLine(myBoolString);

            Console.Read();
            */


            /*
            string myString = "15";
            string mySecondString = "13";

            int num1 = Int32.Parse(myString);
            int num2 = Int32.Parse(mySecondString);
            int resultInt = num1 + num2;

            string result = myString + mySecondString;

            Console.WriteLine(resultInt);

            Console.Read();
            */


            byte myByte = 25;
            Console.WriteLine(myByte);
            sbyte mySbyte = -15;
            Console.WriteLine(mySbyte);
            int myInt = -231321;
            Console.WriteLine(myInt);
            uint myUint = 23131;
            Console.WriteLine(myUint);
            short myShort = -23213;
            Console.WriteLine(myShort);
            ushort myUshort = 32131;
            Console.WriteLine(myUshort);
            float myFloat = 3.14f;
            Console.WriteLine(myFloat);
            double myDouble = 3.231231;
            Console.WriteLine(myDouble);
            char myChar = 'A';
            Console.WriteLine(myChar);
            bool myBool = true;
            Console.WriteLine(myBool);
            string myString = "I control text";
            Console.WriteLine(myString);
            string numText = "15";
            int myNumFromText = int.Parse(numText);
            Console.WriteLine(myNumFromText);

            Console.WriteLine("Pi value is always {0}", PI);

            Console.Read();
        }
    }
}
