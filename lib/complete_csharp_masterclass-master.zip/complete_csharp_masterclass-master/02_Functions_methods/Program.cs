﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter_2_functions_methods
{
    class Program
    {
        public static void WriteSomething()
        {
            Console.WriteLine("Hello");
        }

        public static void WriteSomethingSpecific(string message)
        {
            Console.WriteLine(message);
        }

        public static int Add(int p1, int p2)
        {
            return p1 + p2;
        }

        public static int Multiply(int p1, int p2)
        {
            return p1 * p2;
        }

        public static double Divide(int p1, int p2)
        {
            return (double) p1/ (double) p2;
        }

        public static void GreetFriend(string friendName1, string friendName2, string friendName3)
        {
            Console.WriteLine("Hi {0}, my friend!", friendName1);
            Console.WriteLine("Hi {0}, my friend!", friendName2);
            Console.WriteLine("Hi {0}, my friend!", friendName3);
        }

        public static void Calculate()
        {
            Console.WriteLine("Please enter the first number:");
            string num1Input = Console.ReadLine();
            Console.WriteLine("Please enter the second number:");
            string num2Input = Console.ReadLine();

            int num1 = int.Parse(num1Input);
            int num2 = int.Parse(num2Input);

            int result = num1 + num2;
            WriteSomethingSpecific(result.ToString());
        }

        static void Main(string[] args)
        {
            /*
            WriteSomething();
            WriteSomethingSpecific("Hello World");
            
            string resultAdd = Add(2, 1).ToString();
            WriteSomethingSpecific(resultAdd);

            string resultMultiply = Multiply(2, 1).ToString();
            WriteSomethingSpecific(resultMultiply);

            string resultDivide = Divide(11, 3).ToString();
            WriteSomethingSpecific(resultDivide);
            */


            /*
            string friend1 = "Franek";
            string friend2 = "Michal";
            string friend3 = "Tomas";

            GreetFriend(friend1, friend2, friend3);
            */


            /*
            string input = Console.ReadLine();

            WriteSomethingSpecific(input);
            */

            /*
            Calculate();
            */


            /*
            Console.WriteLine("Please enter number");
            string userInput = Console.ReadLine();
            try
            {
                //int zero = 0;
                //int divideByZero = zero / zero;
                int userInputAsInt = int.Parse(userInput);
            }
            catch (FormatException)
            {
                Console.WriteLine("FormatException, please enter the correct type next time");
            }
            catch (OverflowException)
            {
                Console.WriteLine("OverflowException");
            }
            catch (ArgumentNullException)
            {
                Console.WriteLine("ArgumentNullException");
            }
            catch (Exception)
            {
                Console.WriteLine("General exception");
            }
            finally
            {
                Console.WriteLine("Executed every time!");
            }
            */


            int num1 = 5;
            int num2 = 3;
            int num3;

            //unary operators
            num3 = -num1;
            Console.WriteLine("num3 is {0}", num3);

            bool isSunny = true;
            Console.WriteLine("is it sunny? {0}", !isSunny);

            //increment operators
            int num = 0;
            num++;
            Console.WriteLine("num is {0}", num);
            Console.WriteLine("num is {0}", num++);
            Console.WriteLine("num is {0}", ++num);

            //decrement
            num--;
            Console.WriteLine("num is {0}", num);
            Console.WriteLine("num is {0}", num--);
            Console.WriteLine("num is {0}", --num);

            int result;
            result = num1 + num2;
            Console.WriteLine("result of num1 + num2 is {0}", result);
            result = num1 - num2;
            Console.WriteLine("result of num1 - num2 is {0}", result);
            result = num1 / num2;
            Console.WriteLine("result of num1 / num2 is {0}", result);
            result = num1 * num2;
            Console.WriteLine("result of num1 * num2 is {0}", result);
            result = num1 % num2;
            Console.WriteLine("result of num1 % num2 is {0}", result);

            //relational and type operators
            bool isLower;
            isLower = num1 < num2;
            Console.WriteLine("result of num1 < num2 is {0}", isLower);

            bool isEqual;
            isEqual = num1 == num2;
            Console.WriteLine("result of num1 == num2 is {0}", isEqual);

            isEqual = num1 != num2;
            Console.WriteLine("result of num1 != num2 is {0}", isEqual);

            //conditional operators
            bool isLowerAndSunny;
            isLowerAndSunny = isLower && isSunny;
            Console.WriteLine("result of isLower && isSunny is {0}", isLowerAndSunny);

            bool isLowerOrSunny;
            isLowerOrSunny = isLower || isSunny;
            Console.WriteLine("result of isLower || isSunny is {0}", isLowerOrSunny);


            Console.ReadKey();
        }
    }
}
