﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter_3_making_decision
{
    class Program
    {
        static string userName;
        static string password;

        static string highScorePlayer = "Mikolaj";
        static int highScore = 300;

        public static void CheckHighScore(int score, string playerName)
        {
            if(score > highScore)
            {
                highScore = score;
                highScorePlayer = playerName;
                Console.WriteLine("New highscore is " + score + ", is it now held by " + playerName);
            }
            else
            {
                Console.WriteLine("Old highscore could not be broken. It is still " + highScore + " and held by " + highScorePlayer);
            }
        }

        static void Register()
        {
            Console.WriteLine("Please enter your username: ");
            userName = Console.ReadLine();
            Console.WriteLine("Please enter your password: ");
            password = Console.ReadLine();
            Console.WriteLine("Registarion completed");
            Console.WriteLine("-----------------------------");
        }

        static void Login()
        {
            Console.WriteLine("Please enter your username: ");
            if (userName == Console.ReadLine())
            {
                Console.WriteLine("Please enter your password: ");
                if (password == Console.ReadLine())
                {
                    Console.WriteLine("Has work!");
                }
                else
                {
                    Console.WriteLine("Fail");
                }
            }
            else
            {
                Console.WriteLine("Fail");
            }
        }


        static void Main(string[] args)
        {
            /*
            Console.WriteLine("What's the temperature like?");
            string temperature = Console.ReadLine();

            int numTemperature;
            if(int.TryParse(temperature, out int temp))
            {
                numTemperature = temp;
            }
            else
            {
                numTemperature = 0;
                Console.WriteLine("Value entered, was no number, 0 set as temperature");
            }


            if (numTemperature < 10)
            {
                Console.WriteLine("Take the coat");
            }
            else if (numTemperature == 10)
            {
                Console.WriteLine("It is 10 degrees C");
            }
            else if(numTemperature > 30) {
                Console.WriteLine("It is hot");
            }
            else 
            {
                Console.WriteLine("Warm");
            }
            */


            /*
            Console.WriteLine("Please enter your username");
            bool isAdmin = false;
            bool isRegistered = true;
            string userName = "";

            userName = Console.ReadLine();

            if (isRegistered && userName != "" && userName.Equals("admin"))
            {
                Console.WriteLine("Hi there, register user");
                
                Console.WriteLine("Hi there {0}", userName);
                  
                Console.WriteLine("Hi there, admin");
               
            }

            if(isAdmin || isRegistered)
            {
                Console.WriteLine("You are logged in");
            }
            */

            /*
            Register();
            Login();
            */


            /*
            int age = 19;
            switch (age)
            {
                case 15:
                    Console.WriteLine("Too young to party in the club");
                    break;
                case 25:
                    Console.WriteLine("Good to go");
                    break;
                default:
                    Console.WriteLine("How old are you then?");
                    break;
            }

            if (age == 15)
            {
                Console.WriteLine("Too young to party in the club");
            }
            else if(age == 25)
            {
                Console.WriteLine("Good to go");
            }
            else
            {
                Console.WriteLine("How old are you then?");
            }

            string username = "mikolaj";
            switch (username)
            {
                case "mikolaj":
                    Console.WriteLine("username is mikolaj");
                    break;
                case "root":
                    Console.WriteLine("username is root");
                    break;
                default:
                    Console.WriteLine("username is unknow");
                    break;
            }
            */


            /*
            CheckHighScore(250, "Maria");
            CheckHighScore(315, "Michael");
            CheckHighScore(350, "Mikolaj");
            */


            int temperature = -5;
            string stateOfMatter;
            
            if(temperature < 0)
                stateOfMatter = "Solid";
            else if(temperature > 100)
                stateOfMatter = "Gas";
            else
                stateOfMatter = "Liquid";
            Console.WriteLine("State of matter is {0}", stateOfMatter);

            temperature += 30;
            stateOfMatter = temperature < 0 ? "Solid" : "Liquid";
            Console.WriteLine("State of matter is {0}", stateOfMatter);

            temperature += 100;
            stateOfMatter = temperature < 0 ? "Solid" : (temperature > 100 ? "Gas" : "Liquid");
            Console.WriteLine("State of matter is {0}", stateOfMatter);
            
            Console.ReadKey();
        }
    }
}
