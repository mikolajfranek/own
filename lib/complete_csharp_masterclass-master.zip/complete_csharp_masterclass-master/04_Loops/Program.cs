﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter_4_loops
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
            for(int i = 0; i < 10; i+=2)
            {
                Console.WriteLine("Counter is {0}", i);
            }
            Console.WriteLine("For loop is done");

            for(int j = 0; j < 20; j+=3)
            {
                Console.WriteLine(j);
            }
            Console.WriteLine("For loop is done");
            */


            /*
            int lenghtOfText = 0;
            string wholeText = "";
            do
            {
                Console.WriteLine("Please enter the name of a friend");

                string nameOfFriend = Console.ReadLine();
                int currentLenght = nameOfFriend.Length;

                lenghtOfText += currentLenght;
                wholeText += nameOfFriend;

            } while (lenghtOfText < 20);
            Console.WriteLine("That was enough, {0}", wholeText);
            */


            /*
            int counter = 0;
            Console.WriteLine("Increase amount");
            while (Console.ReadLine().Equals(""))
            {
                counter++;
                Console.WriteLine("Current amount is {0}", counter);
                Console.WriteLine("Increase amount");
            }
            Console.WriteLine("Inside are {0}", counter);
            */


            /*
            for(int i = 0; i < 10; i++)
            {
                if(i == 3)
                {
                    //Console.WriteLine("At 3 we stop");
                    //break;
                    Console.WriteLine("Skip number 3");
                    continue;
                }
                Console.WriteLine(i);
            }
            */

            
            string input = "0";
            int count = 0;
            int total = 0;
            int currentNumber = 0;
            do
            {
                Console.WriteLine("----------------");
                Console.WriteLine("Last number was {0}", currentNumber);
                Console.WriteLine("Current amount entries {0}", count);
                Console.WriteLine("Current amount {0}", total);
                Console.WriteLine("Enter score, (enter -1 to calculate averate)");
                input = Console.ReadLine();

                if (int.TryParse(input, out currentNumber) && currentNumber > 0 && currentNumber < 21)
                {
                    total += currentNumber;
                    count++;
                }
                else if (input.Equals("-1") == false)
                {
                    Console.WriteLine("Not valid value");
                }
                Console.WriteLine("----------------\n");
            } while (input.Equals("-1") == false);

            Console.WriteLine("----------------");
            double average = count != 0 ? ((double)total / (double)count) : 0; 
            Console.WriteLine("Average of score is {0}", average);
            Console.WriteLine("----------------");
            

            Console.ReadKey();
        }
    }
}
