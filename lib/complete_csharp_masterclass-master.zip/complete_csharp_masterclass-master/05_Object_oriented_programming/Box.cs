﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter_5_object_oriented_programming
{
    class Box
    {
        /* fields */
        /* ---------------------------------------------------------- */
        private string color = "white";
        //private int length;
        private int height;
        private int width;
        private int volume;


        /* property */
        /* ---------------------------------------------------------- */    
        //auto - implemented property - enter "prop" + press double tab
        public int Length { get; set; }

        //Height is readonly - when delete set keyword, Height is writeonly - when delete get keyword
        public int Height
        {
            get
            {
                return this.height;
            }
            set
            {
                if(value < 0) throw new Exception("Size should be positive");
                this.height = value;
            }
        }
        public int Width
        {
            get
            {
                return this.width;
            }
            set
            {
                this.width = value;
            }
        }

        public int Volume
        {
            get
            {
                return this.Height * this.Width * this.Length;
            }
            set
            {
                this.volume = value;
            }
        }

        public int FrontSurface
        {
            get
            {
                return this.Length * this.Height;
            }
        }

        //Long version
        /*
        public int Length { get => length; set => length = value; }
        public int Length
        {
            get
            {
                return this.length;
            }
            set
            {
                this.length = value;
            }
        }
        */

        //Metods to allow get, set
        /*
        public void SetLenght(int length)
        {
            this.length = length;
        }
        public int GetLenght()
        {
            return this.length;
        }
        */


        /* constructor */
        /* ---------------------------------------------------------- */
        public Box(int length, int height, int width)
        {
            this.Length = length;
            this.Height = height;
            this.Width = width;
        }


        /* methods */
        /* ---------------------------------------------------------- */
        public void DisplayInfo()
        {
            Console.WriteLine("Lenght is {0}, height is {1}, width is {2}, volume is {3}",
                this.Length,
                this.Height,
                this.Width,
                this.Length * this.Height * this.Width
                );
        }

    }
}
