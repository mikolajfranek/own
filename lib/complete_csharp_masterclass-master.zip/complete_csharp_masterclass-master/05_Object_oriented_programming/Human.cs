﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter_5_object_oriented_programming
{
    class Human
    {
        //member variable
        private string firstName;
        private string lastName;
        private string eyeColor;
        private int age;

        
        //default contructor
        public Human()
        {
            Console.WriteLine("Constructor called, object created");
        }

        //constructor parameterized
        public Human(string firstName)
        {
            this.firstName = firstName;
        }

        //constructor parameterized
        public Human(string firstName, string lastName)
        {
            this.firstName = firstName;
            this.lastName = lastName;
        }

        //constructor parameterized
        public Human(string firstName, string lastName, string eyeColor)
        {
            this.firstName = firstName;
            this.lastName = lastName;
            this.eyeColor = eyeColor;
        }


        //constructor parameterized
        public Human(string firstName, string lastName, string eyeColor, int age)
        {
            this.firstName = firstName;
            this.lastName = lastName;
            this.eyeColor = eyeColor;
            this.age = age;
        }

        //member methonds
        public void IntroduceMySelf()
        {
            Console.WriteLine("------------------------------");
            if (this.firstName != null)
                Console.WriteLine("My name is {0}", this.firstName);
            if (this.lastName != null)
                Console.WriteLine("My last name is {0}", this.lastName);
            if (this.eyeColor != null)
                Console.WriteLine("My eye color is {0}", this.eyeColor);
            if (this.age != 0)
                Console.WriteLine("My age {0}", this.age);
            Console.WriteLine("------------------------------\n");
        }

    }
}
