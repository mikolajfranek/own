﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter_5_object_oriented_programming
{
    class Members
    {
        // fields
        private string memberName;
        private string jobTitle;
        private int salary;

        public int age;


        //property
        public string JobTitle
        {
            get
            {
                return this.jobTitle;
            }
            set
            {
                this.jobTitle = value;
            }
        }



        //constructor
        public Members()
        {
            this.age = 30;
            this.memberName = "Lucy";
            this.salary = 5000;
            this.JobTitle = "Developer";

            Console.WriteLine("Object created");
        }

        //dinalizer, destructor - only one for class
        ~Members()
        {
            //cleanup statement
            Console.WriteLine("Destruction of object");
            Debug.Write("Destruction of object");
        }


        //methods
        public void Introducing(bool isFriend)
        {
            if (isFriend)
            {
                this.SharingPrivateInfo();
            }
            else
            {
                Console.WriteLine("Hi, my name is {0}, and my job titile is {1}, and I'm {2} years old",
                    this.memberName,
                    this.JobTitle,
                    this.age
                    );
            }
        }

        private void SharingPrivateInfo()
        {
            Console.WriteLine("My salary is {0}", this.salary);
        }

    }
}
