﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter_5_object_oriented_programming
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
            //instance of human
            Human mikolaj = new Human();
            mikolaj.firstName = "Mikolaj";
            mikolaj.lastName = "Frank";
            mikolaj.IntroduceMySelf();

            Human mike = new Human();
            mike.firstName = "Michael";
            mike.lastName = "Doe";
            mike.IntroduceMySelf();
            */


            /*
            Human mikolaj = new Human("Mikolaj", "Frank", "brown", 23);
            mikolaj.IntroduceMySelf();

            Human john = new Human("John", "Doe", "blue");
            john.IntroduceMySelf();

            Human natali = new Human("Natali", "Doe");
            natali.IntroduceMySelf();

            Human mike = new Human("Mike");
            mike.IntroduceMySelf();

            Human basic = new Human();
            basic.IntroduceMySelf();
            */

            /*
            try
            {
                Box box = new Box(5, 4, 10);
                Console.WriteLine("Volume is {0}", box.Volume);
                Console.WriteLine("FrontSurface is {0}", box.FrontSurface);

                box.DisplayInfo();
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
            */

            
            Members member1 = new Members();
            member1.Introducing(true);
            //Console.ReadKey();
        }
    }
}
