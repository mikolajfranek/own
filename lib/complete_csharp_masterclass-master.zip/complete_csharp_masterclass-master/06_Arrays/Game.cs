﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter_6_arrays
{
    class Game
    {
        //fields
        private const int DIMENSION_OF_GAME_PLACE = 3;
        private const char USER_O = 'O';
        private const char USER_X = 'X';
        
        private string exceptionMessage;
        private bool endOfGame;

        private char actualUser;
        private int fieldEmpty;
        private char[,] gamePlace =
        {
            {'1', '2', '3'},
            {'4', '5', '6'},
            {'7', '8', '9'}
        };
        

        //properties
        public bool EndOfGame { get => this.endOfGame; set => this.endOfGame = value; }
        public string ResolveException { get => this.exceptionMessage; set => this.exceptionMessage = value; }

        //constructor
        public Game()
        {
            this.exceptionMessage = "";
            this.endOfGame = false;
            this.actualUser = 'X';
            this.fieldEmpty = DIMENSION_OF_GAME_PLACE * DIMENSION_OF_GAME_PLACE;
        }

        //methods
        private bool CheckStatusWinner(string line)
        {
            if (line.Equals((USER_O.ToString() + USER_O.ToString() + USER_O.ToString())) 
                || 
                line.Equals(USER_X.ToString() + USER_X.ToString() + USER_X.ToString()))
            {
                this.endOfGame = true;
                this.ResultMessageWinner();
                return true;
            }
            return false;
        }
        public void CheckStatus()
        {
            string line;
            for(int i = 0; i < DIMENSION_OF_GAME_PLACE; i++)
            {
                line = "";
                for(int j = 0; j < DIMENSION_OF_GAME_PLACE; j++)
                {
                    line += this.gamePlace[i, j].ToString();
                }
                if (this.CheckStatusWinner(line)) return;


                line = "";
                for (int j = 0; j < DIMENSION_OF_GAME_PLACE; j++)
                {
                    line += this.gamePlace[j, i].ToString();
                }
                if (this.CheckStatusWinner(line)) return;
            }

            line = this.gamePlace[0, 0].ToString() + this.gamePlace[1, 1].ToString() + this.gamePlace[2, 2].ToString();
            if (this.CheckStatusWinner(line)) return;

            line = this.gamePlace[2, 0].ToString() + this.gamePlace[1, 1].ToString() + this.gamePlace[0, 2].ToString();
            if (this.CheckStatusWinner(line)) return;

            //draw
            if (this.fieldEmpty == 0)
            {
                this.endOfGame = true;
                this.ResultMessageDraw();
                return;
            }

            this.actualUser = this.actualUser == USER_O ? USER_X : USER_O;
        }
        public void MakeMove()
        {
            string inputField = Console.ReadKey().KeyChar.ToString();
            if (int.TryParse(inputField, out int inputIntField) == false) throw new Exception("Char is not number");
            if (inputIntField < 1 || inputIntField > 9) throw new Exception("Not valid number");

            int x = (inputIntField - 1) / DIMENSION_OF_GAME_PLACE;
            int y = (inputIntField - 1) % DIMENSION_OF_GAME_PLACE;

            if (int.TryParse(this.gamePlace[x, y].ToString(), out int valueOFField) == false) throw new Exception("Field is not empty");

            this.gamePlace[x, y] = this.actualUser;
            this.fieldEmpty--;
        }
        private void DrawGamePlace()
        {
            Console.Clear();
            for (int i = 0; i < DIMENSION_OF_GAME_PLACE; i++)
            {
                Console.WriteLine();
                for (int j = 0; j < DIMENSION_OF_GAME_PLACE; j++)
                {
                    Console.Write("| {0} |", this.gamePlace[i, j]);
                }
                Console.WriteLine();
            }
        }
        public void Draw()
        {
            this.DrawGamePlace();

            Console.WriteLine("\n-------------------------");
            if(this.ResolveException.Equals("") == false)
            {
                Console.WriteLine("Message from program: {0}", this.ResolveException);
                this.ResolveException = "";
                Console.WriteLine("\n-------------------------");
            }

            Console.WriteLine("Hello in game");
            Console.WriteLine("Actual user set {0}", this.actualUser);
            Console.WriteLine("Write position of your sign");
        }
        private void ResultMessageDraw()
        {
            this.DrawGamePlace();

            Console.WriteLine("\n\n^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^");
            Console.WriteLine("Draw");
            Console.WriteLine("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^");
        }
        private void ResultMessageWinner()
        {
            this.DrawGamePlace();

            Console.WriteLine("\n\n^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^");
            Console.WriteLine("Win player which set {0}", this.actualUser);
            Console.WriteLine("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^");
        }
    }
}