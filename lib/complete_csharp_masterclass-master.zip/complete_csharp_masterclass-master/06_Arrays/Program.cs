﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter_6_arrays
{
    class Program
    {

        public static double GetAverage(int[] gradesArray)
        {
            int size = gradesArray.Length;
            double average;
            int sum = 0;

            for(int i = 0; i < size; i++)
            {
                sum += gradesArray[i];
            }

            average = (double)sum / (double)size;
            return average;
        }

        public static void IncreaseValues(int [] gradesArray)
        {
            for (int i = 0; i < gradesArray.Length; i++)
            {
                gradesArray[i] += 10;
            }
        }


        static void Main(string[] args)
        {
            /*
            int[] grades = new int[5];

            //init '1
            grades[0] = 20;
            grades[1] = 14;
            grades[2] = 4;
            grades[3] = 64;
            grades[4] = 122;

            Console.WriteLine("grades at index {0} is {1}", 0, grades[0]);

            Console.WriteLine("Change value of index {0}", 0);
            string input = Console.ReadLine();
            grades[0] = int.Parse(input);
            Console.WriteLine("grades at index {0} is {1}", 0, grades[0]);

            //init '2
            int[] gradesOfMathStudent = { 20, 23, 231, 5, 2, 53 };

            //init '3
            int[] gradesOfHistoryStudent = new int[] { 123, 32, 5, 34, 1, 33 };
            Console.WriteLine("Len of student hitory is {0}", gradesOfHistoryStudent.Length);
            */


            /*
            int[] nums = new int[10];
            for(int i = 0; i < nums.Length; i++)
            {
                nums[i] = i + 10;
            }

            for(int j = 0; j < nums.Length; j++)
            {
                Console.WriteLine("Element at index {0} equal {1}", j, nums[j]);
            }

            Console.WriteLine("--------------------------------------");

            int counter = 0;
            foreach(int value in nums)
            {
                Console.WriteLine("Element at index {0} equal {1}", counter, value);
                counter++;
            }

            Console.WriteLine("--------------------------------------");

            string[] friends = new string[5] { "mike", "frank", "john", "lucy", "daniel"};
            foreach(string friend in friends)
            {
                Console.WriteLine("Hi there {0}, my friend", friend);
            }
            */


            /*
            //2d array
            string[,] matrix;

            //3d array
            int[,,] threeD;


            int[,] array2D = 
            {
                {1,2,3},
                {4,5,6},
                {7,8,9}
            };
            Console.WriteLine("Central value is {0}", array2D[1,1]);


            string[,,] array3D = new string[,,]
            {
                {
                    {"000", "001"},
                    {"010", "011"}
                },
                {
                    {"100", "101"},
                    {"110", "111"}
                }
            };
            Console.WriteLine("Some string in 3d array is {0}", array3D[1,0,1]);

            int dimension = array3D.Rank;
            Console.WriteLine("Dimenstion is {0}", dimension);
            */


            //game
            /*
            Game game = new Game();

            while (game.EndOfGame == false)
            {
                try
                {
                    game.Draw();
                    game.MakeMove();
                    game.CheckStatus();

                }catch(Exception e)
                {
                    game.ResolveException = e.Message;
                }
            }
            Console.WriteLine("End of game!");
            */


            /*
            //jagged array - tablica tablic
            int[][] jaggedArray = new int[3][];
            jaggedArray[0] = new int[5];
            jaggedArray[1] = new int[3];
            jaggedArray[2] = new int[2];

            jaggedArray[0] = new int[] { 2, 3, 4, 5, 6 };
            jaggedArray[1] = new int[] { 1, 2, 3 };
            jaggedArray[2] = new int[] { 3, 5 };


            int[][] jaggedArray2 = new int[][]
            {
                new int[] { 2, 3, 4, 5, 6 },
                new int[] { 1, 2, 3 },
                new int[] { 3, 5 }
            };
            Console.WriteLine("Middle in first entry is {0}", jaggedArray2[0][2]);
            for (int i = 0; i < jaggedArray2.Length; i++)
            {
                Console.WriteLine();
                for(int j = 0; j < jaggedArray2[i].Length; j++)
                {
                    Console.WriteLine("Element of ({0}, {1}) is {2}", i, j, jaggedArray2[i][j]);
                }
            }*/


            //arrays as param
            /*
            int[] studentsGrades = new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 9};
            Console.WriteLine("Average is {0}", GetAverage(studentsGrades));

            //array by ref in param
            IncreaseValues(studentsGrades);

            foreach (int grade in studentsGrades)
            {
                Console.WriteLine("{0}", grade);
            }
            */

            //arrayList
            //declare with undefined amount of objects
            ArrayList myArrayList = new ArrayList();
            
            //declare with defined amount of object
            ArrayList myArrayList2 = new ArrayList(100);

            myArrayList.Add(25);
            myArrayList.Add("Hello");
            myArrayList.Add(123.23);
            myArrayList.Add(13);
            myArrayList.Add(128);
            myArrayList.Add(25.3);
            myArrayList.Add(13);

            //delete element with value entry from arraylist
            //only remove the first 13 
            myArrayList.Remove(13);

            //delete element with specyfic position
            myArrayList.RemoveAt(0);
            Console.WriteLine(myArrayList.Count);

            double sum = 0;
            foreach(object obj in myArrayList)
            {
                if(obj is int)
                {
                    sum += Convert.ToDouble(obj);
                }else if (obj is double)
                {
                    sum += (double)obj;
                }
                else if(obj is string)
                {
                    Console.WriteLine(obj);
                }
            }
            Console.WriteLine("Sum is {0}", sum);
           
            Console.ReadKey();
        }


    }
}
