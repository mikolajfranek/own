﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter_7_inheritance_and_more_about_oop
{
    public interface INotifications
    {
        void ShowNotification();
        string GetDate();
    }
}
