﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter_7_inheritance_and_more_about_oop
{
    class ImagePost : Post
    {
        private string ImageUrl { get; set; }

        public ImagePost() { }

        public ImagePost(string title, string sendByUserName, string imageUrl, bool isPublic)
        {
            this.ID = this.GetNextID();
            
            //remember that if a derived class does not invoke a base-class contructor explicitly,
            //the default constructor is called implicitly

            //this.Title = title;
            this.SendByUserName = sendByUserName;
            this.IsPublic = isPublic;

            this.ImageUrl = imageUrl;
        }

        //overide method from class Post
        public override string ToString()
        {
            //return base.ToString(
            return String.Format("{0} - {1} - {2} - by {3}", this.ID, this.Title, this.ImageUrl, this.SendByUserName);
        }
    }
}
