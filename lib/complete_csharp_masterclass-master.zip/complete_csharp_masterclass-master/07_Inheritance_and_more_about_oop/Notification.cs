﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter_7_inheritance_and_more_about_oop
{
    class Notification : INotifications
    {
        private string sender;
        private string message;
        private string date;

        public Notification()
        {
            this.sender = "admin";
            this.message = "none";
            this.date = "-";
        }

        public Notification(string sender, string message, string date)
        {
            this.sender = sender;
            this.message = message;
            this.date = date;
        }

        public string GetDate()
        {
            return this.date;
        }

        public void ShowNotification()
        {
            Console.WriteLine("Message {0} - was sent by {1} at {2}", this.message, this.sender, this.date);
        }
    }
}
