﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter_7_inheritance_and_more_about_oop
{
    class Post
    {
        //it will be created once the application is started
        private static int currentPostId;

        protected int ID { get; set; }
        protected string Title { get; set; }
        protected string SendByUserName { get; set; }
        protected bool IsPublic { get; set; }


        //valid
        //if a derived class does not invoke a base-class contructor explicitly,
        //the default constructor is called implicitly
        public Post()
        {
            this.ID = 0;
            this.Title = "Post";
            this.IsPublic = true;
            this.SendByUserName = "Mikolaj";
        }

        public Post(string title, bool isPublic, string sendByUserName)
        {
            this.ID = this.GetNextID();
            this.Title = title;
            this.IsPublic = isPublic;
            this.SendByUserName = sendByUserName;
        }

        protected int GetNextID()
        {
            return ++currentPostId;
        }
        public void Update(string title, bool isPublic)
        {
            this.Title = title;
            this.IsPublic = isPublic;
        }

        //virtual method overide of the ToString method that is inherited
        //from System.Object.ToString
        public override string ToString()
        {
            //return base.ToString()
            return String.Format("{0} - {1} - by {2}", this.ID, this.Title, this.SendByUserName);
        }
    }
}
