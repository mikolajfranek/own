﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter_7_inheritance_and_more_about_oop
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
            Post post = new Post("Thanks of the birthdays wishes", true, "Mikolaj");
            Console.WriteLine(post.ToString());
            
            ImagePost imagepost = new ImagePost("Check out my new shoes", "Mikolaj", "https://images.com/shoes", true);
            Console.WriteLine(imagepost.ToString());
            
            VideoPost videoPost = new VideoPost("FailVideo", "Mikolaj", "https://video.com/fakevideo", true, 15);
            Console.WriteLine(videoPost.ToString());

            videoPost.Play();

            Console.WriteLine("Press any key to stop video");
            Console.ReadKey();
            videoPost.Stop();
            */

            /*
            Employee mike = new Employee("Mike", "Doe", 1000);
            mike.Work();
            mike.Pause();

            Boss john = new Boss("Ferrari", "John", "Doe", 2000);
            john.Lead();

            Trainee david = new Trainee(32, 8, "Doe", "David", 500);
            david.Learn();
            david.Work();
            */

            Notification notify = new Notification("Mikolaj", "Go a head", "12.02.1992");
            notify.ShowNotification();

            Console.ReadKey();
        }
    }
}
