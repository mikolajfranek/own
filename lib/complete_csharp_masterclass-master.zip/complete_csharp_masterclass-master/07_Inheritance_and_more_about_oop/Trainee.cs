﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter_7_inheritance_and_more_about_oop
{
    class Trainee : Employee
    {
        public int WorkingHours { get; set; }
        public int SchoolHours { get; set; }

        public Trainee(int workingHours, int schoolHours, string name, string firstName, int salary) : base(name, firstName, salary)
        {
            this.WorkingHours = workingHours;
            this.SchoolHours = schoolHours;
        }

        public void Learn()
        {
            Console.WriteLine("I am learning - {0} {1}", this.Name, this.FirstName);
        }
        
        //?
        public new void Work()
        {
            Console.WriteLine("I work for {0} hours", this.WorkingHours);
        }
    }
}
