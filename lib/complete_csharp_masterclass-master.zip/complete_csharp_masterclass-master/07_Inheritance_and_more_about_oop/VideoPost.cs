﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Chapter_7_inheritance_and_more_about_oop
{
    class VideoPost : Post
    {
        protected bool isPlaying = false;
        protected int currentDuration = 0;
        Timer timer;

        protected string VideoUrl { get; set; }
        protected int Length { get; set; }


        public VideoPost() {}

        public VideoPost(string title, string sendByUserName, string videoUrl, bool isPublic, int length)
        {
            this.ID = this.GetNextID();
            this.Title = title;
            this.SendByUserName = sendByUserName;
            this.IsPublic = isPublic;

            this.VideoUrl = videoUrl;
            this.Length = length;
        }

        public override string ToString()
        {
            return String.Format("{0} - {1} - {2} - {3} by {4}", this.ID, this.Title, this.VideoUrl, this.Length, this.SendByUserName);
        }

        private void TimerCallback(Object o)
        {
            if(currentDuration < Length)
            {
                currentDuration++;
                Console.WriteLine("Video at {0}s", currentDuration);
                GC.Collect();
            }
            else
            {
                this.Stop();
            }
        }

        public void Play()
        {
            if(isPlaying == false)
            {
                this.isPlaying = true;
                Console.WriteLine("Play {0}", this.Title);
                timer = new Timer(TimerCallback, null, 0, 1000);
            }
        }

        public void Stop()
        {
            if (isPlaying)
            {
                this.isPlaying = false;
                Console.WriteLine("Stop {0}", this.Title);
                currentDuration = 0;
                timer.Dispose();
            }
        }
    }
}
