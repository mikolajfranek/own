﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter_8_polymorphism_and_even_more_on_opp_plus_text_files
{
    class Audi : Car
    {
        private string brand = "Audi";
        public string Model { get; set; }

        public Audi(int hp, string color, string model) : base(hp, color)
        {
            this.Model = model;
        }

        public void ShowDetails()
        {
            Console.WriteLine("Brand {0}, HP {1}, Color {2}", this.brand, this.HP, this.Color);
        }

        public override void Repair()
        {
            Console.WriteLine("The Audi {0} was repaired", this.Model);
        }
    }
}