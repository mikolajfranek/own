﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter_8_polymorphism_and_even_more_on_opp_plus_text_files
{
    /* sealed */class BMW : Car
    {
        private string brand = "BMW";
        public string Model { get; set; }

        /*
        public BMW()
        {

        }
        */

        public BMW(int hp, string color, string model) : base(hp, color)
        {
            this.Model = model;
        }

        //this metod has priority over base method class
        public new void ShowDetails()
        {
            Console.WriteLine("Brand {0}, HP {1}, Color {2}", this.brand, this.HP, this.Color);
        }

        //sealed only before override - otherwise not work
        public sealed override void Repair()
        {
            Console.WriteLine("The BMW {0} was repaired", this.Model);
        }
    }
}
