﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter_8_polymorphism_and_even_more_on_opp_plus_text_files
{
    //relation 'has a'
    class CarIdInfo
    {
        public int IDNum { get; set; } = 0;
        public string Owner { get; set; } = "No owner";

    }
}
