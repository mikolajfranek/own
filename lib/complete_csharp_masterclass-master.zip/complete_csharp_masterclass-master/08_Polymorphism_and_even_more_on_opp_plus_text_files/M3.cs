﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter_8_polymorphism_and_even_more_on_opp_plus_text_files
{

    //with default constructor in BMW and CAR - constructor is useless
    class M3 : BMW
    {
        public M3(int hp, string color, string model) : base(hp, color, model)
        {

        }

        /*
        public override void Repair()
        {
            base.Repair();
        }
        */

    }
}
