﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter_8_polymorphism_and_even_more_on_opp_plus_text_files
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
            var cars = new List<Car>
            {
                new Audi(200, "blue", "A4"),
                new BMW(250, "red", "M3")
            };


            foreach(var car in cars)
            {
                car.Repair();
            }


            Car bmwZ3 = new BMW(200, "black", "Z3");
            Car audiA3 = new Audi(100, "green", "A3");
            bmwZ3.ShowDetails();
            audiA3.ShowDetails();


            BMW bmwM5 = new BMW(330, "white", "M5");
            bmwM5.ShowDetails();


            Car carB = (Car)bmwM5;
            carB.ShowDetails();


            M3 myM3 = new M3(220, "red", "M3");
            myM3.Repair();


            //has a 
            bmwZ3.SetCarIdInfo(123, "Mikolaj");
            audiA3.SetCarIdInfo(432, "Frank");
            bmwZ3.GetCarIdInfo();
            audiA3.GetCarIdInfo();
            */


            string path = @"C:\Users\7\Desktop\complete_csharp_masterclass\Chapter_8_polymorphism_and_even_more_on_opp_plus_text_files\Assets\test.txt";
            //'1
            string[] lines = { "215thirds", "252", "third199" };
            //System.IO.File.WriteAllLines(path, lines);

            //'2
            //string input = Console.ReadLine();
            //System.IO.File.WriteAllText(path, input);

            //'3
            using (System.IO.StreamWriter file = new System.IO.StreamWriter(path))
            {
                foreach(string line in lines)
                {
                    if (line.Contains("third"))
                    {
                        file.WriteLine(line);
                    }
                }
            }
            //adding
            using(System.IO.StreamWriter file = new System.IO.StreamWriter(path, true))
            {
                file.WriteLine("additional line");
            }

            
            //'1
            string text = System.IO.File.ReadAllText(path);
            Console.WriteLine("Text file contain folowing text {0}", text);

            /*
            //'2
            string[] lines = System.IO.File.ReadAllLines(path);
            Console.WriteLine("Text file contain folowing text:");
            foreach (string line in lines)
            {
                Console.WriteLine("\t{0}", line);
            }
            */

            Console.ReadKey();
        }
    }
}
