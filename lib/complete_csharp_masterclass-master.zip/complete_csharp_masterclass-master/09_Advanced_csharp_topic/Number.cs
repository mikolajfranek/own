﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter_9_advanced_csharp_topics
{
    class Number
    {
        public int n { get; set; }

        public override string ToString()
        {
            return n.ToString();
        }

    }
}
