﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Chapter_9_advanced_csharp_topics
{
    class Program
    {
        //delegete
        public delegate int SomeMath(int i);

        public delegate bool Compare(int i, Number n);


        struct Game
        {
            public string name;
            public string developer;
            public double rating;
            public string releaseDate;

            public Game(string name, string developer, double rating, string releaseDate)
            {
                this.name = name;
                this.developer = developer;
                this.rating = rating;
                this.releaseDate = releaseDate;
            }

            public void Display()
            {
                Console.WriteLine("Game {0} was develop by {1}, rating is {2}, release date {3}", this.name, this.developer, this.rating, this.releaseDate);
            }
        }


        enum Day { Mo, Tu, We, Th, Fr, Sa, Su }

        public static DateTime GetTomorrow()
        {
            return DateTime.Today.AddDays(1);
        }

        public static DateTime GetFirstDayOfYear(int year)
        {
            return new DateTime(year, 1, 1);
        }

        static void Main(string[] args)
        {
            /*
            //lambda expression and delegate
            DoSomething();
            */

            //list
            /*
            //immutable
            int[] scores = new int[] { 943, 43, 34, 43 };

            List<int> list = new List<int> { 1, 2, 3, 4 };
            list.Add(0);
            list.Add(32);
            list.Sort();
            list.RemoveRange(2, 2);

            list.ForEach(x => Console.WriteLine(x));

            Console.WriteLine(list.Contains(7));

            int index = list.FindIndex(x => x == 1);
            Console.WriteLine("Position of 1 is {0}", index);

            list.RemoveAt(index);
            list.ForEach(x => Console.WriteLine(x));


            ArrayList arrayList = new ArrayList();
            arrayList.Add(1);
            arrayList.Add("Two");
            arrayList.Add(new Number { n = 4 });

            foreach(Object o in arrayList)
            {
                Console.WriteLine(o);
            }
            */

            /*
            //class is reference type
            //structs are value type
            Game game1;

            game1.name = "Pokemon go";
            game1.developer = "XXX";
            game1.rating = 3.2;
            game1.releaseDate = "01.01.1992";

            game1.Display();
            */


            /*
            Day fr = Day.Fr;
            Console.WriteLine(fr == Day.Fr);
            Console.WriteLine(Day.Mo);
            Console.WriteLine((int)Day.Mo);
            Console.WriteLine(Day.Mo == 0);
            */

            
            /*
            Console.WriteLine("Cell {0}", Math.Ceiling(15.1));
            Console.WriteLine("Floor {0}", Math.Floor(15.9));
            int num1 = 13;
            int num2 = 9;
            Console.WriteLine("Min {0}", Math.Min(num1, num2));
            Console.WriteLine("Max {0}", Math.Max(num1, num2));

            Console.WriteLine("2^3 = {0}", Math.Pow(2,3));
            Console.WriteLine("PI = {0}", Math.PI);
            Console.WriteLine("Squareroot of 25 is {0}", Math.Sqrt(25));
            Console.WriteLine("Abs of -5 is {0}", Math.Abs(-5));
            Console.WriteLine("Cos of 1 is {0}", Math.Cos(1));
            */


            /*
            Random dice = new Random();
            int numEyes;

            for(int i = 0; i < 10; i++)
            {
                numEyes = dice.Next(1, 7);
                Console.WriteLine(numEyes);
            }
            */


            /*
            string pattern = @"23(1|2)?";
            Regex regex = new Regex(pattern);

            string test = "Hi there, my numer is 231321 and other 232";

            MatchCollection matchCollection = regex.Matches(test);
            foreach(Match m in matchCollection)
            {
                GroupCollection group = m.Groups;
                foreach(Group g in group)
                {
                    Console.WriteLine(m.Value + " on index " + m.Index + " or  position " + g.Index);
                }  
            }
            */


            /*
            DateTime dateTime = new DateTime(1995, 3, 24);
            Console.WriteLine("My birthday is {0}", dateTime);

            //current date
            Console.WriteLine(DateTime.Today);

            Console.WriteLine(DateTime.Now);

            //tomorrow
            DateTime tommorow = GetTomorrow();
            Console.WriteLine(tommorow);

            //days of week
            Console.WriteLine("Today is {0}", DateTime.Today.DayOfWeek);

            //fist of day
            Console.WriteLine("First of  1995 is {0}", GetFirstDayOfYear(1995));

            int days = DateTime.DaysInMonth(2000, 2);
            Console.WriteLine("Days in Feb 2000 were {0}", days);
   
            DateTime now = DateTime.Now;
            Console.WriteLine("Minute {0}", now.Minute);

            Console.WriteLine("Hour {0}, Minute {1}, Seconds {2}", DateTime.Now.Hour, DateTime.Now.Minute, DateTime.Now.Second);


            Console.WriteLine("Write a date in format YYYY-MM-DD");
            string date = Console.ReadLine();
            if(DateTime.TryParse(date, out DateTime result))
            {
                Console.WriteLine(result);
                TimeSpan daysPassed = DateTime.Now.Subtract(result);
                Console.WriteLine("Days passed since {0} will be {1}", result, daysPassed.Days);
            }
            else
            {
                Console.WriteLine("Wrong input");
            }
            */



            //nullables
            int? num1 = null;
            //int num2 = null; - error
            int? num3 = 13213;

            double? num4 = new Double?();
            double? num5 = 3.1415;

            bool? boolval = new bool?();

            Console.WriteLine("Nullable numbers are: {0}, {1}, {2}, {3}", num1, num3, num4, num5);
            Console.WriteLine("Nullable bool is {0}", boolval);

            bool? isMale = null;
            if (isMale == true)
            {
                Console.WriteLine("Male");
            }
            else if(isMale == false)
            {
                Console.WriteLine("Not Male");
            }
            else
            {
                Console.WriteLine("No gender choosen");
            }


            double? number1 = 123.45;
            double? number2 = null;
            double result;

            if(number1 == null)
            {
                result = 0.0;
            }
            else
            {
                result = (double)number1;
            }
            Console.WriteLine("Result is {0}", result);

            //short version of NULL COALESCING OPERATOR
            //if null then value is assigned
            result = number1 ?? 0.0;
            Console.WriteLine("Result is {0}", result);

            result = number2 ?? 0.0;
            Console.WriteLine("Result is {0}", result);



            Console.ReadKey();
        }

        public static void DoSomething()
        {
            SomeMath math = new SomeMath(TimesTen);
            Console.WriteLine(math(8));

            List<int> list = new List<int> { 1, 2, 3, 5, 6, 7 };
            List<int> evenNumbers = list.FindAll(delegate(int i){
                return i % 2 == 0;
            });

            foreach(int even in evenNumbers)
            {
                Console.WriteLine(even);
            }

            //lambda expression
            List<int> oddNumbers = list.FindAll(x => x % 2 == 1);
            oddNumbers.ForEach(x => 
                {
                    Console.WriteLine("Odd numbers");
                    Console.WriteLine(x);
                }
            );



            math = new SomeMath(x => x * x * x);
            Console.WriteLine(math(4));

            Compare comp = (a, number) => a == number.n;
            Console.WriteLine(comp(5, new Number { n = 5 } ));
        }

        public static int Add(int a, int b)
        {
            return a + b;
        }

        public static int Square(int i)
        {
            return i * i;
        }

        public static int TimesTen(int i)
        {
            return i * 10;
        }
         
    }
}
