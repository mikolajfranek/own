﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Chapter_10_wpf
{
    /// <summary>
    /// Logika interakcji dla klasy MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public int MyProperty
        {
            get { return (int) GetValue(dependencyProperty); }
            set { SetValue(dependencyProperty, value); }
        }

        //own depenency property
        public static readonly DependencyProperty dependencyProperty = 
            DependencyProperty.Register("MyProperty", typeof(int), typeof(MainWindow), new PropertyMetadata(0));


        public Sum SumObject { get; set; }

        public MainWindow()
        {
            InitializeComponent();

            /*
            Grid grid = new Grid();
            this.Content = grid;

            Button button = new Button();
            button.FontSize = 22;
            button.Width = 200;
            button.Height = 50;

            WrapPanel wrapPanel = new WrapPanel();


            TextBlock textBlock = new TextBlock();

            textBlock.Text = "Multi";
            textBlock.Foreground = Brushes.Blue;
            wrapPanel.Children.Add(textBlock);

            textBlock = new TextBlock();
            textBlock.Text = "Color";
            textBlock.Foreground = Brushes.Red;
            wrapPanel.Children.Add(textBlock);

            textBlock = new TextBlock();
            textBlock.Text = "Button";
            textBlock.Foreground = Brushes.Green;
            wrapPanel.Children.Add(textBlock);

            button.Content = wrapPanel;

            grid.Children.Add(button);
            */


            //binding mode onetime
            /*
            MySlider.Value = 30;
            */


            /*
            SumObject = new Sum { Num1 = "1", Num2 = "3" };
            this.DataContext = SumObject;
            */

            /*
            List<Match> matches = new List<Match>();
            matches.Add(new Match() { Team1 = "team1", Team2 = "team2", Score1 = 3, Score2 = 6, Completion = 85 });
            matches.Add(new Match() { Team1 = "team3", Team2 = "team4", Score1 = 6, Score2 = 2, Completion = 25 });

            ListBoxMatches.ItemsSource = matches;
            */

            /*
            ElementComboBox.ItemsSource = typeof(Colors).GetProperties();
            */
        }

        //Directing event
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Direct event", "Info", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        //Bubbling event
        //sends to the top of element - where some element may handled event
        private void Button_MouseUp(object sender, MouseButtonEventArgs e)
        {
            MessageBox.Show("Bubbling event", "Info", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        
        //Tunneling event
        //sends to the bottom of element - where some element may handled event
        private void Button_PreviewMouseUp(object sender, MouseButtonEventArgs e)
        {
            MessageBox.Show("Tunneling event", "Info", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void Button_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            MessageBox.Show("Left button went down - tunnelling event", "Info", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void Button_PreviewMouseRightButtonUp(object sender, MouseButtonEventArgs e)
        {
            MessageBox.Show("Right button went up - tunnelling event", "Info", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            /*
            if (ListBoxMatches.SelectedItem != null)
            {
                MessageBox.Show(
                    "Result of match " + (ListBoxMatches.SelectedItem as Match).Team1 + " "
                    + (ListBoxMatches.SelectedItem as Match).Score1 + " : "
                    + (ListBoxMatches.SelectedItem as Match).Score2 + " "
                    + (ListBoxMatches.SelectedItem as Match).Team2

                    ,
                    "Info",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information
                    );
            }
            */
        }

        /*
        private void ElementCheckBoxAllChanged(object sender, RoutedEventArgs e)
        {
            bool new_value = ElementCheckBoxAll.IsChecked == true;
            ElementCheckBoxSalami.IsChecked = new_value;
            ElementCheckBoxMozzarella.IsChecked = new_value;
            ElementCheckBoxMushrooms.IsChecked = new_value;
        }

        private void ElementCheckBoxSingleChanged(object sender, RoutedEventArgs e)
        {
            ElementCheckBoxAll.IsChecked = null;
            if(ElementCheckBoxSalami.IsChecked == true && ElementCheckBoxMozzarella.IsChecked == true && ElementCheckBoxMushrooms.IsChecked == true)
            {
                ElementCheckBoxAll.IsChecked = true;
            }

            if (ElementCheckBoxSalami.IsChecked == false && ElementCheckBoxMozzarella.IsChecked == false && ElementCheckBoxMushrooms.IsChecked == false)
            {
                ElementCheckBoxAll.IsChecked = false;
            }
        }
        */

        private void RadioButton_CheckedYes(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Thank you", "Info", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void RadioButton_CheckedNo(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Please say yes", "Info", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void RadioButton_CheckedMaybe(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Please say yes", "Info", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Welcome" + ElementTextBoxUserName, "Info", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }
}
