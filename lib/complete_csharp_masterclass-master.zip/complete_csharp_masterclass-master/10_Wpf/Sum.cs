﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter_10_wpf
{
    public class Sum : INotifyPropertyChanged
    {
        private string num1;
        private string num2;
        private string result;

        public string Num1
        {
            get
            {
                return this.num1;
            }
            set
            {
                if(int.TryParse(value, out int number))
                {
                    this.num1 = value;
                }
                OnPropertyChanged("Num1");
                OnPropertyChanged("Result");
            }
        }

        public string Num2
        {
            get
            {
                return this.num2;
            }
            set
            {
                if (int.TryParse(value, out int number))
                {
                    this.num2 = value;
                }
                OnPropertyChanged("Num2");
                OnPropertyChanged("Result");
            }
        }

        public string Result
        {
            get
            {
                int result = int.Parse(Num1) + int.Parse(Num2);
                return result.ToString();
            }
            set
            {
                int result = int.Parse(Num1) + int.Parse(Num2);
                this.result = result.ToString();
                OnPropertyChanged("Result");
            }
        }


        public event PropertyChangedEventHandler PropertyChanged;

        private void OnPropertyChanged(string property)
        {
            if(this.PropertyChanged != null)
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(property));
            }
        }
    }
}
