﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Chapter_11_using_databases
{
    /// <summary>
    /// Logika interakcji dla klasy MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        SqlConnection sqlConnection;

        public MainWindow()
        {
            InitializeComponent();

            string connectionString = ConfigurationManager.ConnectionStrings["Chapter_11_using_databases.Properties.Settings.franek_dbConnectionString"].ConnectionString;
            this.sqlConnection = new SqlConnection(connectionString);

            this.ShowZoos();
            ShowAnimals();
        }

        private void ShowZoos()
        {
            try
            {
                string query = "SELECT * FROM Zoo";
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(query, this.sqlConnection);

                using (sqlDataAdapter)
                {
                    DataTable zooTable = new DataTable();
                    sqlDataAdapter.Fill(zooTable);

                    //content which we want to see
                    ElementListBox_Zoo.DisplayMemberPath = "Location";
                    //value behind specyfic item is id
                    ElementListBox_Zoo.SelectedValuePath = "Id";
                    //assigned content from table
                    ElementListBox_Zoo.ItemsSource = zooTable.DefaultView;
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString(), "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ShowZooAnimal()
        {
            try
            {
                string query = 
                    "SELECT * " +
                    "FROM Animal as a " +
                    "JOIN ZooAnimal as za on a.Id = za.AnimalId " +
                    "WHERE za.ZooId = @ZooId";
                SqlCommand sqlCommand = new SqlCommand(query, this.sqlConnection);
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);

                using (sqlDataAdapter)
                {
                    sqlCommand.Parameters.AddWithValue("ZooId", ElementListBox_Zoo.SelectedValue);

                    DataTable animalTable = new DataTable();
                    sqlDataAdapter.Fill(animalTable);

                    //content which we want to see
                    ElementListBox_ZooAnimal.DisplayMemberPath = "Name";
                    //value behind specyfic item is id
                    ElementListBox_ZooAnimal.SelectedValuePath = "Id";
                    //assigned content from table
                    ElementListBox_ZooAnimal.ItemsSource = animalTable.DefaultView;
                }
            }
            catch (Exception e)
            {
                //MessageBox.Show(e.ToString(), "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ShowAnimals()
        {
            try
            {
                string query = "SELECT * FROM Animal";
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(query, this.sqlConnection);

                using (sqlDataAdapter)
                {
                    DataTable animalTable = new DataTable();
                    sqlDataAdapter.Fill(animalTable);

                    //content which we want to see
                    ElementListBox_Animal.DisplayMemberPath = "Name";
                    //value behind specyfic item is id
                    ElementListBox_Animal.SelectedValuePath = "Id";
                    //assigned content from table
                    ElementListBox_Animal.ItemsSource = animalTable.DefaultView;
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString(), "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ShowSelectedZooInTextBox()
        {
            try
            {
                string query =
                    "SELECT Location " +
                    "FROM Zoo " +
                    "WHERE Id = @ZooId";
                SqlCommand sqlCommand = new SqlCommand(query, this.sqlConnection);
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);

                using (sqlDataAdapter)
                {
                    sqlCommand.Parameters.AddWithValue("ZooId", ElementListBox_Zoo.SelectedValue);

                    DataTable zooDataTable = new DataTable();
                    sqlDataAdapter.Fill(zooDataTable);

                    ElementTextBox.Text = zooDataTable.Rows[0]["Location"].ToString();
                }
            }
            catch (Exception e)
            {
                //MessageBox.Show(e.ToString(), "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ShowSelectedAnimalInTextBox()
        {
            try
            {
                string query =
                    "SELECT Name " +
                    "FROM Animal " +
                    "WHERE Id = @AnimalId";
                SqlCommand sqlCommand = new SqlCommand(query, this.sqlConnection);
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);

                using (sqlDataAdapter)
                {
                    sqlCommand.Parameters.AddWithValue("AnimalId", ElementListBox_Animal.SelectedValue);

                    DataTable zooDataTable = new DataTable();
                    sqlDataAdapter.Fill(zooDataTable);

                    ElementTextBox.Text = zooDataTable.Rows[0]["Name"].ToString();
                }
            }
            catch (Exception e)
            {
                //MessageBox.Show(e.ToString(), "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ElementListBox_Zoo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            this.ShowZooAnimal();
            this.ShowSelectedZooInTextBox();
        }

        private void DeleteZoo_Click(object sender, RoutedEventArgs e)
        {
            try {
                ElementListBox_ZooAnimal.ItemsSource = null;

                string query = "DELETE FROM Zoo WHERE Id = @ZooId";
                SqlCommand sqlCommand = new SqlCommand(query, this.sqlConnection);
                this.sqlConnection.Open();
                sqlCommand.Parameters.AddWithValue("ZooId", ElementListBox_Zoo.SelectedValue);
                sqlCommand.ExecuteScalar();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                this.sqlConnection.Close();
                this.ShowZoos();                
            }
        }

        private void AddZoo_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string query = "INSERT INTO Zoo VALUES (@Location)";
                SqlCommand sqlCommand = new SqlCommand(query, this.sqlConnection);
                this.sqlConnection.Open();
                sqlCommand.Parameters.AddWithValue("Location", ElementTextBox.Text);
                sqlCommand.ExecuteScalar();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                this.sqlConnection.Close();
                this.ShowZoos();
            }
        }

        private void AddAnimalToZoo_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string query = "INSERT INTO ZooAnimal VALUES (@ZooId, @AnimalId)";
                SqlCommand sqlCommand = new SqlCommand(query, this.sqlConnection);
                this.sqlConnection.Open();
                sqlCommand.Parameters.AddWithValue("ZooId", ElementListBox_Zoo.SelectedValue);
                sqlCommand.Parameters.AddWithValue("AnimalId", ElementListBox_Animal.SelectedValue);
                sqlCommand.ExecuteScalar();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                this.sqlConnection.Close();
                this.ShowZooAnimal();
            }
        }

        private void DeleteAnimal_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string query = "DELETE FROM Animal WHERE Id = @AnimalId";
                SqlCommand sqlCommand = new SqlCommand(query, this.sqlConnection);
                this.sqlConnection.Open();
                sqlCommand.Parameters.AddWithValue("AnimalId", ElementListBox_Animal.SelectedValue);
                sqlCommand.ExecuteScalar();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                this.sqlConnection.Close();
                this.ShowAnimals();
                this.ShowZooAnimal();
            }
        }

        private void AddAnimal_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                ElementListBox_ZooAnimal.ItemsSource = null;

                string query = "INSERT INTO Animal VALUES (@Name)";
                SqlCommand sqlCommand = new SqlCommand(query, this.sqlConnection);
                this.sqlConnection.Open();
                sqlCommand.Parameters.AddWithValue("Name", ElementTextBox.Text);
                sqlCommand.ExecuteScalar();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                this.sqlConnection.Close();
                this.ShowAnimals();
            }
        }

        private void DeleteAnimalAssociated_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string query = "DELETE FROM ZooAnimal WHERE AnimalId = @ZooAnimalId AND ZooId = @ZooId";
                SqlCommand sqlCommand = new SqlCommand(query, this.sqlConnection);
                this.sqlConnection.Open();
                sqlCommand.Parameters.AddWithValue("ZooAnimalId", ElementListBox_ZooAnimal.SelectedValue);
                sqlCommand.Parameters.AddWithValue("ZooId", ElementListBox_Zoo.SelectedValue);
                sqlCommand.ExecuteScalar();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                this.sqlConnection.Close();
                this.ShowZooAnimal();
            }
        }

        private void ElementListBox_Animal_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            this.ShowSelectedAnimalInTextBox();
        }

        private void UpdateZoo_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string query = "UPDATE Zoo SET Location = @Location WHERE Id = @ZooId";
                SqlCommand sqlCommand = new SqlCommand(query, this.sqlConnection);
                this.sqlConnection.Open();
                sqlCommand.Parameters.AddWithValue("Location", ElementTextBox.Text);
                sqlCommand.Parameters.AddWithValue("ZooId", ElementListBox_Zoo.SelectedValue);
                sqlCommand.ExecuteScalar();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                this.sqlConnection.Close();
                this.ShowZoos();
            }
        }

        private void UpdateAnimal_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string query = "UPDATE Animal SET Name = @Name WHERE Id = @AnimalId";
                SqlCommand sqlCommand = new SqlCommand(query, this.sqlConnection);
                this.sqlConnection.Open();
                sqlCommand.Parameters.AddWithValue("Name", ElementTextBox.Text);
                sqlCommand.Parameters.AddWithValue("AnimalId", ElementListBox_Animal.SelectedValue);
                sqlCommand.ExecuteScalar();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                this.sqlConnection.Close();
                this.ShowAnimals();
                this.ShowZooAnimal();
            }
        }
    }
}
