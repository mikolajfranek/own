﻿SELECT *
FROM [dbo].Animal as a
LEFT JOIN [dbo].ZooAnimal as za ON a.Id = za.AnimalId
LEFT JOIN [dbo].Zoo as z ON za.ZooId = z.Id
WHERE z.Location = 'New York'