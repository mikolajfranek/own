﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;


namespace Chapter_12_linq
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
            int[] numbers = new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
            OddNumbers(numbers);
            */

            UniversityManager universityManager = new UniversityManager();
            /*
            universityManager.MaleStudents();
            universityManager.FemaleStudents();
            universityManager.SortStudentByAge();
            universityManager.AllStudentsFromBeijingTech();

            Console.WriteLine("Write id of university");
            string input = Console.ReadLine();

            try
            {
                int inputAsInt = int.Parse(input);
                universityManager.AllStudentsFromUniversity(inputAsInt);
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception {0}", e.Message);
            }
           

            int[] someInts = { 30, 12, 3, 4, 12 };
            IEnumerable<int> sortedInts = from i in someInts orderby i select i;
            IEnumerable<int> reversedInts = sortedInts.Reverse();
            foreach(int i in reversedInts)
            {
                Console.WriteLine(i);
            }

            IEnumerable<int> reversedSortedInts = from i in someInts orderby i descending select i;
            foreach(int i in reversedSortedInts)
            {
                Console.WriteLine(i);
            }
            */


            /*
            universityManager.StudentAndUniversityNameCollection();
            */


            //We simply apply our Student-Structure to XML. 
            string studentsXML =
                        @"<Students>
                            <Student>
                                <Name>Toni</Name>
                                <Age>21</Age>
                                <University>Yale</University>
                                <Semester>6</Semester>
                            </Student>
                            <Student>
                                <Name>Carla</Name>
                                <Age>17</Age>
                                <University>Yale</University>
                                <Semester>1</Semester>
                            </Student>
                            <Student>
                                <Name>Leyla</Name>
                                <Age>19</Age>
                                <University>Beijing Tech</University>
                                <Semester>3</Semester>
                            </Student>
                            <Student>
                                <Name>Frank</Name>
                                <Age>25</Age>
                                <University>Beijing Tech</University>
                                <Semester>10</Semester>
                            </Student>
                        </Students>";

            XDocument studentsXdoc = new XDocument();
            studentsXdoc = XDocument.Parse(studentsXML);

            var students = from student in studentsXdoc.Descendants("Student")
                           orderby student.Element("Age").Value
                           select new
                           {
                               Name = student.Element("Name").Value,
                               Age = student.Element("Age").Value,
                               University = student.Element("University").Value,
                               Semester = student.Element("Semester").Value
                           };
            foreach(var student in students)
            {
                Console.WriteLine("Student {0}, age {1} from university {2} on semester {3}",
                    student.Name, student.Age, student.University, student.Semester);
            }


            Console.ReadKey();
        }

        static void OddNumbers(int[] numbers)
        {
            Console.WriteLine("Odd numbers:");
            IEnumerable<int> oddNumbers = from number in numbers where number % 2 != 0 select number;
            Console.WriteLine(oddNumbers);
            foreach(int i in oddNumbers)
            {
                Console.WriteLine(i);
            }
        }
    }
}
