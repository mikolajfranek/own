﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter_12_linq
{
    class UniversityManager
    {
        public List<University> universities;
        public List<Student> students;

        public UniversityManager()
        {
            universities = new List<University>();
            students = new List<Student>();

            //Let's add some Universities
            universities.Add(new University { Id = 1, Name = "Yale" });
            universities.Add(new University { Id = 2, Name = "Beijing Tech" });

            //Let's add some Students
            students.Add(new Student { Id = 1, Name = "Carla", Gender = "female", Age = 17, UniversityId = 1 });
            students.Add(new Student { Id = 2, Name = "Toni", Gender = "male", Age = 21, UniversityId = 1 });
            students.Add(new Student { Id = 3, Name = "Frank", Gender = "male", Age = 22, UniversityId = 2 });
            students.Add(new Student { Id = 4, Name = "Leyla", Gender = "female", Age = 19, UniversityId = 2 });
            students.Add(new Student { Id = 5, Name = "James", Gender = "trans-gender", Age = 25, UniversityId = 2 });
            students.Add(new Student { Id = 6, Name = "Linda", Gender = "female", Age = 22, UniversityId = 2 });
        }

        public void MaleStudents()
        {
            IEnumerable<Student> maleStudents = from student in this.students where student.Gender == "male" select student;
            Console.WriteLine("Male students:");
            foreach(Student student in maleStudents)
            {
                student.Print();
            }
        }

        public void FemaleStudents()
        {
            IEnumerable<Student> femaleStudents = from student in this.students where student.Gender == "female" select student;
            Console.WriteLine("Female students:");
            foreach (Student student in femaleStudents)
            {
                student.Print();
            }
        }

        public void SortStudentByAge()
        {
            IEnumerable<Student> sortedStudents = from student in this.students orderby student.Age select student;
            Console.WriteLine("Students sorted by age:");
            foreach(Student student in sortedStudents)
            {
                student.Print();
            }
        }

        public void AllStudentsFromBeijingTech()
        {
            IEnumerable<Student> bjtStudents = from student in this.students
                                               join university in this.universities on student.UniversityId equals university.Id
                                               where university.Name == "Beijing Tech"
                                               select student;
            Console.WriteLine("Students from Beijing Tech");
            foreach(Student student in bjtStudents)
            {
                student.Print();
            }
        }

        public void AllStudentsFromUniversity(int universityId)
        {
            IEnumerable<Student> universityStudents = from student in this.students
                                               where student.UniversityId == universityId
                                               select student;
            Console.WriteLine("Students from {0}", universityId);
            foreach (Student student in universityStudents)
            {
                student.Print();
            }
        }

        public void StudentAndUniversityNameCollection()
        {
            var newCollection = from student in this.students
                                join university in this.universities on student.UniversityId equals university.Id
                                orderby student.Name
                                select new
                                {
                                    StudentName = student.Name,
                                    UniversityName = university.Name
                                };
            Console.WriteLine("New colleciton");
            foreach(var element in newCollection)
            {
                Console.WriteLine("Student {0} from university {1}", element.StudentName, element.UniversityName);
            }

        }
    }
}
