﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Chapter_12_linq_to_sql
{
    /// <summary>
    /// Logika interakcji dla klasy MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        LinqToSqlDataClassesDataContext dataContext;

        public MainWindow()
        {
            InitializeComponent(); 
            string connectionString = ConfigurationManager.ConnectionStrings["Chapter_12_linq_to_sql.Properties.Settings.franek_dbConnectionString"].ConnectionString;
            this.dataContext = new LinqToSqlDataClassesDataContext(connectionString);

            //InsertUniversities();
            //InsertStudents();
            //InsertLectures();

            //InsertStudentLectureAssociations();
            //GetUniversityOfTonie();
            //GetLecturesOfTonie();

            //GetAllStudentsFromYale();
            //GetAllUniversitiesWithTransGenders();

            //GetAllLecturesFromBeijingTech();
            //UpdateTonie();
            DeleteJames();

        }

        public void InsertUniversities()
        {
            this.dataContext.ExecuteCommand("DELETE FROM University");

            University university = new University();
            university.Name = "Yale";
            this.dataContext.University.InsertOnSubmit(university);


            university = new University();
            university.Name = "Beijing Tech";
            this.dataContext.University.InsertOnSubmit(university);

            this.dataContext.SubmitChanges();

            ElementDataGrid.ItemsSource = this.dataContext.University;
        }

        public void InsertStudents()
        {
            this.dataContext.ExecuteCommand("DELETE FROM Student");

            University yale = this.dataContext.University.First(x => x.Name.Equals("Yale"));

            List<Student> students = new List<Student>();            
            students.Add(new Student() { Name = "Carla", Gender = "Female", UniversityId = yale.Id });
            students.Add(new Student() { Name = "Tonie", Gender = "Male", University = yale });

            University beijingTech = this.dataContext.University.First(x => x.Name.Equals("Beijing Tech"));
            students.Add(new Student() { Name = "Leyle", Gender = "Female", University = beijingTech });
            students.Add(new Student() { Name = "James", Gender = "Trans-gender", University = beijingTech });

            this.dataContext.Student.InsertAllOnSubmit(students);

            this.dataContext.SubmitChanges();

            ElementDataGrid.ItemsSource = this.dataContext.Student;
        }
    
        public void InsertLectures()
        {
            this.dataContext.ExecuteCommand("DELETE FROM Lecture");

            this.dataContext.Lecture.InsertOnSubmit(new Lecture() { Name = "Math" });
            this.dataContext.Lecture.InsertOnSubmit(new Lecture() { Name = "History" });

            this.dataContext.SubmitChanges();

            ElementDataGrid.ItemsSource = this.dataContext.Lecture;
        }

        public void InsertStudentLectureAssociations()
        {
            this.dataContext.ExecuteCommand("DELETE FROM StudentLecture");

            Student carla = this.dataContext.Student.First(x => x.Name.Equals("Carla"));
            Student tonie = this.dataContext.Student.First(x => x.Name.Equals("Tonie"));
            Student leyle = this.dataContext.Student.First(x => x.Name.Equals("Leyle"));
            Student james = this.dataContext.Student.First(x => x.Name.Equals("James"));

            Lecture math = this.dataContext.Lecture.First(x => x.Name.Equals("Math"));
            Lecture history = this.dataContext.Lecture.First(x => x.Name.Equals("History"));

            this.dataContext.StudentLecture.InsertOnSubmit(new StudentLecture() { Student = carla, Lecture = math });
            this.dataContext.StudentLecture.InsertOnSubmit(new StudentLecture() { Student = tonie, Lecture = math });

            StudentLecture studentLectureToni = new StudentLecture();
            studentLectureToni.Student = tonie;
            studentLectureToni.LectureId = history.Id;
            this.dataContext.StudentLecture.InsertOnSubmit(studentLectureToni);

            this.dataContext.StudentLecture.InsertOnSubmit(new StudentLecture() { Student = leyle, Lecture = history });

            this.dataContext.SubmitChanges();

            ElementDataGrid.ItemsSource = this.dataContext.StudentLecture;
        }

        public void GetUniversityOfTonie()
        {
            Student tonie = this.dataContext.Student.First(x => x.Name.Equals("Tonie"));
            University university = tonie.University;

            List<University> universities = new List<University>();
            universities.Add(university);

            ElementDataGrid.ItemsSource = universities;
        }

        public void GetLecturesOfTonie()
        {
            Student tonie = this.dataContext.Student.First(x => x.Name.Equals("Tonie"));

            var tonieLecture = from element in tonie.StudentLecture select element.Lecture;

            ElementDataGrid.ItemsSource = tonieLecture;
        }

        public void GetAllStudentsFromYale()
        {
            var students = from student in this.dataContext.Student
                           where student.University.Name == "Yale"
                           select student;

            ElementDataGrid.ItemsSource = students;
        }

        public void GetAllUniversitiesWithTransGenders()
        {
            var transGendersUniversities = from student in this.dataContext.Student
                                           join university in this.dataContext.University on student.University equals university
                                           where student.Gender == "Trans-gender"
                                           select university;

            ElementDataGrid.ItemsSource = transGendersUniversities;
        }

        public void GetAllLecturesFromBeijingTech()
        {
            var lectures = from lecture in this.dataContext.Lecture
                           join studentLecture in this.dataContext.StudentLecture on lecture equals studentLecture.Lecture
                           join student in this.dataContext.Student on studentLecture.Student equals student
                           join univeristy in this.dataContext.University on student.University equals univeristy
                           where univeristy.Name.Equals("Beijing Tech")
                           select lecture;
            
            //shorter version
            /*
            var lectures = from studentLectures in this.dataContext.StudentLecture
                           join student in this.dataContext.Student on studentLectures.Student equals student
                           where student.University.Name == "Beijing Tech"
                           select studentLectures.Lecture;
            */

            ElementDataGrid.ItemsSource = lectures;
        }


        public void UpdateTonie()
        {
            Student tonie = this.dataContext.Student.FirstOrDefault(x => x.Name.Equals("Antonio"));
            tonie.Name = "Antonio";

            this.dataContext.SubmitChanges();

            ElementDataGrid.ItemsSource = dataContext.Student;
        }

        public void DeleteJames()
        {
            Student james = this.dataContext.Student.FirstOrDefault(x => x.Name.Equals("James"));
            this.dataContext.Student.DeleteOnSubmit(james);

            this.dataContext.SubmitChanges();

            ElementDataGrid.ItemsSource = dataContext.Student;
        }

    }
}
