﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Chapter_13_threads
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
            Console.WriteLine("Hello world 1");
            Thread.Sleep(1000);
            Console.WriteLine("Hello worgld 2");
            Console.WriteLine("Hello world 3");
            Console.WriteLine("Hello world 4");
            */

            /*
            new Thread(() =>
            {
                Thread.Sleep(1000);
                Console.WriteLine("Thread 1");
            }).Start();

            new Thread(() =>
            {
                Thread.Sleep(1000);
                Console.WriteLine("Thread 2");
            }).Start();

            new Thread(() =>
            {
                Thread.Sleep(1000);
                Console.WriteLine("Thread 3");
            }).Start();

            new Thread(() =>
            {
                Thread.Sleep(1000);
                Console.WriteLine("Thread 4");
            }).Start();

            Console.ReadKey();
            */


            /*
            var taskCompletionSource = new TaskCompletionSource<bool>();
            var thread = new Thread(() =>
            {
                Console.WriteLine($"Thread number: { Thread.CurrentThread.ManagedThreadId} started");
                Thread.Sleep(1000);
                taskCompletionSource.TrySetResult(true);
                Console.WriteLine($"Thread number: { Thread.CurrentThread.ManagedThreadId} ended");
            });
            
            thread.Start();
            var test = taskCompletionSource.Task.Result;

            Console.WriteLine("Task was done {0}", test);
            */


            /*
            new Thread(() =>
            {
                Thread.Sleep(1000);
                Console.WriteLine("Thread 4");
            })
            { IsBackground = true }.Start();


            Enumerable.Range(0, 1000).ToList().ForEach(x => {

                ThreadPool.QueueUserWorkItem((o) =>
                {
                    Console.WriteLine($"Thread number: { Thread.CurrentThread.ManagedThreadId} started");
                    Thread.Sleep(1000);
                    Console.WriteLine($"Thread number: { Thread.CurrentThread.ManagedThreadId} ended");
                });
                //not clear data in thread local storage


                
                //new Thread(() => {
                    //Console.WriteLine($"Thread number: { Thread.CurrentThread.ManagedThreadId} started");
                    //Thread.Sleep(1000);
                    //Console.WriteLine($"Thread number: { Thread.CurrentThread.ManagedThreadId} ended");
                //}).Start();
            });
            */



            Console.WriteLine("Main thread started");

            Thread thread_1 = new Thread(Thread1Function);
            Thread thread_2 = new Thread(Thread2Function);

            thread_1.Start();
            thread_2.Start();

            //blocking main thread
            //thread_1.Join();
            //Console.WriteLine("Thread_1_Function done");
     

            if (thread_1.Join(1000))
            {
                Console.WriteLine("Thread_1_Function done");
            }
            else
            {
                Console.WriteLine("Thread_1_Function wasnt't done within 1 sec");
            }
            
            thread_2.Join();
            Console.WriteLine("Thread_2_Function done");

            for(int i = 0; i < 10; i++)
            {
                if (thread_1.IsAlive)
                {
                    //still running
                    Console.WriteLine("Thread1 is still doing stuff");
                }
                else
                {
                    Console.WriteLine("Thread1 copleted");
                }
                Thread.Sleep(300);
            }
         

            Console.WriteLine("Main thread ended");
            Console.ReadKey();
        }

        public static void Thread1Function()
        {
            Console.WriteLine("Thread_1_Function start");
            Thread.Sleep(3000);
            Console.WriteLine("Thread_1_Function comming back to caller");
        }

        public static void Thread2Function()
        {
            Console.WriteLine("Thread_2_Function start");
        }

    }
}
