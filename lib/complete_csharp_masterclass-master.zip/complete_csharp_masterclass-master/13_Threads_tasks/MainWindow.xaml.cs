﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Chapter_13_threads_tasks
{
    /// <summary>
    /// Logika interakcji dla klasy MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public static readonly DependencyProperty HtmlProperty = DependencyProperty.RegisterAttached(
            "Html",
            typeof(string),
            typeof(MainWindow),
            new FrameworkPropertyMetadata(OnHtmlChanged)
            );

        public MainWindow()
        {
            InitializeComponent();
        }

        private async void Element_MyButton_Click(object sender, RoutedEventArgs e)
        {
            /*
            Task.Run(() =>
            {
               Debug.WriteLine($"Thread nr {Thread.CurrentThread.ManagedThreadId}");
               HttpClient httpClient = new HttpClient();
               string html = httpClient.GetStringAsync("https://google.com").Result;


               Element_MyButton.Dispatcher.Invoke(() =>
               {
                   Debug.WriteLine($"Thread nr {Thread.CurrentThread.ManagedThreadId} owns my button");
                   Element_MyButton.Content = "Done";
               });
           });
           */
            string my_html = "";
            Debug.WriteLine($"Thread nr {Thread.CurrentThread.ManagedThreadId}");
            await Task.Run(async () =>
            {
                Debug.WriteLine($"Thread nr {Thread.CurrentThread.ManagedThreadId}");
                HttpClient httpClient = new HttpClient();
                my_html = httpClient.GetStringAsync("https://google.com").Result;
            });

            Debug.WriteLine($"Thread nr {Thread.CurrentThread.ManagedThreadId}");
            Element_MyButton.Content = "Done downloading";

            Element_WebBrowser.SetValue(HtmlProperty, my_html);
        }

        static void OnHtmlChanged(DependencyObject dependencyObject, DependencyPropertyChangedEventArgs e)
        {
            WebBrowser webBrowser = dependencyObject as WebBrowser;
            if(webBrowser != null)
            {
                webBrowser.NavigateToString(e.NewValue as string);
            }
        }


    }
}
