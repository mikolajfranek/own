﻿using System;
using System.Linq;

namespace _Zasady_projektowania_SOLID
{
    public class Badania
    {
        /*
        public Badania(Relacje relacje)
        {
            relacje.powiazania
                .Where(x => x.Item1.Nazwa.Equals("Mikolaj") && x.Item2 == Relacja.RODZIC).ToList()
                .ForEach(x =>
            {
                Console.WriteLine($"Mikolaj ma dziecko o imieniu {x.Item3.Nazwa}");
            });
        }
        */

        public Badania(IWyszukiwarkaRelacji wyszukiwarkaRelacji)
        {
            foreach(var p in wyszukiwarkaRelacji.WyszukajWszystkieDzieciDanejOsoby("Mikolaj"))
            {
                Console.WriteLine($"Mikolaj ma dziecko o imieniu {p.Nazwa}");
            }
        }
    }
}
