﻿using System;
namespace _Zasady_projektowania_SOLID
{
    public class Dokument
    {
        public Dokument()
        {
        }
    }
}
