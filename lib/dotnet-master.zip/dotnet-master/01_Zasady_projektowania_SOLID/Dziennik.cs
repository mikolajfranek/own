﻿using System;
using System.Collections.Generic;

namespace _Zasady_projektowania_SOLID
{
    public class Dziennik
    {
        private readonly List<string> wpisy = new List<string>();
        private static int licznik = 0;

        public void DodajWpis(string text)
        {
            wpisy.Add($"{++licznik}: {text}");
        }

        public void UsunWpis(int index)
        {
            wpisy.RemoveAt(index);
        }

        public override string ToString()
        {
            string result = "";
            wpisy.ForEach(x =>
            {
                result += $"{x}\n";
            });
            return result;
        }
    }
}
