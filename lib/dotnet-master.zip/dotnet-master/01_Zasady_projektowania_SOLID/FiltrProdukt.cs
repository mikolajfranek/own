﻿using System;
using System.Collections.Generic;

namespace _Zasady_projektowania_SOLID
{
    public class FiltrProdukt
    {
        public IEnumerable<Produkt> FiltrujPoprzezKolor(IEnumerable<Produkt> produkty, Kolor kolor)
        {
            foreach (var p in produkty)
            {
                if (p.Kolor == kolor)
                {
                    yield return p;
                }
            }
        }


        public IEnumerable<Produkt> FiltrujPoprzezRozmiar(IEnumerable<Produkt> produkty, Rozmiar rozmiar)
        {
            foreach (var p in produkty)
            {
                if (p.Rozmiar == rozmiar)
                {
                    yield return p;
                }
            }
        }


        public IEnumerable<Produkt> FiltrujPoprzezKolorOrazRozmiar(IEnumerable<Produkt> produkty, Kolor kolor, Rozmiar rozmiar)
        {
            foreach (var p in produkty)
            {
                if (p.Kolor == kolor && p.Rozmiar == rozmiar)
                {
                    yield return p;
                }
            }
        }
    }
}
