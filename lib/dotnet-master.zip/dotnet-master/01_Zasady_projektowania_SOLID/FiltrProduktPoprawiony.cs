﻿using System;
using System.Collections.Generic;

namespace _Zasady_projektowania_SOLID
{
    public class FiltrProduktPoprawiony : IFiltr<Produkt>
    {
        public IEnumerable<Produkt> Filtruj(IEnumerable<Produkt> produkty, Specyfikacja<Produkt> specyfikacja)
        {
            foreach (var p in produkty)
            {
                if (specyfikacja.CzyJestZgodny(p))
                {
                    yield return p;
                }
            }
        }
    }
}
