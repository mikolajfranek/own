﻿using System;
namespace _Zasady_projektowania_SOLID
{
    public interface IDrukarka
    {
        void Drukuj(Dokument d);
    }
}
