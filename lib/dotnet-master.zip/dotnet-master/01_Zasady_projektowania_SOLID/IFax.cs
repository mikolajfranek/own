﻿using System;
namespace _Zasady_projektowania_SOLID
{
    public interface IFax
    {
        void Faxuj(Dokument d);
    }
}
