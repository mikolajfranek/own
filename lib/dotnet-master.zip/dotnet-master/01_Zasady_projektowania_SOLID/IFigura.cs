﻿using System;
namespace _Zasady_projektowania_SOLID
{
    public interface IFigura
    {
        int Szerokosc { get; set; }
        int Wysokosc { get; set; }

        int Pole { get; }
    }
}
