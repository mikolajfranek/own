﻿using System;
using System.Collections.Generic;

namespace _Zasady_projektowania_SOLID
{
    public interface IFiltr<T>
    {
        IEnumerable<T> Filtruj(IEnumerable<T> elementy, Specyfikacja<T> specyfikacja);
    }
}
