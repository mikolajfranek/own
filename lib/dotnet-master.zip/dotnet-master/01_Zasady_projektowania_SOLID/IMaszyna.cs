﻿using System;
namespace _Zasady_projektowania_SOLID
{
    public interface IMaszyna
    {
        void Drukuj(Dokument d);
        void Faxuj(Dokument d);
        void Skanuj(Dokument d);
    }
}
