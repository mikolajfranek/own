﻿using System;
namespace _Zasady_projektowania_SOLID
{
    public interface ISkaner
    {
        void Skanuj(Dokument d);
    }
}
