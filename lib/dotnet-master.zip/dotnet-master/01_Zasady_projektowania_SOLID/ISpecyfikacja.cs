﻿using System;
namespace _Zasady_projektowania_SOLID
{
    public interface ISpecyfikacja<T>
    {
        bool CzyJestZgodny(T element);
    }
}
