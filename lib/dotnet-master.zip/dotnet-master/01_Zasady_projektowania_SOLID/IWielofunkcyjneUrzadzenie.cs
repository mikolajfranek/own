﻿using System;
namespace _Zasady_projektowania_SOLID
{
    public interface IWielofunkcyjneUrzadzenie : ISkaner, IDrukarka, IFax
    {
        //implementacja
    }
}
