﻿using System.Collections.Generic;

namespace _Zasady_projektowania_SOLID
{
    public interface IWyszukiwarkaRelacji
    {
        IEnumerable<Osoba> WyszukajWszystkieDzieciDanejOsoby(string nazwa);
    }
}
