﻿using System;
namespace _Zasady_projektowania_SOLID
{
    public enum Kolor
    {
        CZERWONY, ZIELONY, NIEBIESKI
    }
}
