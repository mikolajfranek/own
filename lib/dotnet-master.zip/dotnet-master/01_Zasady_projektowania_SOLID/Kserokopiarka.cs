﻿using System;
namespace _Zasady_projektowania_SOLID
{
    public class Kserokopiarka : IDrukarka, ISkaner
    {
        public Kserokopiarka()
        {
        }

        public void Drukuj(Dokument d)
        {
            //implementacja
        }

        public void Skanuj(Dokument d)
        {
            //implementacja
        }
    }
}
