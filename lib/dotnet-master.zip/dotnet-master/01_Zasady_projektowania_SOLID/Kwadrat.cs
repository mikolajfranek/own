﻿using System;
namespace _Zasady_projektowania_SOLID
{
    public class Kwadrat : Prostokat
    {
        //przysłonięcie setterów
        public new int Szerokosc
        {
            get => base.Szerokosc;
            set { base.Szerokosc = base.Wysokosc = value; }
        }
        public new int Wysokosc
        {
            get => base.Wysokosc;
            set { base.Szerokosc = base.Wysokosc = value; }
        }

        public Kwadrat(int rozmiar)
        {
            Szerokosc = Wysokosc = rozmiar;
        }
    }
}
