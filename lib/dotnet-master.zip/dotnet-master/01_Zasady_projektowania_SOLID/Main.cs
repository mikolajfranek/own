﻿using System;
using System.Collections.Generic;

namespace _Zasady_projektowania_SOLID
{
    class MainClass
    {
        public static void UzyskajPole(Prostokat prostokat)
        {
            prostokat.Wysokosc = 10;
            Console.WriteLine($"Oczekiwano {10 * prostokat.Szerokosc}, uzyskano {prostokat.Pole}");

            if (prostokat.GetType() == typeof(Prostokat))
            {
                //przetwarzaj prostokąt
                prostokat.Wysokosc = 10;
                Console.WriteLine($"Oczekiwano {10 * prostokat.Szerokosc}, uzyskano {prostokat.Pole}\n");
            }
            else if (prostokat.GetType() == typeof(Kwadrat))
            {
                //przetwarzaj kwadrat
                ((Kwadrat)prostokat).Wysokosc = 10;
                Console.WriteLine($"Oczekiwano {10 * prostokat.Szerokosc}, uzyskano {prostokat.Pole}\n");
            }
        }

        public static void Main(string[] args)
        {
            /*
            * SRP - Zasada pojedynczej odpowiedzialności
            * 
            * każda klasa jest odpowiedzialna tylko za jedną rzecz, zatem istnieje jeden powód do jej modyfikacji
            *            
            * przykład: nie należy dodawać metody zapisywania dziennika do klasy dziennika
            */

            /*
            var d = new Dziennik();
            d.DodajWpis("Zjadłem pająka.");
            d.DodajWpis("Kupiłem rower.");

            var m = new MenadzerDysku();
            m.ZapiszDoPliku(d, "/home/ubuntu/dziennik.txt", true);
            */





            /*
            * OCP - Zasada otwarty-zamknięty
            *            
            * funkcjonalność powinna być otwarta na rozszerzenia, ale zamknięta na modyfikacje
            * nie powinno być potrzeby do wracania do kodu, który został już napisany i przetestowany
            * 
            * przykład: dodanie nowej metody filtrowania polega na skorzystaniu z napisanych już wcześniej interfejsóœ
            */

            /*
            List<Produkt> produkty = new List<Produkt>()
            {
                new Produkt("produkt 1", Kolor.CZERWONY, Rozmiar.MALY),
                new Produkt("produkt 2", Kolor.NIEBIESKI, Rozmiar.SREDNI),
                new Produkt("produkt 3", Kolor.ZIELONY, Rozmiar.WIELKI),
                new Produkt("produkt 4", Kolor.CZERWONY, Rozmiar.OGROMNY),
            };

            FiltrProdukt filtr = new FiltrProdukt();
            foreach(var p in filtr.FiltrujPoprzezKolor(produkty, Kolor.NIEBIESKI))
            {
                Console.WriteLine($"{p}\n");
            }

            FiltrProduktPoprawiony filtrPoprawiony = new FiltrProduktPoprawiony();
            foreach (var p in filtrPoprawiony.Filtruj(produkty, new SpecyfikacjaOperatorAnd<Produkt>(new SpecyfikacjaKolor(Kolor.CZERWONY), new SpecyfikacjaRozmiar(Rozmiar.OGROMNY))))
            {
                Console.WriteLine($"{p}\n");
            }

            foreach (var p in filtrPoprawiony.Filtruj(produkty, new SpecyfikacjaKolor(Kolor.CZERWONY) & new SpecyfikacjaRozmiar(Rozmiar.OGROMNY)))
            {
                Console.WriteLine($"{p}\n");
            }

            foreach(var p in filtrPoprawiony.Filtruj(produkty, Kolor.CZERWONY.And(Rozmiar.OGROMNY)))
            {
                Console.WriteLine($"{p}\n");
            }
            */





            /*
            * LSP - Zasada podstawiania Liskov
            *
            * jeśli interfejs akceptuje obiekt typu Rodzic to powinien przyjmować obiekt typu Dziecko
            * 
            * klasa dziedzicząca powinna tylko rozszerzać możliwości klasy bazowej i w pewnym sensie nie zmieniać tego, co ona robiła już wcześniej
            * 
            * wywoływanie metody, która pierwotnie zdefiniowano w klasie bazowej, powinna dać te same rezultaty
            * 
            * przykład: zastosowanie Run-Time Type Information RTTI w celu rozpoznania typu obiektu, a następnie wywołanie funkcji, która wykonuje operację na danym obiekcie
            */

            /*
            UzyskajPole(new Prostokat(2, 3));
            UzyskajPole(new Kwadrat(5));
            */





            /*
            * ISP - Zasada segregacji interfesów 
            *
            * interfejsy należy rozdzielić tak, aby imlementatorzy mogli wybrać je w zależności od potrzeb
            * 
            * przykład: drukowanie i skanowanie to różne operacje (skaner nie może drukować), stąd powinno zdefiniować dla nich osobne interfesy
            * WielofunkcyjnaDrukarka (która tylko drukuje) ma widoczne metody do faxowania i skanowania (implementacja jest myląca)            
            * 
            * WielofunkcyjnaMaszyna - prosta implementacja wykorzystująca interfejsy (użycie prostej delegaty - jest to przykład wzorca Dekorator)
            */

            /*
            WielofunkcyjneUrzadzenie wielofunkcyjneUrzadzenie = new WielofunkcyjneUrzadzenie();
            //wystąpi błąd kopilacji w przypadku użycia Faxuj (metoda nie jest przestarzała, tylko jest nie zaimplementowana)
            //wielofunkcyjneUrzadzenie.Faxuj(new Dokument()); 
            */





            /*
            * DIP - Zasada odwracania zależności
            *
            * wysokopoziomowe moduły nie powinny zależeć od modułów niskiego poziomu, i jedne i drugie powinny zależeć od abstrakcji 
            * abstrakcja nie powinna zależeć od szczegółów, to szczegóły powinny zależeć od abstrakcji
            *
            * przykład: Badania naruszają DIP, ponieważ klasa Badania zależy od klasy Relacje
            * jest to złe bo implementacja Badania zależy od składowania danych w klasie Relacje (co jak w przyszłości dane zamiast w liście krotej byłyby przechowywane w bazie danych?)
            */

            Relacje relacje = new Relacje();
            relacje.DodajRodzicaOrazDziecko(rodzic: new Osoba() { Nazwa = "Mikolaj" }, dziecko: new Osoba() { Nazwa = "Jan" });
            relacje.DodajRodzicaOrazDziecko(rodzic: new Osoba() { Nazwa = "Klaudia" }, dziecko: new Osoba() { Nazwa = "Janek" });
            relacje.DodajRodzicaOrazDziecko(rodzic: new Osoba() { Nazwa = "Mikolaj" }, dziecko: new Osoba() { Nazwa = "Alojzy" });

            Badania badania = new Badania(relacje);
        }
    }
}
