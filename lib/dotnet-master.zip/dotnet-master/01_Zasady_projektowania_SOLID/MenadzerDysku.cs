﻿using System;
using System.IO;

namespace _Zasady_projektowania_SOLID
{
    public class MenadzerDysku
    {
        public void ZapiszDoPliku(Dziennik dziennik, string sciezkaDoPliku, bool nadpisz = false)
        {
            if (nadpisz || !File.Exists(sciezkaDoPliku))
            {
                File.WriteAllText(sciezkaDoPliku, dziennik.ToString());
            }
        }
    }
}
