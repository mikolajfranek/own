﻿using System;
namespace _Zasady_projektowania_SOLID
{
    public class Osoba
    {
        public string Nazwa { get; set; }

        public Osoba()
        {

        }
    }
}
