﻿using System;
namespace _Zasady_projektowania_SOLID
{
    public class Produkt
    {
        public string Nazwa;
        public Kolor Kolor;
        public Rozmiar Rozmiar;

        public Produkt(string nazwa, Kolor kolor, Rozmiar rozmiar)
        {
            this.Nazwa = nazwa;
            this.Kolor = kolor;
            this.Rozmiar = rozmiar;
        }

        public override string ToString()
        {
            return $"{Nazwa} jest koloru {Kolor} oraz ma rozmiar {Rozmiar}";
        }
    }
}
