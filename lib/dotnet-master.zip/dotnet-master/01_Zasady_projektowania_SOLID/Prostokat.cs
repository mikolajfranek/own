﻿using System;
namespace _Zasady_projektowania_SOLID
{
    public class Prostokat 
    {
        public int Szerokosc { get; set; }
        public int Wysokosc { get; set; }

        public int Pole { get => Szerokosc * Wysokosc; }

        public bool CzyJestKwadratem => Szerokosc == Wysokosc;

        public Prostokat() {}

        public Prostokat(int szerokosc, int wysokosc)
        {
            Szerokosc = szerokosc;
            Wysokosc = wysokosc;
        }
    }
}
