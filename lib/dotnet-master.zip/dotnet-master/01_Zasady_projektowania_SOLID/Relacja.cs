﻿using System;
namespace _Zasady_projektowania_SOLID
{
    public enum Relacja
    {
        RODZIC, DZIECKO, RODZENSTWO
    }
}
