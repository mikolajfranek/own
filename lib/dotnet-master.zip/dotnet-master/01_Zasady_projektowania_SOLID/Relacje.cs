﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _Zasady_projektowania_SOLID
{
    public class Relacje : IWyszukiwarkaRelacji
    {
        private List<(Osoba, Relacja, Osoba)> powiazania = new List<(Osoba, Relacja, Osoba)>();

        public void DodajRodzicaOrazDziecko(Osoba rodzic, Osoba dziecko)
        {
            powiazania.Add((rodzic, Relacja.RODZIC, dziecko));
            powiazania.Add((dziecko, Relacja.DZIECKO, rodzic));
        }

        public IEnumerable<Osoba> WyszukajWszystkieDzieciDanejOsoby(string nazwa)
        {
            return powiazania
               .Where(x => x.Item1.Nazwa.Equals(nazwa) && x.Item2 == Relacja.RODZIC)
               .Select(x => x.Item3);
        }

        public Relacje()
        {
        }
    }
}
