﻿using System;
namespace _Zasady_projektowania_SOLID
{
    public enum Rozmiar
    {
        MALY, SREDNI, WIELKI, OGROMNY
    }
}
