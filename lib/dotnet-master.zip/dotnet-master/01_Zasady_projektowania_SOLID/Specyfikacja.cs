﻿using System;
namespace _Zasady_projektowania_SOLID
{
    public abstract class Specyfikacja<T>
    {
        public abstract bool CzyJestZgodny(T element);

        public static Specyfikacja<T> operator &(Specyfikacja<T> pierwsza, Specyfikacja<T> druga)
        {
            return new SpecyfikacjaOperatorAnd<T>(pierwsza, druga);
        }
    }
}
