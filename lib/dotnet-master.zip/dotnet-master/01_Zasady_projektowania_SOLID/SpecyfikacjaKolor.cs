﻿using System;
namespace _Zasady_projektowania_SOLID
{
    public class SpecyfikacjaKolor : Specyfikacja<Produkt>
    {
        private Kolor kolor;

        public SpecyfikacjaKolor(Kolor kolor)
        {
            this.kolor = kolor;
        }

        public override bool CzyJestZgodny(Produkt element)
        {
            return element.Kolor == this.kolor;
        }
    }
}
