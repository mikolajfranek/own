﻿using System;
namespace _Zasady_projektowania_SOLID
{
    public class SpecyfikacjaOperatorAnd<T> : Specyfikacja<T>
    {
        private readonly Specyfikacja<T> pierwsza, druga;

        public SpecyfikacjaOperatorAnd(Specyfikacja<T> pierwsza, Specyfikacja<T> druga)
        {
            this.pierwsza = pierwsza;
            this.druga = druga;
        }

        public override bool CzyJestZgodny(T element)
        {
            return pierwsza.CzyJestZgodny(element) && druga.CzyJestZgodny(element);
        }
    }
}
