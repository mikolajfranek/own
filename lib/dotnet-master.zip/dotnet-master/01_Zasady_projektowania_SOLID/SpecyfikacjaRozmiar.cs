﻿using System;
namespace _Zasady_projektowania_SOLID
{
    public class SpecyfikacjaRozmiar : Specyfikacja<Produkt>
    {
        private Rozmiar rozmiar;

        public SpecyfikacjaRozmiar(Rozmiar rozmiar)
        {
            this.rozmiar = rozmiar;
        }

        public override bool CzyJestZgodny(Produkt element)
        {
            return element.Rozmiar == this.rozmiar;
        }
    }
}
