﻿using System;
namespace _Zasady_projektowania_SOLID
{
    public static class SpecyfikacjaRozszerzenia
    {
        public static SpecyfikacjaOperatorAnd<Produkt> And(this Kolor kolor, Rozmiar rozmiar)
        {
            return new SpecyfikacjaOperatorAnd<Produkt>(
                new SpecyfikacjaKolor(kolor),
                new SpecyfikacjaRozmiar(rozmiar)
            );
        }
    }
}
