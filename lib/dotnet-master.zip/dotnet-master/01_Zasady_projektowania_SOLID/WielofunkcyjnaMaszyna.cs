﻿using System;
namespace _Zasady_projektowania_SOLID
{
    public class WielofunkcyjnaMaszyna : IWielofunkcyjneUrzadzenie
    {
        private IDrukarka drukarka;
        private ISkaner skaner;
        private IFax fax;

        public WielofunkcyjnaMaszyna(IDrukarka drukarka, ISkaner skaner, IFax fax)
        {
            this.drukarka = drukarka;
            this.skaner = skaner;
            this.fax = fax;
        }

        public void Drukuj(Dokument d)
        {
            drukarka.Drukuj(d);
        }

        public void Faxuj(Dokument d)
        {
            fax.Faxuj(d);
        }

        public void Skanuj(Dokument d)
        {
            skaner.Skanuj(d);
        }
    }
}
