﻿using System;
namespace _Zasady_projektowania_SOLID
{
    public class WielofunkcyjneUrzadzenie : IMaszyna
    {
        public WielofunkcyjneUrzadzenie() 
        {
        }

        public void Drukuj(Dokument d)
        {
            //implementacja
        }

        [Obsolete("Nieobsługiwane", true)]
        public void Faxuj(Dokument d)
        {
            throw new NotImplementedException();
        }

        public void Skanuj(Dokument d)
        {
            //pozostawienie metody pustej
        }
    }
}
