﻿using System;

namespace _Perspektywa_funkcyjna
{
    class MainClass
    {
        public delegate int OperacjaArytmetyczne(int a, int b);

        public static int Odejmowanie(int a, int b) => a - b;

        public static void Main(string[] args)
        {
            /*
             * Definiowanie własnych delegatów nie jest konieczne
             * BCL jest dostarczana z predefiniowanymi delegatmi o maksymalnej długości 16 parametrów
             */

            //tworzenie nowej funkcji w metodzie - tego rodzaju funkcje nazywane są funkcjami anonimowymi
            OperacjaArytmetyczne egzemplarzDelegata = (a, b) => a * b;
            Console.WriteLine($"Wynik mnozenia to {egzemplarzDelegata(2, 4)}");

            egzemplarzDelegata = Odejmowanie;
            Console.WriteLine($"Wynik odejmowania to {egzemplarzDelegata(2, 4)}");

            int Dodawanie(int a, int b) => a + b;
            egzemplarzDelegata = Dodawanie;
            Console.WriteLine($"Wynik dodawania to {egzemplarzDelegata(2, 4)}");


            //delegat Action<T1, T2, ... TN>
            Action wykonaj = () => Console.WriteLine("Wykonuję");
            wykonaj();
            Action<string> wyswietl = x => Console.WriteLine(x);
            wyswietl("Wyświetl");

            //delegat Func<T1, T2, ... TR> - gdzie TR określa typ zwracanej wartości
            Func<int, int, int> dodaj = Dodawanie;
            Console.WriteLine($"Wynik dodawania to {dodaj(2, 4)}");

            //delegatów nie można wywnioskować za pomocą mechanizmu wnioskowania
            //var przyklad = (int a, int b) => a / b;
        }
    }
}
