﻿using System.Collections.Generic;
using System.Text;

namespace _Budowniczy
{
    class ApiElementHtml
    {
        protected string Nazwa, Wartosc;
        protected List<ApiElementHtml> Potomkowie = new List<ApiElementHtml>();
        protected ApiElementHtml() { }
        protected ApiElementHtml(string nazwa, string wartosc)
        {
            Nazwa = nazwa;
            Wartosc = wartosc;
        }

        public override string ToString()
        {
            StringBuilder rezultat = new StringBuilder();
            rezultat.AppendFormat("<{0}>", Nazwa);
            if(string.IsNullOrEmpty(Wartosc) == false)
            {
                rezultat.Append(Wartosc);
            }
            foreach (var potomek in Potomkowie)
            {
                rezultat.Append(potomek.ToString());
            }
            rezultat.AppendFormat("</{0}>", Nazwa);
            return rezultat.ToString();
        }

        //klasa budowniczego
        public class ApiBudowniczyHtml
        {
            protected ApiElementHtml tag = new ApiElementHtml();
            public ApiBudowniczyHtml(string nazwaTagu)
            {
                tag.Nazwa = nazwaTagu;
            }
            public void DodajPotomka(string nazwaPotomka, string wartoscPotomka)
            {
                tag.Potomkowie.Add(new ApiElementHtml(nazwaPotomka, wartoscPotomka));
            }
            public ApiBudowniczyHtml DodajPotomkaPlynnie(string nazwaPotomka, string wartoscPotomka)
            {
                tag.Potomkowie.Add(new ApiElementHtml(nazwaPotomka, wartoscPotomka));
                return this;
            }
            public override string ToString() => tag.ToString();

            //operator konwersji niejawnej
            public static implicit operator ApiElementHtml(ApiBudowniczyHtml budowniczy) => budowniczy.tag;
        }

        //metoda fabryczna
        public static ApiBudowniczyHtml Utworz(string nazwaTagu) => new ApiBudowniczyHtml(nazwaTagu);
    }
}
