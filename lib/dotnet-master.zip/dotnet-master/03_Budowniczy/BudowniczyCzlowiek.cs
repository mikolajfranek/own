﻿using System;
namespace _Budowniczy
{
    public abstract class BudowniczyCzlowiek
    {
        protected Czlowiek czlowiek = new Czlowiek();
        public Czlowiek Zbuduj()
        {
            return czlowiek;
        }
    }
}
