﻿using System;
namespace _Budowniczy
{
    public class BudowniczyCzlowiekDataUrodziny<T> : BudowniczyCzlowiekPraca<BudowniczyCzlowiekDataUrodziny<T>>
    where T : BudowniczyCzlowiekDataUrodziny<T>
    {
        public T Urodzony(string dataUrodzenia)
        {
            czlowiek.DataUrodzenia = dataUrodzenia;
            return (T)this;
        }
    }
}
