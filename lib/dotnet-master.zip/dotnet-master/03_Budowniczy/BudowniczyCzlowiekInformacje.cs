﻿using System;
namespace _Budowniczy
{
    public class BudowniczyCzlowiekInformacje<T> : BudowniczyCzlowiek
    where T : BudowniczyCzlowiekInformacje<T>
    {
        public T Nazywany(string nazwa)
        {
            czlowiek.Nazwa = nazwa;
            return (T)this;
        }
    }
}
