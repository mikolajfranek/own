﻿using System;
namespace _Budowniczy
{
    public class BudowniczyCzlowiekPraca<T> : BudowniczyCzlowiekInformacje<BudowniczyCzlowiekPraca<T>>
    where T : BudowniczyCzlowiekPraca<T>
    {
        public T PracujeNaStanowisku(string stanowisko)
        {
            czlowiek.Stanowisko = stanowisko;
            return (T) this;
        }
    }
}
