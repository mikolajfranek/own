﻿namespace _Budowniczy
{
    public class BudowniczyHtml
    {
        protected ElementHtml tag = new ElementHtml();
        public BudowniczyHtml(string nazwaTagu)
        {
            tag.Nazwa = nazwaTagu;
        }
        public void DodajPotomka(string nazwaPotomka, string wartoscPotomka)
        {
            tag.Potomkowie.Add(new ElementHtml(nazwaPotomka, wartoscPotomka));
        }
        public BudowniczyHtml DodajPotomkaPlynnie(string nazwaPotomka, string wartoscPotomka)
        {
            tag.Potomkowie.Add(new ElementHtml(nazwaPotomka, wartoscPotomka));
            return this;
        }
        public override string ToString() => tag.ToString();

        //operator konwersji niejawnej
        public static implicit operator ElementHtml(BudowniczyHtml budowniczy) => budowniczy.tag;
    }
}
