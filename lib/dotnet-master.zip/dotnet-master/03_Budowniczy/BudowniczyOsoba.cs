﻿using System;
namespace _Budowniczy
{
    public class BudowniczyOsoba
    {
        //przetrzymywanie referencji
        protected Osoba osoba; 

        public BudowniczyOsoba() => osoba = new Osoba();
        protected BudowniczyOsoba(Osoba osoba) => this.osoba = osoba;

        public BudowniczyOsobaDom Mieszka => new BudowniczyOsobaDom(osoba);
        public BudowniczyOsobaPraca Pracuje => new BudowniczyOsobaPraca(osoba);
        public static implicit operator Osoba(BudowniczyOsoba pb)
        {
            return pb.osoba;
        }
    }
}
