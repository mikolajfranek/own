﻿using System;
namespace _Budowniczy
{
    public class BudowniczyOsobaDom : BudowniczyOsoba
    {
        public BudowniczyOsobaDom(Osoba osoba) : base(osoba)
        {
            this.osoba = osoba;
        }
        public BudowniczyOsobaDom NaUlicy(string ulica)
        {
            osoba.Ulica = ulica;
            return this;
        }
        public BudowniczyOsobaDom ZKodemPocztowym(string kodPocztowy)
        {
            osoba.KodPocztowy = kodPocztowy;
            return this;
        }
        public BudowniczyOsobaDom WMiejscowosci(string miejscowosc)
        {
            osoba.Miejscowosc = miejscowosc;
            return this;
        }
    }
}
