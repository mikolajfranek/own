﻿using System;
namespace _Budowniczy
{
    public class BudowniczyOsobaPraca : BudowniczyOsoba
    {
        public BudowniczyOsobaPraca(Osoba osoba) : base(osoba)
        {
            this.osoba = osoba;
        }
        public BudowniczyOsobaPraca WFirmie(string nazwaFirmy)
        {
            osoba.NazwaFirmy = nazwaFirmy;
            return this;
        }
        public BudowniczyOsobaPraca NaStanowisku(string stanowisko)
        {
            osoba.Stanowisko = stanowisko;
            return this;
        }
        public BudowniczyOsobaPraca ZPensja(int pensja)
        {
            osoba.Pensja = pensja;
            return this;
        }
    }
}
