﻿using System;
namespace _Budowniczy
{
    public class Czlowiek
    {
        public class Budowniczy : BudowniczyCzlowiekDataUrodziny<Budowniczy> {}

        public string Nazwa;
        public string Stanowisko;
        public string DataUrodzenia;
        public static Budowniczy Nowy => new Budowniczy();

        public override string ToString()
        {
            return $"Człowiek {Nazwa} pracuje na stanowisku {Stanowisko} urodzony {DataUrodzenia}";
        }
    }
}
