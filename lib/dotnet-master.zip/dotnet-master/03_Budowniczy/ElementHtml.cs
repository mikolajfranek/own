﻿using System.Collections.Generic;
using System.Text;

namespace _Budowniczy
{
    public class ElementHtml
    {
        public string Nazwa, Wartosc;
        public List<ElementHtml> Potomkowie = new List<ElementHtml>();
        public ElementHtml() { }
        public ElementHtml(string nazwa, string wartosc)
        {
            Nazwa = nazwa;
            Wartosc = wartosc;
        }

        public override string ToString()
        {
            StringBuilder rezultat = new StringBuilder();
            rezultat.AppendFormat("<{0}>", Nazwa);
            if(string.IsNullOrEmpty(Wartosc) == false)
            {
                rezultat.Append(Wartosc);
            }
            foreach (var potomek in Potomkowie)
            {
                rezultat.Append(potomek.ToString());
            }
            rezultat.AppendFormat("</{0}>", Nazwa);
            return rezultat.ToString();
        }

        //metoda fabryczna
        public static BudowniczyHtml Utworz(string nazwaTagu) => new BudowniczyHtml(nazwaTagu);
    }
}
