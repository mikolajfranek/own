﻿using System;
namespace _Budowniczy
{
    public class Email
    {
        public string Od, Do, Temat, Tresc;

        public override string ToString()
        {
            return $"Wiadomosc od {Od} do {Do} z tematem {Temat} i treścią {Tresc}";
        }
    }
}
