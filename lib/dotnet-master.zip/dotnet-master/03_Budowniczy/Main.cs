﻿using System;
using System.Text;

namespace _Budowniczy
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            /*
             * Budowniczy - dotyczy tworzenia złożonych obiektów
             * tzn. takich, których nie można zbudować w jednowierszowym wywołaniu konstruktora
             * 
             * Budowniczy próbuje zlecić konstrukcję obiektu z części osobnej klasie            
             *             
             * poniżej "nadinżynieria"            
             * 
             * różnica StringBuilder vs konkatenacja stringów:
             * - StringBuilder => alokuje bufor i zapełnia go dodawanymi ciągami 
             * - kontaktenacja => tworzy wiele tymczasowych ciągów (tzn. wiele buforów)
             */
            var witaj = "witaj";
            var sb = new StringBuilder();
            sb.Append("<p>");
            sb.Append(witaj);
            sb.Append("</p>");
            Console.WriteLine(sb);


            var slowa = new[] { "witaj", "świecie" };
            sb.Clear();
            sb.Append("<ul>");
            foreach(var slowo in slowa)
            {
                sb.AppendFormat("<li>{0}</li>", slowo);
            }
            sb.Append("</ul>");
            Console.WriteLine(sb);


            var tag = new ElementHtml("ul", null);
            foreach(var slowo in slowa)
            {
                tag.Potomkowie.Add(new ElementHtml("li", slowo));
            }
            Console.WriteLine(tag);


            /*
             * Prosty budowniczy
             */
            var budowniczy = new BudowniczyHtml("ul");
            budowniczy.DodajPotomka("li", "witaj");
            budowniczy.DodajPotomka("li", "świecie");
            Console.WriteLine(budowniczy);


            /*
             * Płynny budowniczy
             */
            var budowniczyPlynny = new BudowniczyHtml("ul");
            budowniczyPlynny.DodajPotomkaPlynnie("li", "witaj").DodajPotomkaPlynnie("li", "świecie");
            Console.WriteLine(budowniczy);


            /*
             * Wymuszenie skorzystania z budowniczego poprzez ukrycie konstruktorów
             * Wykorzystanie operatora konwersji niejawnej        
             */
            ApiElementHtml apiElementHtml = ApiElementHtml.Utworz("ul")
                                                .DodajPotomkaPlynnie("li", "witaj")
                                                .DodajPotomkaPlynnie("li", "świecie");
            Console.WriteLine(apiElementHtml);


            /*
             * Złożony budowniczy
             */
            var budowniczyOsoba = new BudowniczyOsoba();
            Osoba osoba = budowniczyOsoba
                .Mieszka
                    .NaUlicy("Kartkowa 12")
                    .WMiejscowosci("Ohaio")
                    .ZKodemPocztowym("12-421")
                .Pracuje
                    .WFirmie("The best")
                    .NaStanowisku("Programista")
                    .ZPensja(10000);
            Console.WriteLine(osoba);


            /*
             * Parametry budowniczego
             */
            SerwisEmail serwisEmail = new SerwisEmail();
            serwisEmail.WyslijEmail(email => email.Od("mikolaj").Do("klaudii").Temat("hi hey").Tresc("hello"));


            /*
             * Dziedziczenie płynnego interfejsu
             */
            Czlowiek czlowiek = Czlowiek.Nowy
                            .Nazywany("mikolaj")
                            .PracujeNaStanowisku("informatyk")
                            .Urodzony("1995")
                            .Zbuduj();
            Console.WriteLine(czlowiek);
        }
    }
}
