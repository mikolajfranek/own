﻿using System;
namespace _Budowniczy
{
    public class Osoba
    {
        public string Ulica, KodPocztowy, Miejscowosc;

        public string NazwaFirmy, Stanowisko;
        public int Pensja;

        public override string ToString()
        {
            return $"Osoba mieszka na ulicy {Ulica} w miejscowości {Miejscowosc} z kodem pocztowym {KodPocztowy}\n" +
                    $"Pracuje w firmie {NazwaFirmy} na stanowisku {Stanowisko} z pensją {Pensja}";
        }
    }
}
