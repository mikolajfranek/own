﻿using System;
namespace _Budowniczy
{
    public class SerwisEmail
    {
        public class BudowniczyEmail
        {
            private readonly Email email;
            public BudowniczyEmail(Email email) => this.email = email;
            public BudowniczyEmail Od(string _od)
            {
                email.Od = _od;
                return this;
            }
            public BudowniczyEmail Do(string _do)
            {
                email.Do = _do;
                return this;
            }
            public BudowniczyEmail Temat(string _temat)
            {
                email.Temat = _temat;
                return this;
            }
            public BudowniczyEmail Tresc(string _tresc)
            {
                email.Tresc = _tresc;
                return this;
            }
        }

        private void WyslijEmailWewnetrznie(Email email)
        {
            Console.WriteLine(email);
        }

        public void WyslijEmail(Action<BudowniczyEmail> budowniczy)
        {
            Email email = new Email();
            budowniczy(new BudowniczyEmail(email));
            WyslijEmailWewnetrznie(email);
        }
    }
}
