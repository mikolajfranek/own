﻿using System;
namespace _Fabryki
{
    public interface EmptyInterface
    {
    }
}
