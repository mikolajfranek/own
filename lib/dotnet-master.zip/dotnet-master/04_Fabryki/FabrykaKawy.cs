﻿using System;
namespace _Fabryki
{
    public class FabrykaKawy : InterfejsFabrykaGoracyNapoj
    {
        public InterfejsGoracyNapoj Przygotuj(int iloscMiliLitrow)
        {
            Console.WriteLine($"Wsyp kawę, wlej {iloscMiliLitrow} wrzątku wody, pitnego!");
            return new Kawa();
        }
    }
}
