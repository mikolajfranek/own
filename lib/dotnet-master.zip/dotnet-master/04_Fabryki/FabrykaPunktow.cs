﻿using System;
namespace _Fabryki
{
    public class FabrykaPunktow
    {
        public static Punkt NowyKartezjanskiPunkt(double x, double y)
        {
            return new Punkt(x, y);
        }

        public static Punkt NowyBiegunowyPunkt(double r, double t)
        {
            return new Punkt(r * Math.Cos(t), r * Math.Sin(t));
        }
    }
}
