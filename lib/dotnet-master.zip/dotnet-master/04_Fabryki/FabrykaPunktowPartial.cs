﻿using System;
namespace _Fabryki
{
    public partial class PunktPartial
    {
        public static class FabrykaPunktowPartial
        {
            public static PunktPartial NowyKartezjanskiPunkt(double x, double y)
            {
                return new PunktPartial(x, y);
            }

            public static PunktPartial NowyBiegunowyPunkt(double r, double t)
            {
                return new PunktPartial(r * Math.Cos(t), r * Math.Sin(t));
            }
        }
    }
}
