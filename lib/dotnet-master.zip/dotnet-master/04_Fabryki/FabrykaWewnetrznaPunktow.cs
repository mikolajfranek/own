﻿using System;
namespace _Fabryki
{
    public class FabrykaWewnetrznaPunktow
    {
        public FabrykaWewnetrznaPunktow()
        {
        }
    }
}
