﻿using System;
namespace _Fabryki
{
    public class Herbata : InterfejsGoracyNapoj
    {
        public void Konsumuj()
        {
            Console.WriteLine("Herbata jest dobra, bardzo dobra.");
        }
    }
}
