﻿using System;
namespace _Fabryki
{
    public interface InterfejsFabrykaGoracyNapoj
    {
        InterfejsGoracyNapoj Przygotuj(int iloscMiliLitrow);
    }
}
