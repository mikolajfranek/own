﻿using System;
namespace _Fabryki
{
    public interface InterfejsGoracyNapoj
    {
        void Konsumuj();
    }
}
