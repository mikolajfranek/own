﻿using System;
namespace _Fabryki
{
    public class Kawa : InterfejsGoracyNapoj
    {
        public void Konsumuj()
        {
            Console.WriteLine("Kawa jest zbyt gorzka, wolę na słodko.");
        }
    }
}
