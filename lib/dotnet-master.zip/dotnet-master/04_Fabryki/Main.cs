﻿using System;

namespace _Fabryki
{
    class MainClass
    {
        public InterfejsGoracyNapoj PrzygotujNapoj(string typ)
        {
            switch (typ)
            {
                case "kawa":
                    return new FabrykaKawy().Przygotuj(100);
                default:
                    throw new ArgumentException("Niezlokalizowany typ napoju");
            }
        }

        public static void Main(string[] args)
        {
            /*
             * Metoda fabrykująca
             */
            Punkt punkt = Punkt.NowyKartezjanskiPunkt(1, 2);
            Console.WriteLine(punkt);

            /*
             * Fabryka
             */
            Punkt punkt1 = FabrykaPunktow.NowyKartezjanskiPunkt(2, 3);
            Console.WriteLine(punkt1);

            /*
             * Fabryka wewnetrzna
             */
            Punkt punkt2 = Punkt.FabrykaWewnetrzna.NowyKartezjanskiPunkt(3, 4);
            Console.WriteLine(punkt2);

            /*
             * Separacja logiczna
             * Skorzystanie ze słowa kluczowego 'partial'            
             */
            PunktPartial punkt3 = PunktPartial.FabrykaPunktowPartial.NowyKartezjanskiPunkt(4, 5);
            Console.WriteLine(punkt3);

            /*
             * Fabryka abstrakcyjna
             * MaszynaGoracyNapoj przechowuje referencje do fabryk napojów            
             */
            MaszynaGoracyNapoj maszynaGoracyNapoj = new MaszynaGoracyNapoj();
            InterfejsGoracyNapoj kawa = maszynaGoracyNapoj.WybierzMaszyneDoKawy().Przygotuj(250);
            kawa.Konsumuj();
        }
    }
}
