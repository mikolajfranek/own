﻿using System;
namespace _Fabryki
{
    public class MaszynaGoracyNapoj
    {
        protected InterfejsFabrykaGoracyNapoj fabrykaGoracyNapoj;

        public InterfejsFabrykaGoracyNapoj WybierzMaszyneDoKawy()
        {
            fabrykaGoracyNapoj = new FabrykaKawy();
            return fabrykaGoracyNapoj;
        }
    }
}
