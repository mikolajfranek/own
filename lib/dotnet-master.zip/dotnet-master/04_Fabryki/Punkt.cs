﻿using System;
namespace _Fabryki
{
    public class Punkt
    {
        private double x, y;

        /*
         * dla metod fabrykujących, wewnetrznej klasy fabryka - konstruktor może być protected/private
         */
        public Punkt(double x, double y)
        {
            this.x = x;
            this.y = y;
        }

        /*
         * Fabryka wewnetrzna
         */
        public static class FabrykaWewnetrzna
        {
            public static Punkt NowyKartezjanskiPunkt(double x, double y)
            {
                return new Punkt(x, y);
            }
        }
        /*
         * Metody fabrykujące
         */
        public static Punkt NowyKartezjanskiPunkt(double x, double y)
        {
            return new Punkt(x, y);
        }
        public static Punkt NowyBiegunowyPunkt(double r, double t)
        {
            return new Punkt(r * Math.Cos(t), r * Math.Sin(t));
        }

        public override string ToString()
        {
            return $"Pozycja x:{x}\tPozycja y:{y}";
        }
    }
}
