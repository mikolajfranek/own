﻿using System;
namespace _Fabryki
{
    public partial class PunktPartial
    {
        private double x, y;

        private PunktPartial(double x, double y)
        {
            this.x = x;
            this.y = y;
        }

        public override string ToString()
        {
            return $"Pozycja x:{x}\tPozycja y:{y}";
        }
    }
}
