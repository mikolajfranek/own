﻿using System;
namespace _Fabryki
{
    public enum UkladWspolrzednych
    {
        KARTEZJANSKI, BIEGUNOWY
    }
}
