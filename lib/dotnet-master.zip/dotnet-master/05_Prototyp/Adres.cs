﻿using System;
namespace _Prototyp
{
    [Serializable]
    public class Adres : InterfejsGlebokieKopiowanie<Adres>
    {
        public string Ulica;
        public int NumerDomu;
        public int Apartament;
        public Adres()
        {
        }
        public Adres(Adres adres)
        {
            this.Ulica = adres.Ulica;
            this.NumerDomu = adres.NumerDomu;
            this.Apartament = adres.Apartament;
        }
        public Adres(string ulica, int numerDomu, int apartament)
        {
            this.Ulica = ulica;
            this.NumerDomu = numerDomu;
            this.Apartament = apartament;
        }
        public Adres GlebokieKopiowanie()
        {
            var adres = new Adres();
            adres.Ulica = this.Ulica;
            adres.NumerDomu = this.NumerDomu;
            adres.Apartament = this.Apartament;
            return adres;
        }
        public override string ToString()
        {
            return $"Mieszka na ulicy {Ulica} w domu o numerze {NumerDomu} w apartamencie {Apartament}";
        }
    }
}
