﻿using System;
namespace _Prototyp
{
    public static class FabrykaPracownikow
    {
        private static Osoba centrum = new Osoba(null, new Adres("Towarowa", 12, 0));
        private static Osoba biuro = new Osoba(null, new Adres("Kolejowa", 13, 0));

        public static Osoba NowyPracownikCentrum(string nazwa, int apartament) => NowyPracownik(centrum, nazwa, apartament);
        public static Osoba NowyPracownikBiuro(string nazwa, int apartament) => NowyPracownik(biuro, nazwa, apartament);

        private static Osoba NowyPracownik(Osoba proto, string nazwa, int apartament)
        {
            var copy = proto.GlebokieKopiowanie();
            copy.Nazwa = nazwa;
            copy.Adres.Apartament = apartament;
            return copy;
        }
    }
}
