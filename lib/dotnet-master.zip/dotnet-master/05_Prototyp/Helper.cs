﻿using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Xml.Serialization;

namespace _Prototyp
{
    public static class Helper
    {
        public static T SerializacjaBinarnaGlebokieKopiowanie<T>(this T self)
        {
            using (var stream = new MemoryStream())
            {
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                binaryFormatter.Serialize(stream, self);
                stream.Seek(0, SeekOrigin.Begin);
                object copy = binaryFormatter.Deserialize(stream);
                return (T)copy;
            }
        }
        public static T SerializacjaXMLGlebokieKopiowanie<T>(this T self)
        {
            string pathFile = "/home/ubuntu/test.xml";
            using (var memoryStream = new MemoryStream())
            {
                XmlSerializer xmlSerializer = new XmlSerializer(typeof(T));
                xmlSerializer.Serialize(memoryStream, self);
                memoryStream.Position = 0;
                File.WriteAllBytes(pathFile, memoryStream.ToArray());
                return (T)xmlSerializer.Deserialize(memoryStream);
            }
        }
    }
}
