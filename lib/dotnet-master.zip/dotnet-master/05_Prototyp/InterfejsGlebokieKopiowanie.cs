﻿using System;
namespace _Prototyp
{
    public interface InterfejsGlebokieKopiowanie<T>
    {
        T GlebokieKopiowanie();
    }
}
