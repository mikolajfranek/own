﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Serialization;

namespace _Prototyp
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            /*
             * Głęboka kopia obiektów
             */
            var jan = new Osoba("Jan Kowalski", new Adres("Liściowa", 2, 1));
            var janina = (Osoba)jan.GlebokieKopiowanie();
             janina.Nazwa = "Janina Nowak";
            janina.Adres.NumerDomu = 99;
            Console.WriteLine(jan);
            Console.WriteLine(janina);

            /*
             * DateTime - głęboka kopia
             */
            var dt1 = new DateTime(2016, 1, 1);
            var dt2 = dt1;

            /*
             * string - głęboka kopia
             */
            string s1 = "witaj";
            string s2 = s1; 
            s2 = "świecie"; 
            Console.WriteLine(s1); //witaj

            /*
             * Skorzystanie z konstruktora kopiującego - głęboka kopia dla typów NIE referencyjnych
             */
            var d1 = new Dictionary<string, int>
            {
                ["abc"] = 1,
                ["cde"] = 2
            };
            var d2 = new Dictionary<string, int>(d1);
            d2["abc"] = 55;
            Console.WriteLine(d1["abc"]); //1

            /*
             * Typ referencyjny - kopiowanie głębokie musi zostać wykonane dla każdego elementu
             */
            var d3 = new Dictionary<string, Adres>
            {
                ["nowak"] = new Adres
                {
                    NumerDomu = 44,
                    Ulica = "Liściasta"
                }
            };
            //Zakomentowany kod poniżej nie zadziała prawidłowo
            //var d4 = new Dictionary<string, Adres>(d3);
            //d4["nowak"].NumerDomu = 222;
            //Console.WriteLine(d3["nowak"]); //222
            var d5 = d3.ToDictionary(x => x.Key, x => x.Value.GlebokieKopiowanie());
            Console.WriteLine(d3["nowak"]); //44

            /*
             *  Duplikacja za pomocą konstruktora kopiującego
             */
            var janina2 = new Osoba(jan);
            janina2.Nazwa = "Janina Nowak";
            janina2.Adres.NumerDomu = 321;
            Console.WriteLine(jan);
            Console.WriteLine(janina2);

            /*
             * Serializacja binarna - glębokie kopiowanie - każda klasa musi zostać oznaczona atrybutem [Serializable], aby nie było wyjątku
             */
            var janina3 = Helper.SerializacjaBinarnaGlebokieKopiowanie(jan);
            janina3.Nazwa = "Janina Nowak";
            janina3.Adres.NumerDomu = 432;
            Console.WriteLine(jan);
            Console.WriteLine(janina3);

            /*
             * Serializacja XML - uniwersalne głębokie kopiowanie
             */
            var janina4 = Helper.SerializacjaXMLGlebokieKopiowanie(jan);
            janina4.Nazwa = "Janina Nowak";
            janina4.Adres.NumerDomu = 534;
            Console.WriteLine(jan);
            Console.WriteLine(janina4);

            /*
             * Fabryka prototypów
             */
            var jan1 = FabrykaPracownikow.NowyPracownikCentrum("Jan Kowalski", 2);
            var janina5 = FabrykaPracownikow.NowyPracownikBiuro("Janina Nowak", 4);
            Console.WriteLine(jan1);
            Console.WriteLine(janina5);

            /*
             * Serializacja IDictionary
             */
            Panstwa panstwa = new Panstwa();
            var stolice = Helper.SerializacjaXMLGlebokieKopiowanie(panstwa);
            Console.WriteLine(stolice);
        }
    }
}
