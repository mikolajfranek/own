﻿using System;
namespace _Prototyp
{
    [Serializable]
    public class Osoba : InterfejsGlebokieKopiowanie<Osoba>
    {
        public string Nazwa;
        public Adres Adres;
        public Osoba()
        {
        }
        public Osoba(Osoba osoba)
        {
            this.Adres = new Adres(osoba.Adres);
            this.Nazwa = osoba.Nazwa;
        }
        public Osoba(string nazwa, Adres adres)
        {
            this.Nazwa = nazwa;
            Adres = adres;
        }
        public Osoba GlebokieKopiowanie()
        {
            var osoba = new Osoba();
            osoba.Nazwa = this.Nazwa;
            osoba.Adres = this.Adres.GlebokieKopiowanie();
            return osoba;
        }
        /*
         * Płytkie kopiowanie - w przypadku obiektu w klasie kopiowana jest referencja (obydwie oryginalna i skopiowana wersja) odnoszą się do tego samego obiektu
         */
        //public class Osoba : ICloneable
        /*
        public object Clone()
        {
            return (Osoba)this.MemberwiseClone();
        }
        */

        public override string ToString()
        {
            return $"{Nazwa} mieszka na ulicy {Adres.Ulica} w domu o numerze {Adres.NumerDomu}";
        }
    }
}
