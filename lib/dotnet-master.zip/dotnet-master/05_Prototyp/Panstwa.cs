﻿using System.Collections.Generic;
using System.Linq;
using System.Xml.Serialization;

namespace _Prototyp
{
    public class Panstwa
    {
        //Serializacja typu IDictionary (XmlSerializer nie może jej serializować - natomiast jest możliwa serializacja listy krotek)
        [XmlIgnore]
        public Dictionary<string, string> Stolice { get; set; } = new Dictionary<string, string>() { { "Polska", "Warszawa" } };

        public (string, string)[] StoliceSerializowane
        {
            get
            {
                return Stolice.Select(x => (x.Key, x.Value)).ToArray();
            }
            set
            {
                Stolice = value.ToDictionary(x => x.Item1, x => x.Item2);
            }
        }

        public override string ToString()
        {
            string rezultat = "";
            foreach(var stolica in Stolice)
            {
                rezultat += $"{stolica.Key} -> {stolica.Value}\n";
            }
            return rezultat;
        }
    }
}
