﻿namespace _Prototyp
{
    internal class XmlSerializer
    {
    }
}