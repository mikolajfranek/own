﻿using System;
using System.Collections.Generic;

namespace Singleton
{
    public class AtrapaBazaDanych : InterfejsBazaDanych
    {
        public int GetIloscPopulacji(string stolica)
        {
            return new Dictionary<string, int>
            {
                ["alpha"] = 1,
                ["beta"] = 2,
                ["gamma"] = 3
            }[stolica];
        }
    }
}
