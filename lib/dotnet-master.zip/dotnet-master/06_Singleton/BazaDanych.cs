﻿using System;
using System.Collections.Generic;

namespace Singleton
{
    public class BazaDanych : InterfejsBazaDanych
    {
        /// <summary>
        ///Nie skonstruuj więcej niż jednego egzemplarza.
        /// </summary>
        private BazaDanych(string typInstancji) 
        {
            Console.WriteLine($"Trwa inicjalizacja bazy danych - {typInstancji}");
            //TUTAJ umieszczenie danych do zmiennej 'stolice'
        }
        public static BazaDanych Instancja { get; } = new BazaDanych("statyczna");

        private static Lazy<BazaDanych> instancja = new Lazy<BazaDanych>(() => new BazaDanych("leniwa"));
        public static BazaDanych InstancjaLeniwa => instancja.Value;
        public static string TestowyNapis { get; } = "TestowyNapis";

        private Dictionary<string, int> stolice = new Dictionary<string, int>();
        public int GetIloscPopulacji(string stolica)
        {
            return stolice[stolica];
            throw new NotImplementedException();
            //Do wykonania ewentualne pobieranie rekordów z bazy danych
        }
    }
}
