﻿namespace Singleton
{
    public class DyrektorZarzadzajacy
    {
        private static string nazwa;
        private static int wiek;
        public string Nazwa
        {
            get => nazwa;
            set => nazwa = value;
        }
        public int Wiek
        {
            get => wiek;
            set => wiek = value;
        }
    }
}
