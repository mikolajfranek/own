﻿using System;
namespace Singleton
{
    public class DzisiejszaData : InterfejsData
    {
        private readonly InterfejsLogger logger;
        private int licznik = 0;
        public DzisiejszaData(InterfejsLogger logger)
        {
            this.logger = logger;
        }
        public void WypiszDate()
        {
            licznik += 1;
            this.logger.Zapisz($"{DateTime.Today.ToShortDateString()} --- {this.GetHashCode()} --- {licznik}");
        }
    }
}
