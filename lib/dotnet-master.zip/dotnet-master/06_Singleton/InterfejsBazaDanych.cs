﻿using System;
namespace Singleton
{
    public interface InterfejsBazaDanych
    {
        int GetIloscPopulacji(string stolica);
    }
}
