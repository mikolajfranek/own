﻿using System;
namespace Singleton
{
    public interface InterfejsData
    {
        void WypiszDate();
    }
}
