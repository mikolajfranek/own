﻿using System;
namespace Singleton
{
    public interface InterfejsLogger
    {
        void Zapisz(string tresc);
    }
}
