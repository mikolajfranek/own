﻿using System;
namespace Singleton
{
    public class LoggerKonsola : InterfejsLogger
    {
        public void Zapisz(string tresc)
        {
            Console.WriteLine(tresc);
        }
    }
}
