﻿using System;
using Autofac;

namespace Singleton
{
    class MainClass
    {
        private static IContainer Container { get; set; }

        private static void RegisterServices(ContainerBuilder builder)
        {
            //InstancePerDependency - w każdym 'bloku using' za każdym razem stworzy nową instancję
            //builder.RegisterType<LoggerKonsola>().As<InterfejsLogger>();
            //builder.RegisterType<DzisiejszaData>().As<InterfejsData>();

            //InstancePerLifetimeScope - w każdym 'bloku using' zwracany jest jeden i ten sam obiekt
            //builder.RegisterType<LoggerKonsola>().As<InterfejsLogger>().InstancePerLifetimeScope();
            //builder.RegisterType<DzisiejszaData>().As<InterfejsData>().InstancePerLifetimeScope();

            //SingleInstance - stworzenie singletona dla wszystkich 'bloków using' 
            builder.RegisterType<LoggerKonsola>().As<InterfejsLogger>().SingleInstance();
            builder.RegisterType<DzisiejszaData>().As<InterfejsData>().SingleInstance();
        }

        private static void PrepareIoC()
        {
            var builder = new ContainerBuilder();
            RegisterServices(builder);
            Container = builder.Build();
        }

        public static void Main(string[] args)
        {
            /*
             * Singleton - przy dostepnie do statycznej składowej tworzone są 'pierwszy raz' statyczne pola/właściwości
             */
            //var bazaDanych1 = BazaDanych.Instancja;
            Console.WriteLine(BazaDanych.TestowyNapis);
            var bazaDanych1 = BazaDanych.InstancjaLeniwa;

            /*
             * Rozwiązanie problemu testowania singletonów - skorzystanie z interfejsów - abstrakcja
             */
            var bazaDanych2 = new AtrapaBazaDanych();
            var poszukiwaczRekordu = new PoszukiwaczRekordu(bazaDanych2);
            Console.WriteLine(poszukiwaczRekordu.IloscPopulacji(new[] { "alpha", "gamma" }));

            /*
             * IoC - Inversion of Control
             */
            PrepareIoC();
            using (var scope = Container.BeginLifetimeScope())
            {
                var today1 = scope.Resolve<InterfejsData>();
                today1.WypiszDate();
                var today2 = scope.Resolve<InterfejsData>();
                today2.WypiszDate();
            }
            using (var scope = Container.BeginLifetimeScope())
            {
                var today1 = scope.Resolve<InterfejsData>();
                today1.WypiszDate();
                var today2 = scope.Resolve<InterfejsData>();
                today2.WypiszDate();
            }

            /*
            * Monostat - gettery i settery działają na danych statycznych
            */
            var dyrektor = new DyrektorZarzadzajacy();
            dyrektor.Nazwa = "Kowalski";
            dyrektor.Wiek = 55;
        }
    }
}
