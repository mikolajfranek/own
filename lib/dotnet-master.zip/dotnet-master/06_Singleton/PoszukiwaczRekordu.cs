﻿using System.Collections.Generic;

namespace Singleton
{
    public class PoszukiwaczRekordu
    {
        private InterfejsBazaDanych interfejsBazaDanych;
        public PoszukiwaczRekordu(InterfejsBazaDanych interfejsBazaDanych)
        {
            this.interfejsBazaDanych = interfejsBazaDanych;
        }
        public int IloscPopulacji(IEnumerable<string> nazwy)
        {
            int rezultat = 0;
            foreach (var nazwa in nazwy)
                rezultat += interfejsBazaDanych.GetIloscPopulacji(nazwa);
            return rezultat;
        }
    }
}
