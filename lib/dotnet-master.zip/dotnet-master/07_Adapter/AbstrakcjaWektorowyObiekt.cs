﻿using System.Collections.ObjectModel;

namespace _Adapter
{
    public abstract class AbstrakcjaWektorowyObiekt : Collection<Linia> {}
}
