﻿using System;
using System.Collections.ObjectModel;

namespace _Adapter
{
    public class AdapterLiniaNaPunkty : Collection<Punkt>
    {
        public AdapterLiniaNaPunkty(Linia linia)
        {
            Console.WriteLine($"Generowanie punktów na linii ({linia.Poczatek.X}, {linia.Poczatek.Y}) --> ({linia.Koniec.X}, {linia.Koniec.Y})");
            int lewo = Math.Min(linia.Poczatek.X, linia.Koniec.X);
            int prawo = Math.Max(linia.Poczatek.X, linia.Koniec.X);
            int gora = Math.Min(linia.Poczatek.Y, linia.Koniec.Y);
            int dol = Math.Max(linia.Poczatek.Y, linia.Koniec.Y);
            if (lewo == prawo)
            {
                for (int y = gora; y <= dol; y++)
                {
                    Add(new Punkt(lewo, y));
                }
            }
            else if (gora == dol)
            {
                for (int x = lewo; x <= prawo; x++)
                {
                    Add(new Punkt(x, gora));
                }
            }
        }
    }
}
