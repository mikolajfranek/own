using System;
using System.Collections.Generic;

namespace _Adapter
{
    public class AdapterLiniaNaPunktyBuforowanie 
    {
        static Dictionary<Linia, List<Punkt>> bufor = new Dictionary<Linia, List<Punkt>>();
        private Linia linia;

        public IEnumerator<Punkt> GetEnumerator()
        {
            Console.WriteLine($"Iterowanie {linia.GetHashCode()}");
            Przygotuj();
            return bufor[linia].GetEnumerator();
        }

        public void Przygotuj()
        {
            if (bufor.ContainsKey(linia))
            {
                Console.WriteLine("Linia znajduje się już w buforze");
                return;
            }
            List<Punkt> punkty = new List<Punkt>();
            int lewo = Math.Min(linia.Poczatek.X, linia.Koniec.X);
            int prawo = Math.Max(linia.Poczatek.X, linia.Koniec.X);
            int gora = Math.Min(linia.Poczatek.Y, linia.Koniec.Y);
            int dol = Math.Max(linia.Poczatek.Y, linia.Koniec.Y);
            if (lewo == prawo)
            {
                for (int y = gora; y <= dol; y++)
                {
                    punkty.Add(new Punkt(lewo, y));
                }
            }
            else if (gora == dol)
            {
                for (int x = lewo; x <= prawo; x++)
                {
                    punkty.Add(new Punkt(x, gora));
                }
            }
            bufor.Add(linia, punkty);
        }

        public AdapterLiniaNaPunktyBuforowanie(Linia linia)
        {
            Console.WriteLine($"Generowanie punktów na linii ({linia.Poczatek.X}, {linia.Poczatek.Y}) --> ({linia.Koniec.X}, {linia.Koniec.Y})");
            this.linia = linia;
        }
    }
}