﻿using System;
namespace _Adapter
{
    public class Linia
    {
        protected bool Equals(Linia other)
        {
            return Equals(Poczatek, other.Poczatek) && Equals(Koniec, other.Koniec);
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            if (ReferenceEquals(this, obj)) return true;
            if (obj.GetType() != this.GetType()) return false;
            return Equals((Linia) obj);
        }

        public override int GetHashCode()
        {
            unchecked
            {
                return ((Poczatek != null ? Poczatek.GetHashCode() : 0) * 397) ^ (Koniec != null ? Koniec.GetHashCode() : 0);
            }
        }

        public readonly Punkt Poczatek, Koniec;

        public Linia(Punkt poczatek, Punkt koniec)
        {
            Poczatek = poczatek;
            Koniec = koniec;
        }
    }
}
