﻿using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Xml.Serialization;

namespace _Adapter
{
    class MainClass
    {
        //Założenie, że jedynym interfejsem do rysowania jest 'rysowanie pixela'
        public static void RysujPunkt(Punkt punkt)
        {
            string pathFile = "/home/ubuntu/test.jpg";
            Image image = Image.FromFile(pathFile);
            Graphics graphics = Graphics.FromImage(image);
            graphics.FillRectangle(Brushes.Black, punkt.X, punkt.Y, 1, 1);
            image.Save(pathFile);
        }

        private static List<AbstrakcjaWektorowyObiekt> prostokaty = new List<AbstrakcjaWektorowyObiekt>
        {
            new WektorowyProstokat(200, 200, 100, 20),
            new WektorowyProstokat(150, 150, 200, 50),
            new WektorowyProstokat(150, 150, 200, 20)
        };

        private void NarysujProstokaty()
        {
            foreach (var prostokat in prostokaty)
            {
                foreach (var linia in prostokat)
                {
                    var adapter = new AdapterLiniaNaPunkty(linia);
                    foreach (var punkt in adapter)
                    {
                        RysujPunkt(punkt);
                    }
                }
            }
        }

        //Leniwa wersja metody ładowania punktów wraz z adapterem, który buforuje linie
        private static List<Punkt> punkty = new List<Punkt>();
        private static void Przygotuj()
        {
            foreach (var prostokat in prostokaty)
            {
                foreach (var linia in prostokat)
                {
                    var adapter = new AdapterLiniaNaPunktyBuforowanie(linia);
                    foreach (var punkt in adapter)
                    {
                        punkty.Add(punkt);
                    }
                }
            }
        }

        public static void Main(string[] args)
        {
            Przygotuj();
            foreach (var punkt in punkty)
            {
                RysujPunkt(punkt);
            }
        }
    }
}
