﻿namespace _Adapter
{
    public class WektorowyProstokat : AbstrakcjaWektorowyObiekt
    {
        public WektorowyProstokat(int x, int y, int szerokosc, int wysokosc)
        {
            Add(new Linia(new Punkt(x, y), new Punkt(x + szerokosc, y)));
            Add(new Linia(new Punkt(x + szerokosc, y), new Punkt(x + szerokosc, y + wysokosc)));
            Add(new Linia( new Punkt(x, y), new Punkt(x, y + wysokosc)));
            Add(new Linia(new Punkt(x, y + wysokosc),new Punkt(x + szerokosc, y + wysokosc)));
        }
    }
}
