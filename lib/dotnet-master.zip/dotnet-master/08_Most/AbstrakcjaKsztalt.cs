﻿namespace _Most
{
    public abstract class AbstrakcjaKsztalt
    {
        //Most
        protected InterfejsRenderowanie renderowanie;
        public AbstrakcjaKsztalt(InterfejsRenderowanie renderowanie)
        {
            this.renderowanie = renderowanie;
        }

        public abstract void Rysuj();
        public abstract void Rozszerz(float value);
    }
}
