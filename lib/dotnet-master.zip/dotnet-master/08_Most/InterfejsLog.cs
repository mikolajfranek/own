﻿using System;
namespace _Most
{
    public interface InterfejsLog
    {
        void Informacja(string value);
    }
}
