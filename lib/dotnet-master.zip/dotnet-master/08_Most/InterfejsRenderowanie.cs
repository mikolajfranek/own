﻿using System;
namespace _Most
{
    public interface InterfejsRenderowanie
    {
        void RenderujOkrag(float promien);
    }
}
