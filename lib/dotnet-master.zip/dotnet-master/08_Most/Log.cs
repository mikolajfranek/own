﻿using System;
namespace _Most
{
    public class Log : InterfejsLog
    {
        public void Informacja(string value)
        {
            Console.WriteLine($"Informacja --> {value}");
        }
    }
}
