﻿using System;
using Autofac;

namespace _Most
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            /*
             * Most - miedzy rysowanym ksztaltem a typem renderowaniem
             */
            var wektoroweRenderowanie = new WektoroweRenderowanie();
            var okrag1 = new Okrag(wektoroweRenderowanie, 5);
            okrag1.Rysuj();
            okrag1.Rozszerz(2);
            okrag1.Rysuj();

            /*
             * DI - wstrzykiwanie zależoności
             */
            var builder = new ContainerBuilder();
            builder.RegisterType<WektoroweRenderowanie>().As<InterfejsRenderowanie>();
            builder.Register((c, p) => new Okrag(c.Resolve<InterfejsRenderowanie>(), p.Positional<float>(0)));
            using (var scope = builder.Build())
            {
                var okrag2 = scope.Resolve<Okrag>(
                    new PositionalParameter(0, 6.0f)
                );
                okrag2.Rysuj();
                okrag2.Rozszerz(2);
                okrag2.Rysuj();
            }

            /*
             * Most do dynamicznego prototypowania
             * - aby móc zastąpić jeden typ podczas działania aplikacji innym (oba muszą implementować ten sam interfejs)
             */
            Rachunek rachunek = new Rachunek();
            rachunek.Log = new Log();
            rachunek.Log.Informacja("Koniec");
        }
    }
}
