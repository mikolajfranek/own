﻿namespace _Most
{
    public class Okrag : AbstrakcjaKsztalt
    {
        private float promien;
        public Okrag(InterfejsRenderowanie renderowanie, float promien) : base(renderowanie)
        {
            this.promien = promien;
        }

        public override void Rozszerz(float value)
        {
            this.promien *= value;
        }

        public override void Rysuj()
        {
            this.renderowanie.RenderujOkrag(promien);
        }
    }
}
