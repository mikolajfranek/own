﻿using System;
using Autofac;

namespace _Most
{
    public class Rachunek
    {
        //[Service]
        public InterfejsLog Log { get; set; }
    }
}
