﻿using System;
namespace _Most
{
    public class WektoroweRenderowanie : InterfejsRenderowanie
    {
        public void RenderujOkrag(float promien)
        {
            Console.WriteLine($"Rysowanie okragu o promieniu {promien}");
        }
    }
}
