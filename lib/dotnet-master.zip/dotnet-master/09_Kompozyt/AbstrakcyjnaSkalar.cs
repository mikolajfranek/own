﻿using System.Collections;
using System.Collections.Generic;

namespace _Kompozyt
{
    public abstract class AbstrakcyjnaSkalar<T> : IEnumerable<T>
    where T : AbstrakcyjnaSkalar<T>
    {
        public IEnumerator<T> GetEnumerator()
        {
            yield return (T)this;
        }
        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }
}
