﻿using System;
namespace _Kompozyt
{
    public class Foo : AbstrakcyjnaSkalar<Foo>
    {
        public Foo()
        {
        }
    }
}
