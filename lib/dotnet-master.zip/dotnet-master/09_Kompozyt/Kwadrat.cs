﻿using System;
namespace _Kompozyt
{
    public class Kwadrat : ObiektGraficzny
    {
        public override string Nazwa { get; set; } = "Kwadrat";
    }
}
