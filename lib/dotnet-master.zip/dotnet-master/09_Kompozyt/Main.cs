﻿using System;

namespace _Kompozyt
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            /*
             * Kompozyt - zapewnienie identycznych interfejsów dla pojedynczych obiektów i kolekcji obiektów           
             */
            var obiektGraficzny = new ObiektGraficzny { Nazwa = "Moj obiekt graficzny" };
            obiektGraficzny.Potomkowie.Add(new Kwadrat { Kolor = "Czarny" });
            obiektGraficzny.Potomkowie.Add(new Okrag { Kolor = "Zółty" });
            var grupa = new ObiektGraficzny();
            grupa.Potomkowie.Add(new Kwadrat { Kolor = "Szary" });
            grupa.Potomkowie.Add(new Okrag { Kolor = "Pomarańczowy" });
            obiektGraficzny.Potomkowie.Add(grupa);
            Console.WriteLine(obiektGraficzny);

            /*
             * Sieci neuronowe
             */
            var neuron1 = new Neuron();
            var neuron2 = new Neuron();
            var warstwa1 = new NeuronWarstwa(3);
            var warstwa2 = new NeuronWarstwa(5);

            neuron1.Polacz(neuron2);
            neuron1.Polacz(warstwa1);
            warstwa2.Polacz(neuron1);
            warstwa1.Polacz(warstwa2);

            /*
             * Opakowanie kompozytu - tworzenie z klasy 'skalarnej' kolekcje o jednej zmiennej
             */
            var foo = new Foo();
            foreach (var x in foo)
            {
                // zwróci tylko jedną wartość x
            }
        }
    }
}
