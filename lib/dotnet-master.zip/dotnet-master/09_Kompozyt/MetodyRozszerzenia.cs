﻿using System.Collections.Generic;

namespace _Kompozyt
{
    public static class MetodyRozszerzenia
    {
        public static void Polacz(this IEnumerable<Neuron> pierwszy, IEnumerable<Neuron> drugi)
        {
            if (ReferenceEquals(pierwszy, drugi)) return;
            foreach(var p in pierwszy)
            {
                foreach(var d in drugi)
                {
                    p.Wyjscie.Add(d);
                    d.Wejscie.Add(p);
                }
            }
        }
    }
}
