﻿using System.Collections;
using System.Collections.Generic;

namespace _Kompozyt
{
    public class Neuron : IEnumerable<Neuron>
    {
        public List<Neuron> Wejscie, Wyjscie;

        public Neuron()
        {
            Wejscie = new List<Neuron>();
            Wyjscie = new List<Neuron>();
        }

        public IEnumerator<Neuron> GetEnumerator()
        {
            yield return this;
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }
}
