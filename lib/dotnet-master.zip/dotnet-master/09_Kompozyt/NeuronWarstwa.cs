﻿using System.Collections.ObjectModel;

namespace _Kompozyt
{
    public class NeuronWarstwa : Collection<Neuron>
    {
        public NeuronWarstwa(int ilosc)
        {
            while (ilosc --> 0) 
            {
                Add(new Neuron());
            }
        }
    }
}
