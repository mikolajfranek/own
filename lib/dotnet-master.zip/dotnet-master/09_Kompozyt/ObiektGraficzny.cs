﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _Kompozyt
{
    public class ObiektGraficzny
    {
        public virtual string Nazwa { get; set; } = "Grupa";
        public string Kolor;

        private Lazy<List<ObiektGraficzny>> potomkowie = new Lazy<List<ObiektGraficzny>>();
        public List<ObiektGraficzny> Potomkowie => potomkowie.Value;

        private void Wyswietl(StringBuilder stringBuilder, int glebokosc)
        {
            stringBuilder
                .Append(new string('-', glebokosc))
                .Append(string.IsNullOrWhiteSpace(Kolor) ? string.Empty : $"{Kolor} ")
                .AppendLine($"{Nazwa}");
            foreach (var potomek in Potomkowie)
            {
                potomek.Wyswietl(stringBuilder, glebokosc + 1);
            }
        }
        public override string ToString()
        {
            StringBuilder stringBuilder = new StringBuilder();
            Wyswietl(stringBuilder, 0);
            return stringBuilder.ToString();
        }
    }
}
