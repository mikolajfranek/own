﻿using System;
namespace _Kompozyt
{
    public class Okrag : ObiektGraficzny
    {
        public override string Nazwa { get; set; } = "Okrag";
    }
}
