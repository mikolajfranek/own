﻿using System;
using System.Text;

namespace _Dekorator
{
    public class DekoratorStringBuilder
    {
        private StringBuilder stringBuilder = new StringBuilder();

        public DekoratorStringBuilder Append(string value)
        {
            stringBuilder.Append(value);
            return this;
        }

        public DekoratorStringBuilder AppendLine(string value)
        {
            stringBuilder.AppendLine(value);
            return this;
        }

        public static implicit operator DekoratorStringBuilder(string value)
        {
            var dekorator = new DekoratorStringBuilder();
            dekorator.stringBuilder.Append(value);
            return dekorator;
        }

        public static DekoratorStringBuilder operator +(DekoratorStringBuilder dekorator, string value)
        {
            dekorator.Append(value);
            return dekorator;
        }

        public override string ToString()
        {
            return stringBuilder.ToString();
        }
    }
}
