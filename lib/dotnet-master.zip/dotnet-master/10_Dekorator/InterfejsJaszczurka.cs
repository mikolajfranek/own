﻿using System;
namespace _Dekorator
{
    public interface InterfejsJaszczurka : InterfejsZwierze
    {
        void Pelzanie();
    }
}
