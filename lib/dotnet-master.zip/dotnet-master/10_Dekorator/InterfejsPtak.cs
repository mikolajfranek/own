﻿using System;
namespace _Dekorator
{
    public interface InterfejsPtak : InterfejsZwierze
    {
        void Latanie();
    }
}
