﻿using System;
namespace _Dekorator
{
    public interface InterfejsZwierze
    {
        int Wiek { get; set; }
    }
}
