﻿using System;
namespace _Dekorator
{
    public class Jaszczurka : InterfejsJaszczurka
    {
        public int Wiek { get; set; }

        public void Pelzanie()
        {
            if (Wiek <= 10)
            {
                Console.WriteLine("Umiem tylko pełzać");
            }
        }
    }
}
