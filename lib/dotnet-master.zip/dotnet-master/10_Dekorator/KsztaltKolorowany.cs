﻿namespace _Dekorator
{
    public class KsztaltKolorowany : Kształt
    {
        private readonly Kształt kształt;
        private readonly string kolor;
        public KsztaltKolorowany(Kształt kształt, string kolor)
        {
            this.kształt = kształt;
            this.kolor = kolor;
        }
        public override string AsString() => $"{kształt.AsString()} ma kolor {kolor}";
    }
}
