﻿using System;
namespace _Dekorator
{
    public class KsztaltKolorowanyStatyczny<T> : Kształt
    where T : Kształt, new()
    {
        private readonly T kształt = new T();
        private readonly string kolor;

        public KsztaltKolorowanyStatyczny() : this("biały") 
        { 
            //
        }
        public KsztaltKolorowanyStatyczny(string kolor)
        {
            this.kolor = kolor;
        }

        public override string AsString() => $"{kształt.AsString()} ma kolor {kolor}";
    }
}
