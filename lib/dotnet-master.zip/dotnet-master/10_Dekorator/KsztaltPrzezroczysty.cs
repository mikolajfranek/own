﻿using System;
namespace _Dekorator
{
    public class KsztaltPrzezroczysty : Kształt
    {
        private readonly Kształt kształt;
        private readonly float przezroczystosc;
        public KsztaltPrzezroczysty(Kształt kształt, float przezroczystosc)
        {
            this.kształt = kształt;
            this.przezroczystosc = przezroczystosc;
        }
        public override string AsString() => $"{kształt.AsString()} ma przezroczystość {przezroczystosc * 100.0f}%";
    }
}
