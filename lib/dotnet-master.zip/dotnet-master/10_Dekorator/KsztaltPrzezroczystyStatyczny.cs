﻿using System;
namespace _Dekorator
{
    public class KsztaltPrzezroczystyStatyczny<T> : Kształt
    where T : Kształt, new()
    {
        private readonly T kształt = new T();
        private readonly float przezroczystosc;

        public KsztaltPrzezroczystyStatyczny() : this(0.0f)
        {
            //
        }
        public KsztaltPrzezroczystyStatyczny(float przezroczystosc)
        {
            this.przezroczystosc = przezroczystosc;
        }

        public override string AsString() => $"{kształt.AsString()} ma przezroczystość {przezroczystosc * 100.0f}%";
    }
}
