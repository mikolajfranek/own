﻿namespace _Dekorator
{
    public abstract class Kształt
    {
        public virtual string AsString() => string.Empty;
    }
}
