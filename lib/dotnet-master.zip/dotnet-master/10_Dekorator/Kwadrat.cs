﻿using System;
namespace _Dekorator
{
    public class Kwadrat : Kształt
    {
        private float bok;
        public Kwadrat() : this(0) { }
        public Kwadrat(float bok)
        {
            this.bok = bok;
        }
        public void Rozszerz(float value)
        {
            bok *= value;
        }
        public override string AsString() => $"Kwadrat o boku {bok}";
    }
}
