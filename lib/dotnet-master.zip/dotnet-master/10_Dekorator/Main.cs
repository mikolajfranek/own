﻿using System;

namespace _Dekorator
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            /*
             * Dekorator
             */
            DekoratorStringBuilder dekorator = new DekoratorStringBuilder();
            dekorator.Append("Witaj").AppendLine(" świecie");
            Console.WriteLine(dekorator);

            /*
             * Adapter-Dekorator
             */
            dekorator += " --> Hello World";
            Console.WriteLine(dekorator);

            /*
             * Klasa Smok jako rozwiazanie 'diamentowego dziedziczenia'
             */
            Smok smok = new Smok(new Jaszczurka(), new Ptak());
            smok.Latanie();
            smok.Pelzanie();

            /*
             * Dynamiczna kompozycja dekoratora 
             */
            var okrag = new Okrag(10);
            Console.WriteLine(okrag.AsString());
            var niebieskiKsztalt = new KsztaltKolorowany(okrag, "niebieski");
            Console.WriteLine(niebieskiKsztalt.AsString());
            var przezroczysty = new KsztaltPrzezroczysty(niebieskiKsztalt, 0.2f);
            Console.WriteLine(przezroczysty.AsString());
            //brak dostępu to składowych
            //niebieskiKsztalt.Rozszerz(2);

            /*
             * Dekorator statyczny - przechwytywanie typu tworzonego obiektu
             */
            KsztaltKolorowanyStatyczny<Okrag> kolorowanyStatyczny = new KsztaltKolorowanyStatyczny<Okrag>("zielony");
            Console.WriteLine(kolorowanyStatyczny.AsString());
            KsztaltPrzezroczystyStatyczny<Kwadrat> przezroczystyStatyczny = new KsztaltPrzezroczystyStatyczny<Kwadrat>(0.4f);
            Console.WriteLine(przezroczystyStatyczny.AsString());
            //brak dostępu to składowych
            //kolorowanyStatyczny.Rozszerz(2);
        }
    }
}
