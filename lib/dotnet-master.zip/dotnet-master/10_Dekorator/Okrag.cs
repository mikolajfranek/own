﻿using System;
namespace _Dekorator
{
    public class Okrag : Kształt
    {
        private float promien;
        public Okrag() : this(0) {}
        public Okrag(float promien)
        {
            this.promien = promien;
        }
        public void Rozszerz(float value)
        {
            promien *= value;
        }
        public override string AsString() => $"Okrąg o promieniu {promien}";
    }
}
