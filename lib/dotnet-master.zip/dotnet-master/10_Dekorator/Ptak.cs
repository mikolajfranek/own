﻿using System;
namespace _Dekorator
{
    public class Ptak : InterfejsPtak
    {
        public int Wiek { get; set; }

        public void Latanie()
        {
            if (Wiek > 10)
            {
                Console.WriteLine("Umiem latać");
            }
        }
    }
}
