﻿using System;
namespace _Dekorator
{
    public class Smok : InterfejsPtak, InterfejsJaszczurka
    {
        private InterfejsJaszczurka jaszczurka;
        private InterfejsPtak ptak;

        public Smok(InterfejsJaszczurka jaszczurka, InterfejsPtak ptak)
        {
            this.jaszczurka = jaszczurka;
            this.ptak = ptak;
            this.jaszczurka.Wiek = this.ptak.Wiek;
        }

        public int Wiek { get => jaszczurka.Wiek; set => jaszczurka.Wiek = ptak.Wiek = value;}

        public void Latanie()
        {
            ptak.Latanie();
        }

        public void Pelzanie()
        {
            jaszczurka.Pelzanie();
        }
    }
}
