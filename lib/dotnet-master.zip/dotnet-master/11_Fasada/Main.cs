﻿using System;
using System.IO;
using System.Net;

namespace _Fasada
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            /*
             * Fasada to polega na utworzeniu prostego interfejsu do jednego/wielu bardziej skomplikowanych podsystemów           
             * WebClient jest fasadą
             */
            string url = "https://www.google.com/robots.txt";
            var webRequest = WebRequest.Create(url);
            webRequest.Credentials = CredentialCache.DefaultCredentials;
            var webResponse = webRequest.GetResponse();
            var stream = webResponse.GetResponseStream();
            var streamReader = new StreamReader(stream);
            string tresc1 = streamReader.ReadToEnd();
            Console.WriteLine(tresc1);
            streamReader.Close();
            webResponse.Close();

            string tresc2 = new WebClient().DownloadString(url);
            Console.WriteLine(tresc2);
        }
    }
}
