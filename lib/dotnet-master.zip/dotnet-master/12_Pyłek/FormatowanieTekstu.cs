﻿using System;
using System.Text;

namespace _Pyłek
{
    public class FormatowanieTekstu
    {
        private bool[] wielkaLitera;
        private string tekst;
        public FormatowanieTekstu(string tekst)
        {
            this.tekst = tekst;
            wielkaLitera = new bool[tekst.Length];
        }
        public void ZmienNaWielkaLitere(int start, int koniec)
        {
            for (int i = start; i <= koniec;  i++)
            {
                wielkaLitera[i] = true;
            }
        }
        public override string ToString()
        {
            var stringBuilder = new StringBuilder();
            for (var i = 0; i < wielkaLitera.Length; i++)
            {
                var c = tekst[i];
                stringBuilder.Append(wielkaLitera[i] ? char.ToUpper(c) : c);
            }
            return stringBuilder.ToString();
        }
    }
}
