﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _Pyłek
{
    class MainClass
    {
        public static string GetRandomString(int sizeOfString)
        {
            Random random = new Random();
            return new string(Enumerable.Range(0, sizeOfString).Select(i => (char)('a' + random.Next(26))).ToArray());
        }

        public static void Main(string[] args)
        {
            /*
             * Pyłek - indeks w klasie Osoba2 - niewielki obiekt o małej zajętości pamięci, który wskazuje na inny (większy obiekt), który jest przechowywany gdzie indziej
             * 
             * Nazwy użytkowników
             * 
             * Implementacja Osoba2 > Osoba1, posiada ona (Osoba2) identyfikatory wskazujące na zapisaną/zapamiętaną wartość co pozwala zaoszczędzić pamięć            
             */
            var osoby = new List<Osoba2>();
            for (int i = 0; i < 100; i++)
            {
                osoby.Add(new Osoba2($"{GetRandomString(10)} {GetRandomString(10)}"));
            }

            /*
             * Formatowanie tekstu
             * 
             * Definicja klasy 'PylekTekstFormatowany' zastępuje zapisywanie całego wektoru potrzebnego do formatowania tekstu
             */
            var formatowanieTekstu = new FormatowanieTekstu("Dzisiaj jest sobota, dzień powszedni.");
            formatowanieTekstu.ZmienNaWielkaLitere(10, 19);
            Console.WriteLine(formatowanieTekstu);
            var formatowanieTekstuPylek = new PylekFormatowanieTekstu("Dzisiaj jest sobota, dzień powszedni.");
            formatowanieTekstuPylek.DodajFormatowanie(10, 19).WielkaLitera = true;
            Console.WriteLine(formatowanieTekstuPylek);
        }
    }
}
