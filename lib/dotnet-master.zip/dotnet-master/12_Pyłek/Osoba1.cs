﻿using System;
namespace _Pyłek
{
    public class Osoba1
    {
        public string Nazwa { get; }
        public Osoba1(string nazwa)
        {
            Nazwa = nazwa;
        }
    }
}
