﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _Pyłek
{
    public class Osoba2
    {
        public string Nazwa => string.Join(" ", idki.Select(i => nazwy[i]));
        private static List<string> nazwy = new List<string>();
        private int[] idki;

        public Osoba2(string nazwa)
        {
            int PobierzLubDodaj(string s)
            {
                int id = nazwy.IndexOf(s);
                if (id != -1) return id;
                nazwy.Add(nazwa);
                return nazwy.Count - 1;
            }
            idki = nazwa.Split(' ').Select(PobierzLubDodaj).ToArray();
        }
    }
}
