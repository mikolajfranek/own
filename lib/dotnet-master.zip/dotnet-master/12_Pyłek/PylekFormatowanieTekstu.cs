﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _Pyłek
{
    public class PylekFormatowanieTekstu
    {
        private readonly string tekst;
        private readonly List<PylekTekstFormatowany> formatowania = new List<PylekTekstFormatowany>();
        public PylekFormatowanieTekstu(string tekst)
        {
            this.tekst = tekst;
        }
        public PylekTekstFormatowany DodajFormatowanie(int start, int koniec)
        {
            var tekstFormatowany = new PylekTekstFormatowany { Start = start, Koniec = koniec };
            formatowania.Add(tekstFormatowany);
            return tekstFormatowany;
        }
        public override string ToString()
        {
            var stringBuilder = new StringBuilder();
            for (var i = 0; i < tekst.Length; i++)
            {
                var c = tekst[i];
                foreach (var formatowanie in formatowania)
                {
                    if (formatowanie.CzyPokrywa(i) && formatowanie.WielkaLitera)
                    {
                        c = char.ToUpperInvariant(c);
                    }
                }
                stringBuilder.Append(c);
            }
            return stringBuilder.ToString();
        }
    }
}
