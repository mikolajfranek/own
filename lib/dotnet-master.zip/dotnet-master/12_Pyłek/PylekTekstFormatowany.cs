﻿using System;
namespace _Pyłek
{
    public class PylekTekstFormatowany
    {
        public int Start, Koniec;
        public bool WielkaLitera; 
        public bool CzyPokrywa(int pozycja)
        {
            return pozycja >= Start && pozycja <= Koniec;
        }
    }
}
