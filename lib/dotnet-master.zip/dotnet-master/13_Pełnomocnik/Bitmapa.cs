﻿using System;
namespace _Pełnomocnik
{
    public class Bitmapa : IObraz
    {
        private readonly string sciezkaDoPliku;
        public Bitmapa(string sciezkaDoPliku)
        {
            this.sciezkaDoPliku = sciezkaDoPliku;
            Console.WriteLine($"Pobieranie {sciezkaDoPliku}");
        }

        public void Rysuj()
        {
            Console.WriteLine($"Rysowanie {sciezkaDoPliku}");
        }
    }
}
