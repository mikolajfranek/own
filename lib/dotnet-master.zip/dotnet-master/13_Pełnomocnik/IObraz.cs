﻿using System;
namespace _Pełnomocnik
{
    public interface IObraz
    {
        void Rysuj();
    }
}
