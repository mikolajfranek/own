﻿using System;
namespace _Pełnomocnik
{
    public interface IPingPong
    {
        string Ping(string wiadomosc);
    }
}
