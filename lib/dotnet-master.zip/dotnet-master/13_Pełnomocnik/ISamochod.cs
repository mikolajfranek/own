﻿using System;
namespace _Pełnomocnik
{
    public interface ISamochod
    {
        void Prowadz();
    }
}
