﻿using System;
namespace _Pełnomocnik
{
    public class Kierowca
    {
        public int Wiek { get; set; }
        public Kierowca(int wiek)
        {
            Wiek = wiek;
        }

        private readonly PelnomocnikWlasciwosci<int> wiek2 = new PelnomocnikWlasciwosci<int>(10, nameof(wiek2));
        public int Wiek2
        {
            get => wiek2.Wartosc;
            set => wiek2.Wartosc = value;
        }
    }
}
