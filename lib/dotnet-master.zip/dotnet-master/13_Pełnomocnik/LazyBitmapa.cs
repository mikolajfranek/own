﻿using System;
namespace _Pełnomocnik
{
    public class LazyBitmapa : IObraz
    {
        private readonly string sciezkaDoPliku;
        private Bitmapa bitmapa;
        public LazyBitmapa(string sciezkaDoPliku)
        {
            this.sciezkaDoPliku = sciezkaDoPliku;
        }

        public void Rysuj()
        {
            if (bitmapa == null)
            {
                bitmapa = new Bitmapa(sciezkaDoPliku);
            }
            bitmapa.Rysuj();
        }
    }
}
