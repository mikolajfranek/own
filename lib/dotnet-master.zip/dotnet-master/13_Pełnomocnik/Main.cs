﻿using System;

namespace _Pełnomocnik
{
    class MainClass
    {
        public static void TestPing(IPingPong pingPong)
        {
            Console.WriteLine(pingPong.Ping("ping"));
        }

        public static void Main(string[] args)
        {
            //Pełnomocnik (proxy) zabezpieczający
            //polega na zapewnieniu kontroli dostępu do istniejącego obiektu
            Kierowca kierowca = new Kierowca(12);
            ISamochod samochod = new SamochodPelnomocnik(kierowca);
            samochod.Prowadz();

            //Pełnomocnik właściwości
            kierowca.Wiek2 = 23;

            //Pełnomocnik wirtualny
            Bitmapa bitmapa = new Bitmapa("plik.pdf");
            IObraz lazyBitmapa = new LazyBitmapa("pokemon.png");
            Console.WriteLine("Zaczynam rysować");
            lazyBitmapa.Rysuj();
            Console.WriteLine("Skończyłem rysować");

            //Pełnomocnik komunikacji
            Pong pong = new Pong();
            for (int i = 0; i < 3; ++i)
            {
                TestPing(pong);
            }
            RemotePong pong2 = new RemotePong();
            for (int i = 0; i < 3; ++i)
            {
                TestPing(pong2);
            }
        }
    }
}
