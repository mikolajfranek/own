﻿using System;
namespace _Pełnomocnik
{
    public class PelnomocnikWlasciwosci<T> where T : new()
    {
        private T wartosc;
        private T t;
        private readonly string nazwa;
        public T Wartosc
        {
            get => wartosc;
            set
            {
                if (Equals(this.wartosc, value)) return;
                Console.WriteLine($"Przypisanie {value} do wlasciwosci o nazwie {nazwa}");
                this.wartosc = value;
            }
        }
        public PelnomocnikWlasciwosci() : this(default(T)) { }
        public PelnomocnikWlasciwosci(T wartosc, string nazwa = "")
        {
            this.wartosc = wartosc;
            this.nazwa = nazwa;
        }

        public static implicit operator T(PelnomocnikWlasciwosci<T> property)
        {
            return property.Wartosc; // int n = p_int;
        }

        public static implicit operator PelnomocnikWlasciwosci<T>(T value)
        {
            return new PelnomocnikWlasciwosci<T>(value); // Property<int> p = 123;
        }
    }
}
