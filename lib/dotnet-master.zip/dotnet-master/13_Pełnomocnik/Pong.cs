﻿using System;
namespace _Pełnomocnik
{
    public class Pong : IPingPong
    {
        public string Ping(string wiadomosc)
        {
            return wiadomosc + "pong";
        }
    }
}
