﻿using System;
using System.Net;

namespace _Pełnomocnik
{
    public class RemotePong : IPingPong
    {
        public string Ping(string wiadomosc)
        {
            string uri = "https://google.com";
            string content = new WebClient().DownloadString(uri);
            return "pingpong";
        }
    }
}
