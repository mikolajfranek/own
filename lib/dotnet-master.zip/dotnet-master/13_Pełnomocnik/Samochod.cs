﻿using System;
namespace _Pełnomocnik
{
    public class Samochod : ISamochod
    {
        public void Prowadz()
        {
            Console.WriteLine("Samochod jest prowadzany\n");
        }
    }
}
