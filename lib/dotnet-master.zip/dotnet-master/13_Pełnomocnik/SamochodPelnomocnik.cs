﻿using System;
namespace _Pełnomocnik
{
    public class SamochodPelnomocnik : ISamochod
    {
        private Samochod samochod = new Samochod();
        private Kierowca kierowca;
        public SamochodPelnomocnik(Kierowca kierowca)
        {
            this.kierowca = kierowca;
        }
        public void Prowadz()
        {
            if (kierowca.Wiek >= 18)
                samochod.Prowadz();
            else
            {
                Console.WriteLine("Kierowca jest nieletni"); 
            }
        }
    }
}
