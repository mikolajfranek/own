﻿using System;
namespace _Łańcuch_odpowiedzialności
{
    public class AtakModyfikatorPostaci : ModyfikatorPostaci
    {
        public AtakModyfikatorPostaci(Postac postac) : base(postac) { }

        public override void Handle()
        {
            Console.WriteLine($"Podwojenie siły ataku postaci {postac.Nazwa}");
            postac.Atak *= 2;
            base.Handle();
        }
    }
}
