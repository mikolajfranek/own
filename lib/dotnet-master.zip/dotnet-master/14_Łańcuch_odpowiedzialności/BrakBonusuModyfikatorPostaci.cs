﻿using System;
namespace _Łańcuch_odpowiedzialności
{
    public class BrakBonusuModyfikatorPostaci : ModyfikatorPostaci
    {
        public BrakBonusuModyfikatorPostaci(Postac postac) : base(postac) { }

        public override void Handle()
        {
            Console.WriteLine("Brak bonusu");
        }
    }
}
