﻿using System;
namespace _Łańcuch_odpowiedzialności
{
    //broker zdarzen - wzorzec mediator
    public class Gra
    {
        public event EventHandler<Zapytanie> Modyfikatory;
        public void WykonajZapytanie(object sender, Zapytanie zapytanie)
        {
            //Wykonuje określony delegat w wątku, do którego należy uchwyt okna bazowego formantu, z określoną listą argumentów.
            Modyfikatory?.Invoke(sender, zapytanie);
        }
    }
}
