﻿using System;
namespace _Łańcuch_odpowiedzialności
{
    public class GraAtakModyfikatorPostaci : GraModyfikatorPostaci
    {
        public GraAtakModyfikatorPostaci(Gra gra, GraPostac graPostac) : base(gra, graPostac) { }

        protected override void Handle(object sender, Zapytanie zapytanie)
        {
            if (zapytanie.NazwaPostaci == graPostac.Nazwa && zapytanie.RodzajUmiejetnosci == Zapytanie.Argument.Atak)
            {
                zapytanie.Wartosc *= 2;
            }
        }
    }
}
