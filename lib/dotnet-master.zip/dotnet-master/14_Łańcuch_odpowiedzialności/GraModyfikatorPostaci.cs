﻿using System;
namespace _Łańcuch_odpowiedzialności
{
    public abstract class GraModyfikatorPostaci : IDisposable
    {
        protected Gra gra;
        protected GraPostac graPostac;
        protected GraModyfikatorPostaci(Gra gra, GraPostac graPostac)
        {
            this.gra = gra;
            this.graPostac = graPostac;
            //subskrypcja
            gra.Modyfikatory += Handle; 
        }
        protected abstract void Handle(object sender, Zapytanie zapytanie);
        public void Dispose()
        {
            //anulowanie subskrypcji
            gra.Modyfikatory -= Handle; 
        }

    }
}
