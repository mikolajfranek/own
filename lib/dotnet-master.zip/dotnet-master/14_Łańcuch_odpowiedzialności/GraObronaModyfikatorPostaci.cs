﻿using System;
namespace _Łańcuch_odpowiedzialności
{
    public class GraObronaModyfikatorPostaci : GraModyfikatorPostaci
    {
        public GraObronaModyfikatorPostaci(Gra gra, GraPostac graPostac) : base(gra, graPostac) { }

        protected override void Handle(object sender, Zapytanie zapytanie)
        {
            if (zapytanie.NazwaPostaci == graPostac.Nazwa && zapytanie.RodzajUmiejetnosci == Zapytanie.Argument.Obrona)
            {
                zapytanie.Wartosc += 2;
            }
        }
    }
}
