﻿using System;
namespace _Łańcuch_odpowiedzialności
{
    public class GraPostac
    {
        private Gra gra;
        public string Nazwa;
        private int atak;
        private int obrona;

        public GraPostac(Gra gra, string nazwa, int atak, int obrona)
        {
            this.gra = gra;
            this.Nazwa = nazwa;
            this.atak = atak;
            this.obrona = obrona;
        }

        public override string ToString()
        {
            return $"postać {Nazwa} posiada siły ataku {Atak} oraz siły obrony {Obrona}";
        }

        public int Atak
        {
            get
            {
                var zapytanie = new Zapytanie(Nazwa, Zapytanie.Argument.Atak, atak);
                gra.WykonajZapytanie(this, zapytanie);
                return zapytanie.Wartosc;
            }
        }

        public int Obrona
        {
            get
            {
                var zapytanie = new Zapytanie(Nazwa, Zapytanie.Argument.Obrona, obrona);
                gra.WykonajZapytanie(this, zapytanie);
                return zapytanie.Wartosc;
            }
        }
    }
}
