﻿using System;

namespace _Łańcuch_odpowiedzialności
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            //Łańcuch metod
            var mikolaj = new Postac("Mikolaj", 1, 1);
            Console.WriteLine(mikolaj);
            var root = new ModyfikatorPostaci(mikolaj);
            root.Add(new AtakModyfikatorPostaci(mikolaj));
            root.Add(new AtakModyfikatorPostaci(mikolaj));
            root.Add(new ObronaModyfikatorPostaci(mikolaj));
            root.Handle();
            Console.WriteLine(mikolaj);

            //łańcuch brokerów
            var gra = new Gra();
            var dell = new GraPostac(gra, "Dell", 1, 1);
            Console.WriteLine(dell);
            using(new GraAtakModyfikatorPostaci(gra, dell))
            {
                Console.WriteLine(dell);
                using(new GraObronaModyfikatorPostaci(gra, dell))
                {
                    Console.WriteLine(dell);
                }
            }
            Console.WriteLine(dell);
        }
    }
}
