﻿namespace _Łańcuch_odpowiedzialności
{
    public class ModyfikatorPostaci
    {
        protected Postac postac;
        protected ModyfikatorPostaci next;
        public ModyfikatorPostaci(Postac postac)
        {
            this.postac = postac;
        }
        public void Add(ModyfikatorPostaci item)
        {
            if (next != null)
            {
                next.Add(item);
            }
            else
            {
                next = item;
            }
        }
        public virtual void Handle() => next?.Handle();
    }
}
