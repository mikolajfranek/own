﻿using System;
namespace _Łańcuch_odpowiedzialności
{
    public class ObronaModyfikatorPostaci : ModyfikatorPostaci
    {
        public ObronaModyfikatorPostaci(Postac postac) : base(postac) { }

        public override void Handle()
        {
            if(postac.Atak < 3)
            {
                Console.WriteLine($"Zwiększenie siły obrony postaci {postac.Nazwa}");
                postac.Obrona += 2;
            }
            base.Handle();
        }
    }
}
