﻿using System;
namespace _Łańcuch_odpowiedzialności
{
    public class Postac
    {
        public string Nazwa { get; set; }
        public int Atak { get; set; }
        public int Obrona { get; set; }

        public Postac(string nazwa, int atak, int obrona)
        {
            this.Nazwa = nazwa;
            this.Atak = atak;
            this.Obrona = obrona;
        }

        public override string ToString()
        {
            return $"postać {Nazwa} posiada siły ataku {Atak} oraz siły obrony {Obrona}";
        }
    }
}
