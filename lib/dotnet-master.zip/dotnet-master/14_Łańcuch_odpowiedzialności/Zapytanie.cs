﻿using System;
namespace _Łańcuch_odpowiedzialności
{
    //wzorzec polecenie
    public class Zapytanie
    {
        public string NazwaPostaci;
        public enum Argument
        {
            Atak, Obrona
        }
        public Argument RodzajUmiejetnosci;
        public int Wartosc;
        public Zapytanie(string nazwa, Argument atak1, int atak2)
        {
            this.NazwaPostaci = nazwa;
            this.RodzajUmiejetnosci = atak1;
            this.Wartosc = atak2;
        }
    }
}
