﻿using System;
namespace _Polecenie
{
    public interface IPolecenie
    {
        void Wykonaj();
        void Cofnij();
    }
}
