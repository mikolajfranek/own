﻿using System;
using System.Collections.Generic;

namespace _Polecenie
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            //polecenie
            var rb = new RachunekBankowy();
            Console.WriteLine(rb);
            var cmdWplata = new PolecenieRachunekBankowy(rb, PolecenieRachunekBankowy.Akcja.Wplata, 100);
            cmdWplata.Wykonaj();
            Console.WriteLine(rb);

            //operacja cofania
            Console.WriteLine();
            var cmdWyplata = new PolecenieRachunekBankowy(rb, PolecenieRachunekBankowy.Akcja.Wyplata, 1000);
            cmdWyplata.Wykonaj();
            Console.WriteLine(rb);
            cmdWyplata.Cofnij();
            Console.WriteLine(rb);
            cmdWplata.Cofnij();
            Console.WriteLine(rb);

            //polecenie złożone
            Console.WriteLine();
            var from = new RachunekBankowy();
            from.Wplata(100);
            var to = new RachunekBankowy();
            var przelew = new PoleceniePrzelewBankowy(from, to, 1000);
            przelew.Wykonaj();
            Console.WriteLine(from);
            Console.WriteLine(to);

            //polecenie funkcyjne
            Console.WriteLine();
            var funk = new RachunekBankowy();
            var commands = new List<Action>();
            commands.Add(() => funk.Wplata(100));
            commands.Add(() => funk.Wyplata(100));
            commands.ForEach(c => c());
            Console.WriteLine(funk);
        }
    }
}
