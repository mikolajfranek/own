﻿using System;
namespace _Polecenie
{
    public class PoleceniePrzelewBankowy : ZlozonePolecenieRachunekBankowy
    {
        public PoleceniePrzelewBankowy(RachunekBankowy from, RachunekBankowy to, int ilosc)
        {
            this.AddRange(
                new[]
                {
                    new PolecenieRachunekBankowy(from, PolecenieRachunekBankowy.Akcja.Wyplata, ilosc),
                    new PolecenieRachunekBankowy(to, PolecenieRachunekBankowy.Akcja.Wplata, ilosc)
                }
            );
        }
    }
}
