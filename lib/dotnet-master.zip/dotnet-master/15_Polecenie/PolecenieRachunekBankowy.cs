﻿using System;
namespace _Polecenie
{
    public class PolecenieRachunekBankowy : IPolecenie
    {
        private RachunekBankowy rachunekBankowy;
        public enum Akcja
        {
            Wplata, Wyplata
        }
        private Akcja akcja;
        private int ilosc;
        public PolecenieRachunekBankowy(RachunekBankowy rachunekBankowy, Akcja akcja, int ilosc)
        {
            this.rachunekBankowy = rachunekBankowy;
            this.akcja = akcja;
            this.ilosc = ilosc;
        }

        public bool StatusWykonania { get; set; }
        public void Wykonaj()
        {
            switch (akcja)
            {
                case Akcja.Wplata:
                    rachunekBankowy.Wplata(ilosc);
                    StatusWykonania = true;
                    break;
                case Akcja.Wyplata:
                    StatusWykonania = rachunekBankowy.Wyplata(ilosc);
                    break;
                default:
                    throw new ArgumentOutOfRangeException();
            }
        }
        public void Cofnij()
        {
            if (StatusWykonania == false) return;
            switch (akcja)
            {
                case Akcja.Wplata:
                    StatusWykonania = rachunekBankowy.Wyplata(ilosc);
                    break;
                case Akcja.Wyplata:
                    rachunekBankowy.Wplata(ilosc);
                    StatusWykonania = true;
                    break;
                default:
                    throw new ArgumentOutOfRangeException();
            }
        }
    }
}
