﻿using System;
namespace _Polecenie
{
    public class RachunekBankowy
    {
        private int saldo;
        private int debetowyLimit = -500;
        public void Wplata(int ilosc)
        {
            saldo += ilosc;
            Console.WriteLine($"Wplacono {ilosc}, saldo to {saldo}");
        }
        public bool Wyplata(int ilosc)
        {
            if(saldo - ilosc >= debetowyLimit)
            {
                saldo -= ilosc;
                Console.WriteLine($"Wyplacono {ilosc}, saldo to {saldo}");
                return true;
            }
            return false;
        }

        public override string ToString()
        {
            return $"{nameof(saldo)}: {saldo}";
        }
    }
}
