﻿using System;
namespace _Polecenie
{
    public class UlepszonePolecenieRachunekBankowy
    {
        public UlepszonePolecenieRachunekBankowy()
        {
        }
    }
}
