﻿using System;
using System.Collections.Generic;

namespace _Polecenie
{
    public abstract class ZlozonePolecenieRachunekBankowy : List<PolecenieRachunekBankowy>
    {
        public void Cofnij()
        {
            for(int i = this.Count - 1; i >= 0; i--)
            {
                this[i].Cofnij();
            }
        }

        public void Wykonaj()
        {
            bool sukces = true;
            foreach(var item in this)
            {
                if (sukces)
                {
                    item.Wykonaj();
                    sukces = item.StatusWykonania;
                }
                else
                {
                    item.StatusWykonania = false;
                }
            }

            if(sukces == false)
            {
                this.Cofnij();
            }
        }
    }
}
