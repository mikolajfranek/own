﻿using System;
namespace _Interpreter
{
    public interface IElement
    {
        int Wartosc { get; }
    }
}
