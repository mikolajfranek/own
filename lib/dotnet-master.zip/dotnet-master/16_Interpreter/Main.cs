﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _Interpreter
{
    class MainClass
    {
        static List<Token> Leksykacja(string input)
        {
            var result = new List<Token>();
            for (int i = 0; i < input.Length; i++)
            {
                switch (input[i])
                {
                    case '+':
                        result.Add(new Token(Token.Typ.Plus, "+"));
                        break;
                    case '-':
                        result.Add(new Token(Token.Typ.Minus, "-"));
                        break;
                    case '(':
                        result.Add(new Token(Token.Typ.LewyNawias, "("));
                        break;
                    case ')':
                        result.Add(new Token(Token.Typ.PrawyNawias, ")"));
                        break;
                    default:
                        var sb = new StringBuilder(input[i].ToString());
                        for (int j = i + 1; j < input.Length; ++j)
                        {
                            if (char.IsDigit(input[j]))
                            {
                                sb.Append(input[j]);
                                ++i;
                            }
                            else
                            {
                                result.Add(new Token(Token.Typ.Liczba, sb.ToString()));
                                break;
                            }
                        }
                        break;
                }
            }
            return result;
        }

        static IElement Parsowanie(IReadOnlyList<Token> tokens)
        {
            var result = new OperacjaToken();
            bool isLeftSide = false;
            for (int i = 0; i < tokens.Count; i++)
            {
                var token = tokens[i];
                switch (token.typ)
                {
                    case Token.Typ.Plus:
                        result.typ = OperacjaToken.TypDzialania.Dodawanie;
                        break;
                    case Token.Typ.Minus:
                        result.typ = OperacjaToken.TypDzialania.Odejmowanie;
                        break;
                    case Token.Typ.Liczba:
                        var integer = new MyInteger(int.Parse(token.text));
                        if (isLeftSide == false)
                        {
                            result.lewy = integer;
                            isLeftSide = true;
                        }
                        else
                        {
                            result.prawy = integer;
                        }
                        break;
                    case Token.Typ.LewyNawias:
                        int j = i;
                        for (; j < tokens.Count; ++j)
                        {
                            if (tokens[j].typ == Token.Typ.PrawyNawias)
                            {
                                break;
                            }
                        }
                        var sub = tokens.Skip(i + 1).Take(j - i - 1).ToList();
                        var element = Parsowanie(sub);
                        if (isLeftSide == false)
                        {
                            result.lewy = element;
                            isLeftSide = true;
                        }
                        else
                        {
                            result.prawy = element;
                        }
                        i = j;
                        break;
                }
            }
            return result;
        }

        public static void Main(string[] args)
        {
            var input = "(3+4)-(12+31)";
            var tokeny = Leksykacja(input);
            Console.WriteLine(string.Join("\t", tokeny));
            var parsed = Parsowanie(tokeny);
            Console.WriteLine($"{input} => {parsed.Wartosc}");
        }
    }
}
