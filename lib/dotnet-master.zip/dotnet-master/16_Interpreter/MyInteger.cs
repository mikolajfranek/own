﻿using System;
namespace _Interpreter
{
    public class MyInteger : IElement
    {
        public MyInteger(int value)
        {
            Wartosc = value;
        }

        public int Wartosc { get; }
    }
}
