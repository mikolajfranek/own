﻿using System;
namespace _Interpreter
{
    public class OperacjaToken : IElement
    {
        public enum TypDzialania
        {
            Dodawanie,
            Odejmowanie
        }
        public TypDzialania typ;
        public IElement lewy, prawy;
        public int Wartosc
        {
            get
            {
                switch (typ)
                {
                    case TypDzialania.Dodawanie:
                        return lewy.Wartosc + prawy.Wartosc;
                    case TypDzialania.Odejmowanie:
                        return lewy.Wartosc - prawy.Wartosc;
                    default:
                        throw new ArgumentOutOfRangeException();
                }
            }
        }
    }
}
