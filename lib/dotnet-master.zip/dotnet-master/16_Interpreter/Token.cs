﻿using System;
namespace _Interpreter
{
    public class Token
    {
        public enum Typ
        {
            Liczba, Plus, Minus, LewyNawias, PrawyNawias
        }
        public Typ typ;
        public string text;
        public Token(Typ typ, string text)
        {
            this.typ = typ;
            this.text = text;
        }

        public override string ToString()
        {
            return $"`{text}`";
        }
    }
}
