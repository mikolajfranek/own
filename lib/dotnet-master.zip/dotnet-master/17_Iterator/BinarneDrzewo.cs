﻿using System;
namespace _Iterator
{
    public class BinarneDrzewo<T>
    {
        private Wezel<T> root;
        public BinarneDrzewo(Wezel<T> root)
        {
            this.root = root;
        }
    
    }
}
