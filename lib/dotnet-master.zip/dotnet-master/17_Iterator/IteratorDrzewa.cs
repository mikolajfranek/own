﻿using System;
using System.Collections.Generic;

namespace _Iterator
{
    public class IteratorDrzewa<T>
    {
        public Wezel<T> AktualnyElement { get; set; }
        private readonly Wezel<T> korzen;
        private bool czyYield;

        public IteratorDrzewa(Wezel<T> korzen)
        {
            this.korzen = AktualnyElement = korzen;
            while (AktualnyElement.lewy != null)
            {
                AktualnyElement = AktualnyElement.lewy;
            }
        }

        public bool MoveNext()
        {
            if (!czyYield)
            {
                czyYield = true;
                return true;
            }

            if (AktualnyElement.prawy != null)
            {
                AktualnyElement = AktualnyElement.prawy;
                while (AktualnyElement.lewy != null)
                {
                    AktualnyElement = AktualnyElement.lewy;
                }
                return true;
            }
            else
            {
                var p = AktualnyElement.rodzic;
                while (p != null && AktualnyElement == p.prawy)
                {
                    AktualnyElement = p;
                    p = p.rodzic;
                }
                AktualnyElement = p;
                return AktualnyElement != null;
            }
        }

        public IEnumerable<Wezel<T>> UlepszonyIterator
        {
            get
            {
                IEnumerable<Wezel<T>> PrzejdzKolejno(Wezel<T> current)
                {
                    if (current.lewy != null)
                    {
                        foreach (var left in PrzejdzKolejno(current.lewy))
                            yield return left;
                    }
                    yield return current;
                    if (current.prawy != null)
                    {
                        foreach (var right in PrzejdzKolejno(current.prawy))
                            yield return right;
                    }
                }
                foreach (var node in PrzejdzKolejno(korzen))
                {
                    yield return node;
                }
            }
        }
    }
}
