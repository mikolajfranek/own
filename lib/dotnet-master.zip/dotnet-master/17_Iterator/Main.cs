﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _Iterator
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            //iterowanie
            List<int> list = new List<int>() { 1, 2, 3, 4 };
            foreach (var x in list)
            { 
                Console.WriteLine(x);
            }

            //odpowiednik
            Console.WriteLine();
            var enumerator = ((IEnumerable<int>)list).GetEnumerator();
            while (enumerator.MoveNext())
            {
                Console.WriteLine(enumerator.Current);
            }

            Console.WriteLine();
            IEnumerable<int> GetSomeNumbers()
            {
                yield return 1;
                yield return 2;
                yield return 3;
            }
            foreach (var x in GetSomeNumbers())
            {
                Console.WriteLine(x);
            }

            Console.WriteLine();
            var root = new Wezel<int>(11, new Wezel<int>(22), new Wezel<int>(33));
            var it = new IteratorDrzewa<int>(root);
            while (it.MoveNext())
            {
                Console.WriteLine(it.AktualnyElement.Wartosc);
            }


            Console.WriteLine();
            it.UlepszonyIterator.Select(x => x.Wartosc).ToList().ForEach(Console.WriteLine);
        }
    }
}
