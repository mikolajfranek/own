﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace _Iterator
{ 
    public class Postac : IEnumerable<int>
    {
        public int Sila { get; set; }
        public int Zwinnosc { get; set; }
        public int Inteligencja { get; set; }
        public double SumaStatystyk => Sila + Zwinnosc + Inteligencja;
        public double SredniaStatystyk => SumaStatystyk / 3.0;
        public double MaxStatystyka => Math.Max(Math.Max(Sila, Zwinnosc), Inteligencja);

        //lepsze podejście
        private int[] stats = new int[3];

        private const int sila2 = 0;
        public int Sila2
        {
            get => stats[sila2];
            set => stats[sila2] = value;
        }
        private const int zwinnosc2 = 1;
        public int Zwinnosc2
        {
            get => stats[zwinnosc2];
            set => stats[zwinnosc2] = value;
        }
        private const int inteligencja2 = 2;
        public int Inteligenecja2
        {
            get => stats[inteligencja2];
            set => stats[inteligencja2] = value;
        }


        public double SumaStatystyk2 => stats.Sum();
        public double SredniaStatystyk2 => stats.Average();
        public double MaxStatystyka2 => stats.Max();
        public IEnumerable<int> Statystyki => stats;


        public IEnumerator<int> GetEnumerator() => stats.AsEnumerable().GetEnumerator();
        IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
        public int this[int index]
        {
            get => stats[index];
            set => stats[index] = value;
        }
    }
}
