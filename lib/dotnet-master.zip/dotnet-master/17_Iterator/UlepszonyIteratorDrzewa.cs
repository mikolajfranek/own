﻿using System;
namespace _Iterator
{
    public class UlepszonyIteratorDrzewa
    {
        public UlepszonyIteratorDrzewa()
        {
        }
    }
}
