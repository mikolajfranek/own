﻿using System;
namespace _Iterator
{
    public class Wezel<T>
    {
        public T Wartosc;
        public Wezel<T> lewy, prawy;
        public Wezel<T> rodzic;
        public Wezel(T value)
        {
            Wartosc = value;
        }

        public Wezel(T wartosc, Wezel<T> lewy, Wezel<T> prawy)
        {
            this.Wartosc = wartosc;
            this.lewy = lewy;
            this.prawy = prawy;

            this.lewy.rodzic = prawy.rodzic = this;
        }
    }
}
