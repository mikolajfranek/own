﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _Mediator
{
    public class ChatPokoj
    {
        private List<Osoba> osoby = new List<Osoba>();

        public void Broadcast(string from, string message)
        {
            foreach (var o in osoby)
            {
                if (o.Nazwa != from)
                {
                    o.Receive(from, message);
                }
            }
        }

        public void Join(Osoba o)
        {
            string joinMsg = $"{o.Nazwa} dołącza";
            Broadcast("pokoj", joinMsg);
            o.ChatPokoj = this;
            osoby.Add(o);
        }

        public void Message(string from, string to, string message)
        {
            osoby.FirstOrDefault(p => p.Nazwa == to)?.Receive(from, message);
        }
    }
}
