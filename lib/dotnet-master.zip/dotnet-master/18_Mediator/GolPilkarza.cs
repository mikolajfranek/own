﻿using System;
namespace _Mediator
{
    public class GolPilkarza : GraEventArgs
    {
        public string Nazwa;
        public int GoleDoTejPory;

        public GolPilkarza(string nazwa, int goleDoTejPory)
        {
            Nazwa = nazwa;
            GoleDoTejPory = goleDoTejPory;
        }
        public override void Print()
        {
            Console.WriteLine($"{Nazwa} zdobył gola, to jego {GoleDoTejPory} gol");
        }
    }
}
