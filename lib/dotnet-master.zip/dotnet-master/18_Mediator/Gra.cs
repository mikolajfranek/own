﻿using System;
namespace _Mediator
{
    public class Gra
    {
        public event EventHandler<GraEventArgs> Events;
        public void Wykonaj(GraEventArgs args)
        {
            Events?.Invoke(this, args);
        }
    }
}
