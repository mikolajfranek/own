﻿using System;
namespace _Mediator
{
    public abstract class GraEventArgs : EventArgs
    {
        public abstract void Print();
    }
}
