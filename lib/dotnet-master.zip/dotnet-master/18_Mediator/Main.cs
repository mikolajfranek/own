﻿using System;

namespace _Mediator
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            var pokoj = new ChatPokoj();
            var mikolaj = new Osoba("mikolaj");
            var jagoda = new Osoba("jagoda");
            pokoj.Join(mikolaj);
            pokoj.Join(jagoda);
            mikolaj.Say("helllo");
            jagoda.Say("cześć");
            var weronika = new Osoba("weronika");
            pokoj.Join(weronika);
            weronika.PrivateMessage("mikolaj", "hej mikolaj, tu weronika");
            weronika.Say("siema wszystkim");
            jagoda.PrivateMessage("mikolaj", ".");

            Console.WriteLine();
            var gra = new Gra();
            var pilkarzM = new Pilkarz(gra, "mikolaj");
            var pilkarzF = new Pilkarz(gra, "franek");
            var trener = new Trener(gra);
            pilkarzM.StrzelenieGola();
            pilkarzF.StrzelenieGola();
            pilkarzM.StrzelenieGola();
            pilkarzM.StrzelenieGola();
        }
    }
}
