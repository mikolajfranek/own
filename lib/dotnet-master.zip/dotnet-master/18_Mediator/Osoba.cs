﻿using System;
using System.Collections.Generic;

namespace _Mediator
{
    public class Osoba
    {
        public string Nazwa;
        public ChatPokoj ChatPokoj;
        private List<string> chatLog = new List<string>();

        public Osoba(string name)
        {
            Nazwa = name;
        }

        public void Receive(string sender, string message)
        {
            string s = $"{sender}: '{message}'";
            Console.WriteLine($"[{Nazwa}'s sesja] {s}");
            chatLog.Add(s);
        }

        public void Say(string message) => ChatPokoj.Broadcast(Nazwa, message);

        public void PrivateMessage(string to, string message)
        {
            ChatPokoj.Message(Nazwa, to, message);
        }
    }
}
