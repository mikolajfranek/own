﻿using System;
namespace _Mediator
{
    public class Pilkarz
    {
        private string nazwa;
        private int goleDoTejPory = 0;
        private Gra gra;

        public Pilkarz(Gra gra, string nazwa)
        {
            this.gra = gra;
            this.nazwa = nazwa;
        }

        public void StrzelenieGola()
        {
            goleDoTejPory++;
            var args = new GolPilkarza(nazwa, goleDoTejPory);
            gra.Wykonaj(args);
        }
    }
}
