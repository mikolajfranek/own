﻿using System;
namespace _Mediator
{
    public class Trener
    {
        private Gra gra;
        public Trener(Gra gra)
        {
            this.gra = gra;
            gra.Events += (sender, args) =>
            {
                if (args is GolPilkarza pilkarz && pilkarz.GoleDoTejPory < 3)
                {
                    Console.WriteLine($"trener: dobra robota {pilkarz.Nazwa}");
                }
            };
        }
    }
}
