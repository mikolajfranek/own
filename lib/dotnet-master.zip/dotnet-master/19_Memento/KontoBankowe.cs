﻿using System;
using System.Collections.Generic;

namespace _Memento
{
    public class KontoBankowe
    {
        private List<Memento> wszystkieStany = new List<Memento>();
        private int obecnyStan;
        private int saldo;
        public KontoBankowe(int saldo)
        {
            this.saldo = saldo;
            wszystkieStany.Add(new Memento(saldo));
        }
        public Memento Wplata(int ilosc)
        {
            saldo += ilosc;
            var m = new Memento(saldo);
            wszystkieStany.Add(m);
            obecnyStan += 1;
            return m;
        }
        public void PrzywrocStan(Memento m)
        {
            if(m != null)
            {
                saldo = m.Saldo;
                wszystkieStany.Add(m);
                obecnyStan = wszystkieStany.Count - 1;
            }
        }
        public Memento Undo()
        {
            if (obecnyStan > 0)
            {
                var m = wszystkieStany[--obecnyStan];
                saldo = m.Saldo;
                return m;
            }
            return null;
        }
        public Memento Redo()
        {
            if (obecnyStan + 1 < wszystkieStany.Count)
            {
                var m = wszystkieStany[++obecnyStan];
                saldo = m.Saldo;
                return m;
            }
            return null;
        }
        public override string ToString()
        {
            return $"saldo:{saldo}";
        }
    }
}
