﻿using System;

namespace _Memento
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            var ba = new KontoBankowe(100);
            var m1 = ba.Wplata(50);
            var m2 = ba.Wplata(25);
            Console.WriteLine(ba);
            ba.PrzywrocStan(m1);
            Console.WriteLine(ba);
            ba.PrzywrocStan(m2);
            Console.WriteLine(ba);

            //Cofnij i ponów
            Console.WriteLine();
            ba.Undo();
            Console.WriteLine(ba);
            ba.Undo();
            Console.WriteLine(ba);
            ba.Undo();
            Console.WriteLine(ba);
            ba.Undo();
            Console.WriteLine(ba);
            ba.Redo();
            Console.WriteLine(ba);
        }
    }
}
