﻿using System;
namespace _Memento
{
    public class Memento
    {
        public int Saldo { get; }
        public Memento(int saldo)
        {
            Saldo = saldo;
        }
    }
}
