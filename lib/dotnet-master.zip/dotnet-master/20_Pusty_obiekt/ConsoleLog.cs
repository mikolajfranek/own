﻿using System;
namespace _Pusty_obiekt
{
    class ConsoleLog : ILog
    {
        public void Informacja(string msg)
        {
            Console.WriteLine(msg);
        }
        public void Ostrzezenie(string msg)
        {
            Console.WriteLine("Ostrzezenie:" + msg);
        }
    }
}
