﻿using System;
namespace _Pusty_obiekt
{
    public interface ILog
    {
        void Informacja(string msg);
        void Ostrzezenie(string msg);
    }
}
