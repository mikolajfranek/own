﻿using System;
namespace _Pusty_obiekt
{
    public class KontoBankowe
    {
        private ILog log;
        private int saldo;
        public KontoBankowe(ILog log)
        {
            this.log = new OptionalLog(log);
        }
        public void Wplata(int ilosc)
        {
            saldo += ilosc;
            //nie komunikujemy, że log może być nullem
            log?.Informacja($"Wpłacono {ilosc}, saldo {saldo}");
        }
    }
}
