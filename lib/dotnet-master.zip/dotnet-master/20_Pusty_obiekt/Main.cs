﻿using System;

namespace _Pusty_obiekt
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            var c = new ConsoleLog();
            var ba = new KontoBankowe(c);
            ba.Wplata(1);

            //jeżeli nie chce logować, zamień ILog na klasę abstrakcyjną
            //ulepszenia projektu
            Console.WriteLine();
            var nl = new NullLog();
            var ba2 = new KontoBankowe(nl);
            ba2.Wplata(2);

            //wirtualny pośrednik pustego obiektu
            Console.WriteLine();
            var ba3 = new KontoBankowe(null);
            ba3.Wplata(3);

            //dynamiczny pusty obiekt - przy każdym wywołaniu intefejsu 'nic nie rób'
            //pozwala na tworzenie domyślnego egzemplarza dowolnego typu który faktycznie zwraca dana metoda
            Console.WriteLine();
            var log = Null<ILog>.Instance;
            var ba4 = new KontoBankowe(log);
            ba4.Wplata(100);
        }
    }
}
