﻿using System;
using System.Dynamic;
using ImpromptuInterface;

namespace _Pusty_obiekt
{
    public class Null<T> : DynamicObject where T : class
    {
        public override bool TryInvokeMember(InvokeMemberBinder binder, object[] args, out object result)
        {
            var name = binder.Name;
            result = Activator.CreateInstance(binder.ReturnType);
            return true;
        }

        public static T Instance
        {
            get
            {
                if (typeof(T).IsInterface == false)
                {
                    throw new ArgumentException("Wymagany typ, który jest interfejsem");
                }
                //ActLike pobiera dynamiczny obirkt i dostosowuje go w czasie działania aplikacji do wymaganego interfejsu T
                return new Null<T>().ActLike<T>();
            }
        }
    }
}
