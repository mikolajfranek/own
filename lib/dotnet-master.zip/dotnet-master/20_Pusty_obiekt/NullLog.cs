﻿using System;
namespace _Pusty_obiekt
{
    public sealed class NullLog : ILog
    {
        public void Informacja(string msg) {}
        public void Ostrzezenie(string msg) {}
    }
}
