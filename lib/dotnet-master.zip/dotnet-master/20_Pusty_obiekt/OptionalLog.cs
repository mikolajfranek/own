﻿using System;
namespace _Pusty_obiekt
{
    public class OptionalLog : ILog
    {
        private ILog log;

        public OptionalLog(ILog log = null)
        {
            this.log = log;
        }
        public void Informacja(string msg)
        {
            log?.Informacja(msg);
        }

        public void Ostrzezenie(string msg)
        {
            log?.Ostrzezenie(msg);
        }
    }
}
