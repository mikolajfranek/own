﻿using System;
namespace _Obserwator
{
    public class Event
    {
        public Event()
        {
        }
    }
}
