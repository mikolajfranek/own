﻿using System;

namespace _Obserwator
{
    class MainClass
    {
        public static void ZadzwonPoDoktora(object sender, ZachorowanieEventArgs eventArgs)
        {
            Console.WriteLine($"Doktor musi jechać na ulicę {eventArgs.Adres}");
        }

        public static void UruchomienieGarbargeCollection()
        {
            GC.Collect();
        }

        public static void Main(string[] args)
        {
            var osoba = new Osoba();
            osoba.Zachorowanie += ZadzwonPoDoktora;
            osoba.ZlapaniePrzeziebienia();

            ///Słabe zdarzenie - wycieki pamięci w sensie .Net
            Console.WriteLine();
            var przycisk = new Przycisk();
            var okno = new Okno(przycisk);
            var windowRef = new WeakReference(okno);
            przycisk.Uruchomienie();
            okno = null;
            UruchomienieGarbargeCollection();
            Console.WriteLine($"Czy okno jest nadal żywe po wywołaniu GC? {windowRef.IsAlive}");
            //Okno2 jest prawidłową implementacją, która nie posiada wycieku

            //Obeserwator właściwości
            Console.WriteLine();
            osoba.Wiek = 10;
            Console.WriteLine($"Wiek osoby to {osoba.Wiek++}, moze glosować {osoba.MozeGlosowac}");
            Console.WriteLine($"Wiek osoby to {osoba.Wiek++}, moze glosować {osoba.MozeGlosowac}");
            Console.WriteLine($"Wiek osoby to {osoba.Wiek++}, moze glosować {osoba.MozeGlosowac}");
            Console.WriteLine($"Wiek osoby to {osoba.Wiek++}, moze glosować {osoba.MozeGlosowac}");
            Console.WriteLine($"Wiek osoby to {osoba.Wiek++}, moze glosować {osoba.MozeGlosowac}");
            Console.WriteLine($"Wiek osoby to {osoba.Wiek++}, moze glosować {osoba.MozeGlosowac}");
            Console.WriteLine($"Wiek osoby to {osoba.Wiek++}, moze glosować {osoba.MozeGlosowac}");

            //Problemy z zależnościami
            //nie obsługuje cykli zależności A->B->C->A lub A->B->A

            //Strumienie zdarzeń
            var doesntmatter = new KlasaDemo();

            //Kolekcje obserwowalne
            //subskrypcje deklarowane za pomocą atrybutów dla kontenerów IoC
            //przyklad Trener, Piłkarz - ogólnie brakuje konfiguracji IoC
        }

        private class KlasaDemo : IObserver<Event>
        {
            public KlasaDemo()
            {
                var osobaChora = new OsobaChora();
                var subscribed = osobaChora.Subscribe(this);
                Console.WriteLine();
                osobaChora.ZlapaniePrzeziebienia();
                Console.WriteLine();
            }

            public void OnCompleted() { }
            public void OnError(Exception error) { }
            public void OnNext(Event value)
            {
                if (value is ZachorowanieEvent args)
                {
                    Console.WriteLine($"Doktor jedzie skuterem na {args.Adres}");
                }
            }
        }
    }
}
