﻿using System;
namespace _Obserwator
{
    public class MemberAccessVisitor
    {
        public MemberAccessVisitor()
        {
        }
    }
}
