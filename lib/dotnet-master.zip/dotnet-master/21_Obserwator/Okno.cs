﻿using System;
namespace _Obserwator
{
    public class Okno
    {
        public Okno(Przycisk przycisk)
        {
            przycisk.Klikniecie += AkcjaNaKlikniecie;
        }
    
        private void AkcjaNaKlikniecie(object sender, EventArgs eventArgs)
        {
            Console.WriteLine("Klinięto przycisk (handler w obiekcie Okno)");
        }

        ~Okno()
        {
            Console.WriteLine("Finalizacja obiektu Okno");
        }
    }
}
