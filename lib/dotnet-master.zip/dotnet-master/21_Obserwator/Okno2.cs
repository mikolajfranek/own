﻿using System;

namespace _Obserwator
{
    public class Okno2
    {
        public Okno2(Przycisk przycisk)
        {
            //klasa umożliwia odśmiecanie nawet w przypadku 'Okno' -> zobacz do Main.cs
            //WeakEventManager<Przycisk, EventArgs>.AddHandler(przycisk, "Kliknięto", AkcjaNaKlikniecie);
        }

        private void AkcjaNaKlikniecie(object sender, EventArgs eventArgs)
        {
            Console.WriteLine("Klinięto przycisk (handler w obiekcie Okno2)");
        }

        ~Okno2()
        {
            Console.WriteLine("Finalizacja obiektu Okno2");
        }
    }
}
