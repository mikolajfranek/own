﻿using System;
namespace _Obserwator
{
    public class Osoba : PropertyNotificationSupport
    {
        public event EventHandler<ZachorowanieEventArgs> Zachorowanie;

        public void ZlapaniePrzeziebienia()
        {
            Zachorowanie?.Invoke(this, new ZachorowanieEventArgs { Adres = "Sezamowa 123" });
        }

        private int wiek;
        public int Wiek
        {
            get => wiek;
            set
            {
                if (value == wiek) return;
                wiek = value;
                OnPropertyChanged();
            }
        }

        private readonly Func<bool> mozeGlosowac;
        public bool MozeGlosowac => mozeGlosowac();

        public Osoba()
        {
            this.PropertyChanged += AkcjaPowiadomienie;
            mozeGlosowac = property(nameof(MozeGlosowac), () => Wiek >= 16);
        }

        private void AkcjaPowiadomienie(object sender, EventArgs eventArgs)
        {
            Console.WriteLine("Powiadomienie o zmianie właściwości");
        }
    }
}
