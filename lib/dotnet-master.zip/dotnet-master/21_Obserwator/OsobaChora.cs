﻿using System;
using System.Collections.Generic;

namespace _Obserwator
{
    public class OsobaChora : IObservable<Event>
    {
        private readonly HashSet<Subskrypcja> subscriptions = new HashSet<Subskrypcja>();

        public IDisposable Subscribe(IObserver<Event> observer)
        {
            var subscription = new Subskrypcja(this, observer);
            subscriptions.Add(subscription);
            return subscription;
        }

        public void ZlapaniePrzeziebienia()
        {
            foreach (var sub in subscriptions)
            {
                sub.Obserwator.OnNext(new ZachorowanieEvent { Adres = "Frankowa 123" });
            }
        }

        private class Subskrypcja : IDisposable
        {
            private OsobaChora osoba;
            public IObserver<Event> Obserwator;
            public Subskrypcja(OsobaChora osoba, IObserver<Event> obserwator)
            {
                this.osoba = osoba;
                Obserwator = obserwator;
            }

            public void Dispose()
            {
                osoba.subscriptions.Remove(this);
            }
        }
    }
}
