﻿using System;
namespace _Obserwator
{
    public class Pilkarz
    {
        //not woked on ubuntu
        //[Publishes("score")]
        public event EventHandler PlayerScored;
        public string Name { get; set; }

        public void Score()
        {
            PlayerScored?.Invoke(this, new EventArgs());
        }
    }
}
