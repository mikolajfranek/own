﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Linq.Expressions;
using System.Runtime.CompilerServices;

namespace _Obserwator
{
    public class PropertyNotificationSupport : INotifyPropertyChanged
    {
        private readonly Dictionary<string, HashSet<String>> affectedBy = new Dictionary<string, HashSet<string>>();
        private class MemberAccessVisitor : ExpressionVisitor
        {
            private readonly Type declaringType;
            public IList<string> PropertyNames = new List<string>();
            public MemberAccessVisitor(Type declaringType)
            {
                this.declaringType = declaringType;
            }
            public override Expression Visit(Expression node)
            {
                if (node != null && node.NodeType == ExpressionType.MemberAccess)
                {
                    var memberExpr = (MemberExpression)node;
                    if (memberExpr.Member.DeclaringType == declaringType)
                    {
                        PropertyNames.Add(memberExpr.Member.Name);
                    }
                }
                return base.Visit(node);
            }
        }

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
            foreach (var affector in affectedBy.Keys)
            {
                if (affectedBy[affector].Contains(propertyName))
                {
                    OnPropertyChanged(affector);
                }
            }
        }
               
        protected Func<T> property<T>(string name, Expression<Func<T>> expr)
        {
            Console.WriteLine($"Tworzenie obliczonej właściwości dla wyrażenia {expr}");
            var visitor = new MemberAccessVisitor(GetType());
            visitor.Visit(expr);
            if (visitor.PropertyNames.Any())
            {
                if (affectedBy.ContainsKey(name) == false)
                {
                    affectedBy.Add(name, new HashSet<string>());
                }
                foreach (var propName in visitor.PropertyNames)
                {
                    if (propName != name)
                    {
                        affectedBy[name].Add(propName);
                    }
                }
            }
            return expr.Compile();
        }

        public event PropertyChangedEventHandler PropertyChanged;
    }
}
