﻿using System;
namespace _Obserwator
{
    public class Przycisk
    {
        public event EventHandler Klikniecie;

        public void Uruchomienie()
        {
            Klikniecie?.Invoke(this, EventArgs.Empty);
        }
    }
}
