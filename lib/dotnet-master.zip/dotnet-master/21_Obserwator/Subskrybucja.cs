﻿using System;
namespace _Obserwator
{
    public class Subskrybucja : IDisposable
    {
        private OsobaChora osoba;
        public IObserver<Event> Obserwator;
        public Subskrybucja(OsobaChora osoba, IObserver<Event> obserwator)
        {
            this.osoba = osoba;
            Obserwator = obserwator;
        }

        public void Dispose()
        {
            osoba. .subscriptions.Remove(this);
        }
    }
}
