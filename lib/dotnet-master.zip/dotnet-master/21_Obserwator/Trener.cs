﻿using System;
namespace _Obserwator
{
    public class Trener
    {
        //not woked on ubuntu
        //[SubscribesTo("score")]
        public void PlayerScored(object sender, EventArgs args)
        {
            var p = sender as Pilkarz;
            Console.WriteLine("Dobra robota, {0}!", p.Name);
        }
    }
}
