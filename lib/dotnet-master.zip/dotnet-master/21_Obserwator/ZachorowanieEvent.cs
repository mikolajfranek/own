﻿using System;
namespace _Obserwator
{
    public class ZachorowanieEvent : Event
    {
        public string Adres;
    }
}
