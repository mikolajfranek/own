﻿using System;
namespace _Obserwator
{
    public class ZachorowanieEventArgs : EventArgs
    {
        public string Adres;
    }
}
