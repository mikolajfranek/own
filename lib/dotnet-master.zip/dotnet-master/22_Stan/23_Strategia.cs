﻿using System;
namespace _Stan
{
    public class _3_Strategia
    {
        public _3_Strategia()
        {
        }
    }
}
