﻿using System;
using System.Collections.Generic;
using System.Threading;
using Stateless;

namespace _Stan
{
    class MainClass
    {
        public enum State
        {
            KorzystanieZTelefonu,
            PodniesionaSluchawka, //OffHook,
            Laczenie, //Connecting,
            Polaczenie, //Connected,
            Zawieszenie, //OnHold
        }

        public enum Trigger
        {
            WybraniePolaczenia, //CallDialed,
            Rozlaczenie, //HungUp,
            NawiazaniePolaczenie, //CallConnected,
            Zawieszenie, //PlacedOnHold,
            Wstrzymanie, //TakenOffHold,
            ZostawienieWiadomosci, //LeftMessage
        }

        public enum TriggerPrzelacznik { On, Off }

        private static Dictionary<State, List<(Trigger, State)>> rules = new Dictionary<State, List<(Trigger, State)>>
        {
            [State.PodniesionaSluchawka] = new List<(Trigger, State)>
            {
                (Trigger.WybraniePolaczenia, State.Laczenie)
            },
            [State.Laczenie] = new List<(Trigger, State)>
            {
                (Trigger.Rozlaczenie, State.PodniesionaSluchawka),
                (Trigger.NawiazaniePolaczenie, State.Polaczenie)
            },
        };

        public static void Main(string[] args)
        {
            //Stan kontroluje zachowanie i stan może się zmieniać
            var przelacznik = new Przelacznik();
            przelacznik.On();
            przelacznik.Off();
            przelacznik.Off();

            //Maszyna stanów
            State state = State.PodniesionaSluchawka;
            State exitState = State.Polaczenie;
            do
            {
                break;
                Console.WriteLine($"Telefon jest obecnie w stanie {state}");
                Console.WriteLine("Wybierz wyzwalacz:");
                for (var i = 0; i < rules[state].Count; i++)
                {
                    var (t, _) = rules[state][i];
                    Console.WriteLine($"{i} -> {t}");
                }
                int input = int.Parse(Console.ReadLine());
                var (_, s) = rules[state][input];
                state = s;
            } while (state != exitState);
            Console.WriteLine("Zakończyliśmy używanie telefonu.");

            //Maszyny stanów z wykorzystaniem biblioteki Stateless
            Console.WriteLine();

            bool czyPrawidlowyNumber = true;
            var call = new StateMachine<State, Trigger>(State.PodniesionaSluchawka);
            call.Configure(State.PodniesionaSluchawka)
                .SubstateOf(State.KorzystanieZTelefonu)
                .Permit(Trigger.WybraniePolaczenia, State.Laczenie);
            call.Configure(State.Laczenie)
                .SubstateOf(State.KorzystanieZTelefonu)
                .PermitIf(Trigger.NawiazaniePolaczenie, State.Polaczenie, () => czyPrawidlowyNumber);
            call.Configure(State.Polaczenie)
                .SubstateOf(State.KorzystanieZTelefonu)
                .PermitIf(Trigger.Rozlaczenie, State.PodniesionaSluchawka, () => czyPrawidlowyNumber);


            Console.WriteLine($"{call.State} ==> Korzystanie z telefonu = {call.IsInState(State.KorzystanieZTelefonu)}");
            call.Fire(Trigger.WybraniePolaczenia);
            Console.WriteLine($"{call.State} ==> Korzystanie z telefonu = {call.IsInState(State.KorzystanieZTelefonu)}");
            call.Fire(Trigger.NawiazaniePolaczenie);
            Console.WriteLine($"{call.State} ==> Korzystanie z telefonu = {call.IsInState(State.KorzystanieZTelefonu)}");
            //czyPrawidlowyNumber = false; //- jeśli warunek się nie zgadza, wtedy wywoływany jest wyjątek
            call.Fire(Trigger.Rozlaczenie);
            Console.WriteLine($"{call.State} ==> Korzystanie z telefonu = {call.IsInState(State.KorzystanieZTelefonu)}");

            //Typy, akcje i ignorowanie przejść
            Console.WriteLine();
            var light = new StateMachine<bool, TriggerPrzelacznik>(false);
            light.Configure(false) // jeśli światło jest wylaczone
                .Permit(TriggerPrzelacznik.On, true) 
                .Ignore(TriggerPrzelacznik.Off);
            light.Configure(true) // jeśli światło jest wlaczone
                .Permit(TriggerPrzelacznik.Off, false)
                .Ignore(TriggerPrzelacznik.On)
                .OnEntry(() => Console.WriteLine("Czas start"))
                .OnExit(() => Console.WriteLine("Czas stop")); 
            light.Fire(TriggerPrzelacznik.On);
            light.Fire(TriggerPrzelacznik.Off); 
            light.Fire(TriggerPrzelacznik.Off);

            //Ponowne wejście w ten sam stan
            Console.WriteLine();
            //w konstruktorze możliwe jest pobieranie statusu i zapisywanie w innych miejsach np. w bazie danych
            bool stateToRead = false;
            var light2 = new StateMachine<bool, TriggerPrzelacznik>(() => stateToRead, s => stateToRead = s);
            light2.Configure(false) // jeśli światło jest wylaczone
               .Permit(TriggerPrzelacznik.On, true)
               .OnEntry(transition =>
                {
                    if (transition.IsReentry)
                    {
                        Console.WriteLine("Światło już jest wyłączone!");
                    }
                    else
                    {
                        Console.WriteLine("Wyłączam światło");
                    }
                })
                .PermitReentry(TriggerPrzelacznik.Off);
            light2.Configure(true) // jeśli światło jest wlaczone
                .Permit(TriggerPrzelacznik.Off, false)
                .OnEntryFrom(TriggerPrzelacznik.On, message => Console.WriteLine(message.Parameters[0]))
                .OnEntry(() => Console.WriteLine("Czas start"))
                .OnExit(() => Console.WriteLine("Czas stop"));
            var onTrigger = light2.SetTriggerParameters<string>(TriggerPrzelacznik.On);
            light2.Fire(onTrigger, "Wysłałem parametr do StateLess");
            Console.WriteLine();
            light2.Fire(TriggerPrzelacznik.Off);
            Console.WriteLine();
            light2.Fire(TriggerPrzelacznik.Off);
        }
    }
}
