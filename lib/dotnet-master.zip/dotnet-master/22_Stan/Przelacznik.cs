﻿using System;
namespace _Stan
{
    public class Przelacznik
    {
        public Stan State = new WylaczonyPrzelacznik();
        public void On() { State.On(this); }
        public void Off() { State.Off(this); }
    }
}
