﻿using System;
namespace _Stan
{
    public abstract class Stan
    {
        public virtual void On(Przelacznik sw)
        {
            Console.WriteLine("Światło jest już włączone.");
        }
        public virtual void Off(Przelacznik sw)
        {
            Console.WriteLine("Światło jest już wyłączone.");
        }
    }
}
