﻿using System;
namespace _Stan
{
    public class WlaczonyPrzelacznik : Stan
    {
        public WlaczonyPrzelacznik()
        {
            Console.WriteLine("Światło włączone.");
        }
        public override void Off(Przelacznik sw)
        {
            Console.WriteLine("Wyłączanie światła...");
            sw.State = new WylaczonyPrzelacznik();
        }
    }
}
