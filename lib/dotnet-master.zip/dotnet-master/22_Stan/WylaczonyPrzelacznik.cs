﻿using System;
namespace _Stan
{
    public class WylaczonyPrzelacznik : Stan
    {
        public WylaczonyPrzelacznik()
        {
            Console.WriteLine("Światło wyłączone.");
        }
        public override void On(Przelacznik sw)
        {
            Console.WriteLine("Włączanie światła...");
            sw.State = new WlaczonyPrzelacznik();
        }
    }
}
