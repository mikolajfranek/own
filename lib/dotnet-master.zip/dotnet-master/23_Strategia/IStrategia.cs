﻿using System;
using System.Text;

namespace _Strategia
{
    public interface IStrategia
    {
        void Start(StringBuilder sb);
        void AddListItem(StringBuilder sb, string item);
        void End(StringBuilder sb);
    }
}
