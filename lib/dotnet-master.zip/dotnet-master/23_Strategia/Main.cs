﻿using System;

namespace _Strategia
{
    class MainClass
    {
        //Wzorzez pozwala na zdefiniowanie szkieletu algorytmu
        public static void Main(string[] args)
        {
            //Strategia dynamiczna
            var textProcessor = new TextProcessor();
            textProcessor.SetOutputFormat(TextProcessor.OutputFormat.Markdown);
            textProcessor.AppendList(new[] { "abc", "def", "ghi" });
            Console.WriteLine(textProcessor);
            textProcessor.Clear();
            textProcessor.SetOutputFormat(TextProcessor.OutputFormat.Html);
            textProcessor.AppendList(new[] { "abc", "def", "ghi" });
            Console.WriteLine(textProcessor);

            //Strategia statyczna
            var textProcessorStatic = new TextProcessorStatic<MarkdownStrategia>();
            textProcessorStatic.AppendList(new[] { "abc", "def", "ghi" });
            Console.WriteLine(textProcessorStatic);
            var textProcessorStaticHtml = new TextProcessorStatic<HtmlStrategia>();
            textProcessorStaticHtml.AppendList(new[] { "abc", "def", "ghi" });
            Console.WriteLine(textProcessorStaticHtml);
        }
    }
}
