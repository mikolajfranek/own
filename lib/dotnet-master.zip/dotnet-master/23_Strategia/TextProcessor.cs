﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _Strategia
{
    public class TextProcessor
    {
        public enum OutputFormat
        {
            Markdown,
            Html
        }

        private StringBuilder sb = new StringBuilder();
        private IStrategia strategia;
        public void AppendList(IEnumerable<string> items)
        {
            strategia.Start(sb);
            foreach (var item in items)
                strategia.AddListItem(sb, item);
            strategia.End(sb);
        }
        public override string ToString() => sb.ToString();

        public void SetOutputFormat(OutputFormat format)
        {
            switch (format)
            {
                case OutputFormat.Markdown:
                    strategia = new MarkdownStrategia();
                    break;
                case OutputFormat.Html:
                    strategia = new HtmlStrategia();
                    break;
                default:
                    throw new ArgumentOutOfRangeException(nameof(format), format, null);
            }
        }

        public void Clear()
        {
            sb.Clear();
        }
    }
}
