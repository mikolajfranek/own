﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _Strategia
{
    public class TextProcessorStatic<T>
        where T : IStrategia, new()
    {
        private StringBuilder sb = new StringBuilder();
        private IStrategia strategia = new T();
        public void AppendList(IEnumerable<string> items)
        {
            strategia.Start(sb);
            foreach (var item in items)
                strategia.AddListItem(sb, item);
            strategia.End(sb);
        }
        public override string ToString() => sb.ToString();
    }
}
