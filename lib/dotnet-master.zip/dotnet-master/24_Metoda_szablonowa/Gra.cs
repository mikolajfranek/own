﻿using System;
namespace _Metoda_szablonowa
{
    public abstract class Gra
    {
        public Gra(int liczbaGraczy)
        {
            this.liczbaGraczy = liczbaGraczy;
        }
        protected int aktualnyGracz;
        protected readonly int liczbaGraczy;

        public void Run()
        {
            Start();
            while (ZnalezionoZwyciezce == false)
            {
                WykonajRuch();
            }
            Console.WriteLine($"Gracz {ZwycieskiUzytkownik} wygrał.");
        }
        protected abstract void Start();
        protected abstract bool ZnalezionoZwyciezce { get; }
        protected abstract void WykonajRuch();
        protected abstract int ZwycieskiUzytkownik { get; }
    }
}
