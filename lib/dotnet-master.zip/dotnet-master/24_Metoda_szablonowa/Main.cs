﻿using System;

namespace _Metoda_szablonowa
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            var sz = new Szachy();
            sz.Run();
        }
    }
}
