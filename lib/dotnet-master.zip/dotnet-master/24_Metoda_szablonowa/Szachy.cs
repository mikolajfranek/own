﻿using System;
namespace _Metoda_szablonowa
{
    public class Szachy : Gra
    {
        public Szachy() : base(2) { }

        private int maksymalnaIloscRuchow = 10;
        private int ruch = 1;
        protected override bool ZnalezionoZwyciezce => ruch == maksymalnaIloscRuchow;
        protected override int ZwycieskiUzytkownik => aktualnyGracz;
        protected override void Start()
        {
            Console.WriteLine("Rozpoczecie gry");
        }
        protected override void WykonajRuch()
        {
            Console.WriteLine($"Gracz {aktualnyGracz} wykonał {ruch++}. ruch.");
            aktualnyGracz = (aktualnyGracz + 1) % liczbaGraczy;
        }
    }
}
