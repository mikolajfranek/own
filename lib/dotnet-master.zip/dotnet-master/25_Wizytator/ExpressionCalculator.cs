﻿using System;
using System.Text;

namespace _Wizytator
{
    public class ExpressionCalculator : IExpressionVisitor
    {
        public double Result;

        public void Visit(WyrazenieDouble de)
        {
            Result = de.Value;
        }

        public void Visit(WyrazenieDodawanie ae)
        {
            ae.Left.Accept(this);
            var a = Result;
            ae.Right.Accept(this);
            var b = Result;
            Result = a + b;
        }
    }
}
