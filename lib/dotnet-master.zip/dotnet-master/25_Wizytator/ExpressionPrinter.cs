﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _Wizytator
{
    public static class ExpressionPrinter
    {
        public static void Print(WyrazenieDouble e, StringBuilder sb)
        {
            sb.Append(e.Value);
        }

        public static void Print(WyrazenieDodawanie ae, StringBuilder sb)
        {
            //Uwaga: dynamic sprawdza typ podczas uruchomienia
            sb.Append("(");
            Print(ae.Left as dynamic, sb); 
            sb.Append("+");
            Print(ae.Right as dynamic, sb); 
            sb.Append(")");
        }

        public static void PrintPrzeciazenie(Wyrazenie e, StringBuilder sb)
        {
            if (e is WyrazenieDouble de)
            {
                sb.Append(de.Value);
            }
            else if (e is WyrazenieDodawanie ae)
            {
                sb.Append("(");
                PrintPrzeciazenie(ae.Left, sb);
                sb.Append("+");
                PrintPrzeciazenie(ae.Right, sb);
                sb.Append(")");
            }
        }

        private static Dictionary<Type, Action<Wyrazenie, StringBuilder>> actions = new Dictionary<Type, Action<Wyrazenie, StringBuilder>>
        {
            [typeof(WyrazenieDouble)] = (e, sb) =>
            {
                var de = (WyrazenieDouble)e;
                sb.Append(de.Value);
            },
            [typeof(WyrazenieDodawanie)] = (e, sb) =>
            {
                var ae = (WyrazenieDodawanie)e;
                sb.Append("(");
                PrintPrzeciazenie(ae.Left, sb);
                sb.Append("+");
                PrintPrzeciazenie(ae.Right, sb);
                sb.Append(")");
            }
        };

        public static void PrintExtension(this Wyrazenie e, StringBuilder sb)
        {
            actions[e.GetType()](e, sb);
        }
    }
}
