﻿using System;
using System.Linq.Expressions;
using System.Text;

namespace _Wizytator
{
    public class ExpressionPrinterClassic : IExpressionVisitor,
        IVisitor,
        IVisitor<Wyrazenie>,
        IVisitor<WyrazenieDouble>,
        IVisitor<WyrazenieDodawanie>
    {
        StringBuilder sb = new StringBuilder();
        public void Visit(WyrazenieDouble de)
        {
            sb.Append(de.Value);
        }
        public void Visit(WyrazenieDodawanie ae)
        {
            sb.Append("(");
            ae.Left.Accept(this);
            sb.Append("+");
            ae.Right.Accept(this);
            sb.Append(")");
        }
        public override string ToString() => sb.ToString();


        //Acyclic
        public void VisitAcyclic(Wyrazenie obj)
        {
            throw new NotImplementedException();
        }

        public void VisitAcyclic(WyrazenieDouble obj)
        {
            sb.Append(obj.Value);
        }

        public void VisitAcyclic(WyrazenieDodawanie obj)
        {
            sb.Append("(");
            obj.Left.AcceptAcyclic(this);
            sb.Append("+");
            obj.Right.AcceptAcyclic(this);
            sb.Append(")");
        }
    }
}
