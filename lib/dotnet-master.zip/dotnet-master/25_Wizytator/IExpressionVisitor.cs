﻿using System;
namespace _Wizytator
{
    public interface IExpressionVisitor
    {
        void Visit(WyrazenieDouble de);
        void Visit(WyrazenieDodawanie ae);
    }
}
