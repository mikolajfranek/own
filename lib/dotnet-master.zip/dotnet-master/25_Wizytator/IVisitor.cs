﻿using System;
namespace _Wizytator
{
    public interface IVisitor<T>
    {
        void VisitAcyclic(T obj);
    }

    public interface IVisitor { }
}
