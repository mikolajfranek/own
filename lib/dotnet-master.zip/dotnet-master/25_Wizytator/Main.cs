﻿using System;
using System.Text;

namespace _Wizytator
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            //Nachalny wizytator
            var e = new WyrazenieDodawanie(left: new WyrazenieDouble(10),
                right: new WyrazenieDodawanie(left: new WyrazenieDouble(2), right: new WyrazenieDouble(3)));
            var sb = new StringBuilder();
            e.Print(sb);
            Console.WriteLine(sb);

            //Wyświetlacz reflektywny
            Console.WriteLine();
            sb.Clear();
            ExpressionPrinter.PrintPrzeciazenie((Wyrazenie)e, sb);
            Console.WriteLine(sb);

            //Another method
            Console.WriteLine();
            sb.Clear();
            ExpressionPrinter.PrintExtension(e, sb);
            Console.WriteLine(sb);

            //Co to jest dysponowanie?
            IStuff foo = new Foo();
            //Something.func(foo); - nie można w ten sposób zinterpretować z który typ zostanie wykonany, stąd rozwiązanie poniżej
            foo.call();


            //Wizytator dynamiczny - dynamiczna dyspozycja
            Console.WriteLine();
            sb.Clear();
            ExpressionPrinter.Print(e, sb);
            Console.WriteLine(sb);

            //Klasyczny wizytator
            Console.WriteLine();
            var expressionPrinterClassic = new ExpressionPrinterClassic();
            expressionPrinterClassic.Visit(e);
            Console.WriteLine(expressionPrinterClassic);

            //Kalkulator
            Console.WriteLine();
            var expressionCalculator = new ExpressionCalculator();
            expressionCalculator.Visit(e);
            Console.WriteLine($"{expressionPrinterClassic} = {expressionCalculator.Result}");

            //Wizytator acykliczny
            Console.WriteLine();
            var expressionPrinterClassicAcyclic = new ExpressionPrinterClassic();
            expressionPrinterClassicAcyclic.VisitAcyclic(e);
            Console.WriteLine(expressionPrinterClassicAcyclic);
        }

        interface IStuff {
            void call();
        }
        public class Foo : IStuff
        {
            void IStuff.call()
            {
                Something.func(this);
            }
        }
        public class Bar : IStuff{
            void IStuff.call()
            {
                Something.func(this);
            }
        }

        public static class Something
        {
            public static void func(Foo foo) { }
            public static void func(Bar bar) { }
        }
    }
}
