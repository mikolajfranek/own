﻿using System;
using System.Text;

namespace _Wizytator
{
    public abstract class Wyrazenie
    {
        public abstract void Print(StringBuilder sb);
        public abstract void Accept(IExpressionVisitor visitor);

        public virtual void AcceptAcyclic(IVisitor visitor)
        {
            if (visitor is IVisitor<Wyrazenie> typed)
            {
                typed.VisitAcyclic(this);
            }
        }
    }
}
