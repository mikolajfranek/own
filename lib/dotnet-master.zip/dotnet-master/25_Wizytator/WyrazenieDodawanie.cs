﻿using System;
using System.Text;

namespace _Wizytator
{
    public class WyrazenieDodawanie : Wyrazenie
    {
        private Wyrazenie left, right;
        public Wyrazenie Left { get => left; }
        public Wyrazenie Right { get => right; }

        public WyrazenieDodawanie(Wyrazenie left, Wyrazenie right)
        {
            this.left = left;
            this.right = right;
        }

        public override void Print(StringBuilder sb)
        {
            sb.Append(value: "(");
            left.Print(sb);
            sb.Append(value: "+");
            right.Print(sb);
            sb.Append(value: ")");
        }

        public override void Accept(IExpressionVisitor visitor)
        {
            visitor.Visit(this);
        }

        public override void AcceptAcyclic(IVisitor visitor)
        {
            if (visitor is IVisitor<WyrazenieDodawanie> typed)
            {
                typed.VisitAcyclic(this);
            }
        }
    }
}
