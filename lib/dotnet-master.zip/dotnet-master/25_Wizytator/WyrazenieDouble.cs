﻿using System;
using System.Text;

namespace _Wizytator
{
    public class WyrazenieDouble : Wyrazenie
    {
        private double value;
        public double Value { get => value; }
        public WyrazenieDouble(double value) { this.value = value; }

        public override void Print(StringBuilder sb)
        {
            sb.Append(value: value);
        }

        public override void Accept(IExpressionVisitor visitor)
        {
            visitor.Visit(this);
        }

        public override void AcceptAcyclic(IVisitor visitor)
        {
            if (visitor is IVisitor<WyrazenieDouble> typed)
            {
                typed.VisitAcyclic(this);
            }
        }
    }
}
