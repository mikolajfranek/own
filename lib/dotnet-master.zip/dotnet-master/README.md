# dotnet
Project patterns
