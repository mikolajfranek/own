﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;

namespace NumberChooser
{
    public class Chooser
    {
        private List<List<int>> collectionFromHistory = new List<List<int>>();
        private List<List<int>> collectionFound = new List<List<int>>();
        private int sizeOfCollection = 0;
        private int maxNumberInCollection = 0;

        public Chooser(int sizeOfCollection, int maxNumberInCollection)
        {
            this.sizeOfCollection = sizeOfCollection;
            this.maxNumberInCollection = maxNumberInCollection;
        }

        public List<int> RandColleciton()
        {
            List<int> result = new List<int>();
            for (int i = 0; i < sizeOfCollection;)
            {
                int newNumber = (new Random()).Next(1, maxNumberInCollection + 1);
                if (result.Contains(newNumber)) continue;
                result.Add(newNumber);
                i++;
            }
            return result;
        }

        public string GetCollection()
        {
            List<int> randomCollection = null;
            bool isDuplicate = false;
            bool isFound = false;
            int countNumbersInterseted = 0;
            int maxCountNumbersInterseted = 0;

            do
            {
                isFound = true;
                maxCountNumbersInterseted = 0;

                do
                {
                    isDuplicate = false;
                    randomCollection = RandColleciton();
                    foreach (List<int> found in this.collectionFound)
                    {
                        if (found.Intersect(randomCollection).ToList().Count == 0)
                        {
                            isDuplicate = true;
                            break;
                        }
                    }
                } while (isDuplicate == true);


                foreach (List<int> collection in this.collectionFromHistory)
                {
                    countNumbersInterseted = collection.Intersect(randomCollection).ToList().Count;

                    if (maxCountNumbersInterseted < countNumbersInterseted)
                    {
                        maxCountNumbersInterseted = countNumbersInterseted;
                    }

                    if (maxCountNumbersInterseted > MyConfiguration.MAX_COUNT_NUMBERS_INTERSECTED)
                    {
                        isFound = false;
                        break;
                    }
                }

            } while (isFound == false);

            return string.Join(", ", randomCollection) + " --> max count numbers interseted in history: " + maxCountNumbersInterseted;
        }

        public void DownloadCollectionFromHistory(string url)
        {
            using (WebClient webClient = new WebClient())
            {
                string web = webClient.DownloadString(url);
                string[] lines = web.Split(new string[] { "\r\n" }, StringSplitOptions.RemoveEmptyEntries);
                foreach (string line in lines)
                {
                    string[] splitedNumbers = (line.Split(' '))[2].Split(',');
                    List<int> numbers = new List<int>();
                    foreach (string number in splitedNumbers)
                    {
                        numbers.Add(int.Parse(number));
                    }
                    collectionFromHistory.Add(numbers);
                }
            }
        }
    }
}