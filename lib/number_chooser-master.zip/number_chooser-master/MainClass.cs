﻿using System;

namespace NumberChooser
{
    class MainClass
    {
        private static void ShowMenu(string information = null)
        {
            Console.Clear();
            if(string.IsNullOrEmpty(information) == false)
            {
                Console.WriteLine(MyConfiguration.CONSOLE_SEPARATOR);
                Console.WriteLine(information);
            }
            Console.WriteLine(MyConfiguration.CONSOLE_SEPARATOR);
            Console.WriteLine("1) Lotto");
            Console.WriteLine("2) Minilotto");
            Console.WriteLine("3) Exit");
            Console.WriteLine(MyConfiguration.CONSOLE_SEPARATOR);
            Console.WriteLine("Select option:");
        }

        public static void Main(string[] args)
        {
            string input = "";
            bool canParse = false;
            Chooser chooser = null;
            string urlHistory = "";
            int sizeOfCollection = 0;
            int maxNumberInCollection = 0;

            ShowMenu();
            while (( (canParse = int.TryParse(input = Console.ReadLine(), out int selected)) == true && selected == (int)MyConfiguration.OPTIONS.EXIT) == false)
            {
                if(canParse == true)
                {
                    switch (selected) 
                    {
                        case (int)MyConfiguration.OPTIONS.LOTTO:
                            urlHistory = MyConfiguration.LOTTO_HISTORY_URL;
                            sizeOfCollection = 6;
                            maxNumberInCollection = 49;
                            break;
                        case (int)MyConfiguration.OPTIONS.MINI_LOTTO:
                            urlHistory = MyConfiguration.MINILOTTO_HISTORY_URL;
                            sizeOfCollection = 5;
                            maxNumberInCollection = 42;
                            break;
                        default:
                            urlHistory = "";
                            ShowMenu("You must choose right option");
                            break;
                    }
                    if (string.IsNullOrEmpty(urlHistory)) continue;
                    try
                    {
                        chooser = new Chooser(sizeOfCollection, maxNumberInCollection);
                        chooser.DownloadCollectionFromHistory(urlHistory);
                        string information = "Wait, numbers are choosing...";
                        ShowMenu(information);
                        for (int i = 0; i < MyConfiguration.NUMBER_OF_COLLECTION; i++) 
                        {
                            information += "\n" + chooser.GetCollection();
                            ShowMenu(information);
                        }
                        information += "\n" + "End of choosing";
                        ShowMenu(information);
                    }
                    catch(Exception e)
                    {
                        ShowMenu(e.Message);
                    }
                }
                else 
                {
                    ShowMenu("You must choose right option");
                }
            }
            Console.WriteLine("End of program, press enter to close");
            Console.ReadLine();
        }
    }
}