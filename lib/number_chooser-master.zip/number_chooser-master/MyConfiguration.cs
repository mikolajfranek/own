﻿namespace NumberChooser
{
    public static class MyConfiguration
    {
        public const string CONSOLE_SEPARATOR = "------------------------------------------------";
        public enum OPTIONS { LOTTO = 1, MINI_LOTTO, EXIT };

        public const string LOTTO_HISTORY_URL = "http://www.mbnet.com.pl/dl.txt";
        public const string MINILOTTO_HISTORY_URL = "http://www.mbnet.com.pl/el.txt";

        public const int NUMBER_OF_COLLECTION = 8;
        public const int MAX_COUNT_NUMBERS_INTERSECTED = 3;
    }
}